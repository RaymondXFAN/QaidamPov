# EXP-E — difficulty diagnostic (paired ΔIoU vs single-task)

| filter | train/test | saline% | single IoU | dual λ=1.0 (p) | best λ | best ΔIoU (p) |
|---|---|---:|---|---:|---|---|
| all | 280/60 | 62.5 | 0.9030 | 0.9001 (p=0.222) | 0.3 | +0.0024 (p=0.002) |
| high_saline | 191/39 | 91.2 | 0.9312 | 0.9274 (p=0.077) | 0.3 | +0.0011 (p=0.489) |
| balanced | 69/13 | 47.9 | 0.6972 | 0.6774 (p=0.169) | 1.0 | -0.0199 (p=0.169) |
| change_rich | 125/23 | 47.9 | 0.7644 | 0.7496 (p=0.216) | 0.3 | -0.0060 (p=0.598) |

## Verdict
- **all**: best λ=0.3, ΔIoU=+0.0024 (SIGNIFICANT, p=0.002)
- **high_saline**: best λ=0.3, ΔIoU=+0.0011 (n.s., p=0.489)
- **balanced**: best λ=1.0, ΔIoU=-0.0199 (n.s., p=0.169)
- **change_rich**: best λ=0.3, ΔIoU=-0.0060 (n.s., p=0.598)

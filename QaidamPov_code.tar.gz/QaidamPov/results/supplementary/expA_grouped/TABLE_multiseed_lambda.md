# EXP-A — Multi-seed x lambda grid (ddof=1)

seeds = [42, 123, 2024] | lambdas = [1.0, 0.3, 0.5, 0.7] | n_seeds = 3

## Table A1. Dual-task static metrics by lambda (mean +/- sample std over seeds)

| lambda | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |
|---|---:|---|---|---|---|---|---|
| 1.0 | 3 | 0.8471±0.0233 | 0.8003±0.0229 | 0.8399±0.0277 | 0.8213±0.0329 | 0.6474±0.0617 | 0.4203±0.0090 |
| 0.3 | 3 | 0.8428±0.0203 | 0.7969±0.0206 | 0.8343±0.0237 | 0.8143±0.0278 | 0.6347±0.0526 | 0.4146±0.0128 |
| 0.5 | 3 | 0.8517±0.0261 | 0.8051±0.0275 | 0.8454±0.0296 | 0.8277±0.0345 | 0.6595±0.0660 | 0.4321±0.0265 |
| 0.7 | 3 | 0.8586±0.0227 | 0.8130±0.0236 | 0.8526±0.0260 | 0.8359±0.0304 | 0.6755±0.0581 | 0.4327±0.0273 |
| single-task | 3 | 0.8676±0.0417 | 0.8252±0.0454 | 0.8612±0.0471 | 0.8450±0.0548 | 0.6947±0.1050 | — |

## Table A2. Paired dual-task vs single-task, IoU(saline), same seeds

| lambda | mean delta IoU | t | df | p | 95% CI |
|---|---:|---:|---:|---:|---|
| 1.0 | -0.0249 | -1.330 | 2 | 0.3150 | [-0.1055, +0.0557] |
| 0.3 | -0.0283 | -1.921 | 2 | 0.1947 | [-0.0917, +0.0351] |
| 0.5 | -0.0201 | -1.468 | 2 | 0.2798 | [-0.0789, +0.0387] |
| 0.7 | -0.0122 | -0.376 | 2 | 0.7430 | [-0.1512, +0.1269] |

> Read: the defensible headline is the lambda=1.0 paired row (same seeds, same config). The best-lambda row shows where the dual-task head *can* help, but it must be reported as a lambda-selected value, not an unbiased estimate.

# EXP-B — Change-head per-class metrics (raw export)

Test set: 983040 pixels. Class shares (change): stable non-saline 34.4%, stable saline 60.6%, expansion 3.1%, shrinkage 2.0%

## dual — pooled confusion matrix (sum of 12 runs)

```
[[3228306   74532  735543   19947]
 [  22440 6336924  774590   12190]
 [  35449   35938  285309    4408]
 [  38597   57038  128558    6711]]
```

### Per-class (from pooled CM)

| class | P | R | F1 | support |
|---|---:|---:|---:|---:|
| stable non-saline | 0.9710 | 0.7955 | 0.8745 | 4058328 |
| stable saline | 0.9742 | 0.8868 | 0.9284 | 7146144 |
| expansion | 0.1483 | 0.7901 | 0.2497 | 361104 |
| shrinkage | 0.1551 | 0.0291 | 0.0490 | 230904 |
| **macro** | 0.5622 | 0.6254 | 0.5254 | 11796480 |
| **weighted** | 0.9318 | 0.8356 | 0.8719 | — |

- pooled accuracy = 0.8356 (equals weighted recall = 0.8356)
- mean-of-runs: acc 0.8356, F1-macro 0.5199, F1-weighted 0.8713
- macro-F1 from pooled CM = 0.5254  vs  mean of per-class F1 = 0.5254 -> SAME

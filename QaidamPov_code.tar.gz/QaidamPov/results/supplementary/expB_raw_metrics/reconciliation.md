# Table 4 arithmetic audit

Manuscript reported: accuracy 0.690; macro-F1 0.36; weighted 0.81/0.69/0.75.

Checks:
- In single-label multi-class, weighted recall == accuracy. Any (accuracy, weighted-recall) pair that differs is internally inconsistent.
- macro-F1 must equal the mean of per-class F1 only if computed from the same confusion matrix; report the exact source.
- If the dominant class share * its recall already exceeds the reported accuracy, the accuracy is impossible.

See TABLE_change_per_class.md for the values re-derived from the raw CM.
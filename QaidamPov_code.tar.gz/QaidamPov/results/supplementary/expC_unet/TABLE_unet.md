# EXP-C — U-Net baseline (ddof=1)

| model | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |
|---|---:|---|---|---|---|---|---|
| UNet-single | 3 | 0.9415±0.0015 | 0.9096±0.0023 | 0.9417±0.0015 | 0.9380±0.0016 | 0.8760±0.0031 | nan±nan |
| UNet-dual | 3 | 0.9417±0.0006 | 0.9106±0.0009 | 0.9418±0.0007 | 0.9380±0.0007 | 0.8761±0.0014 | 0.5501±0.0249 |

# EXP-A — Multi-seed x lambda grid (ddof=1)

seeds = [42] | lambdas = [1.0] | n_seeds = 1

## Table A1. Dual-task static metrics by lambda (mean +/- sample std over seeds)

| lambda | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |
|---|---:|---|---|---|---|---|---|
| 1.0 | 1 | 0.8991±0.0000 | 0.8559±0.0000 | 0.8975±0.0000 | 0.8892±0.0000 | 0.7790±0.0000 | 0.4652±0.0000 |
| single-task | 1 | 0.9121±0.0000 | 0.8624±0.0000 | 0.9132±0.0000 | 0.9088±0.0000 | 0.8184±0.0000 | — |

## Table A2. Paired dual-task vs single-task, IoU(saline), same seeds

| lambda | mean delta IoU | t | df | p | 95% CI |
|---|---:|---:|---:|---:|---|
| 1.0 | (insufficient seeds) | | | | |

> Read: the defensible headline is the lambda=1.0 paired row (same seeds, same config). The best-lambda row shows where the dual-task head *can* help, but it must be reported as a lambda-selected value, not an unbiased estimate.

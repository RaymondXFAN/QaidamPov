# QaidamPov supplementary — summary

generated: 2026-10-11 13:32:54

## expA_multiseed_lambda/TABLE_multiseed_lambda.md
```
# EXP-A — Multi-seed x lambda grid (ddof=1)

seeds = [42, 123, 2024] | lambdas = [1.0, 0.3, 0.5, 0.7] | n_seeds = 3

## Table A1. Dual-task static metrics by lambda (mean +/- sample std over seeds)

| lambda | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |
|---|---:|---|---|---|---|---|---|
| 1.0 | 3 | 0.9344±0.0034 | 0.9001±0.0045 | 0.9344±0.0036 | 0.9300±0.0039 | 0.8601±0.0079 | 0.5201±0.0281 |
| 0.3 | 3 | 0.9382±0.0021 | 0.9050±0.0035 | 0.9383±0.0021 | 0.9344±0.0021 | 0.8688±0.0042 | 0.5200±0.0098 |
| 0.5 | 3 | 0.9338±0.0027 | 0.8989±0.0047 | 0.9339±0.0026 | 0.9296±0.0028 | 0.8592±0.0056 | 0.5113±0.0113 |
| 0.7 | 3 | 0.9362±0.0030 | 0.9032±0.0028 | 0.9361±0.0033 | 0.9317±0.0039 | 0.8635±0.0078 | 0.5280±0.0117 |
| single-task | 3 | 0.9363±0.0005 | 0.9016±0.0005 | 0.9366±0.0006 | 0.9327±0.0007 | 0.8654±0.0013 | — |

## Table A2. Paired dual-task vs single-task, IoU(saline), same seeds

| lambda | mean delta IoU | t | df | p | 95% CI |
|---|---:|---:|---:|---:|---|
| 1.0 | -0.0014 | -0.496 | 2 | 0.6688 | [-0.0138, +0.0110] |
| 0.3 | +0.0035 | 1.981 | 2 | 0.1862 | [-0.0041, +0.0110] |
| 0.5 | -0.0026 | -0.886 | 2 | 0.4692 | [-0.0155, +0.0102] |
| 0.7 | +0.0016 | 0.993 | 2 | 0.4252 | [-0.0054, +0.0087] |

> Read: the defensible headline is the lambda=1.0 paired row (same seeds, same config). The best-lambda row shows where the dual-task head *can* help, but it must be reported as a lambda-selected value, not an unbiased estimate.
```

## expB_raw_metrics/TABLE_change_per_class.md
```
# EXP-B — Change-head per-class metrics (raw export)

Test set: 983040 pixels. Class shares (change): stable non-saline 34.4%, stable saline 60.6%, expansion 3.1%, shrinkage 2.0%

## dual — pooled confusion matrix (sum of 12 runs)

```
[[3228306   74532  735543   19947]
 [  22440 6336924  774590   12190]
 [  35449   35938  285309    4408]
 [  38597   57038  128558    6711]]
```

### Per-class (from pooled CM)

| class | P | R | F1 | support |
|---|---:|---:|---:|---:|
| stable non-saline | 0.9710 | 0.7955 | 0.8745 | 4058328 |
| stable saline | 0.9742 | 0.8868 | 0.9284 | 7146144 |
| expansion | 0.1483 | 0.7901 | 0.2497 | 361104 |
| shrinkage | 0.1551 | 0.0291 | 0.0490 | 230904 |
| **macro** | 0.5622 | 0.6254 | 0.5254 | 11796480 |
| **weighted** | 0.9318 | 0.8356 | 0.8719 | — |

- pooled accuracy = 0.8356 (equals weighted recall = 0.8356)
- mean-of-runs: acc 0.8356, F1-macro 0.5199, F1-weighted 0.8713
- macro-F1 from pooled CM = 0.5254  vs  mean of per-class F1 = 0.5254 -> SAME
```

## expC_unet/TABLE_unet.md
```
# EXP-C — U-Net baseline (ddof=1)

| model | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |
|---|---:|---|---|---|---|---|---|
| UNet-single | 3 | 0.9415±0.0015 | 0.9096±0.0023 | 0.9417±0.0015 | 0.9380±0.0016 | 0.8760±0.0031 | nan±nan |
| UNet-dual | 3 | 0.9417±0.0006 | 0.9106±0.0009 | 0.9418±0.0007 | 0.9380±0.0007 | 0.8761±0.0014 | 0.5501±0.0249 |
```


# EXP-A — Multi-seed x lambda grid (ddof=1)

seeds = [42, 123, 2024] | lambdas = [1.0, 0.3, 0.5, 0.7] | n_seeds = 3

## Table A1. Dual-task static metrics by lambda (mean +/- sample std over seeds)

| lambda | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |
|---|---:|---|---|---|---|---|---|
| 1.0 | 3 | 0.9344±0.0034 | 0.9001±0.0045 | 0.9344±0.0036 | 0.9300±0.0039 | 0.8601±0.0079 | 0.5201±0.0281 |
| 0.3 | 3 | 0.9382±0.0021 | 0.9050±0.0035 | 0.9383±0.0021 | 0.9344±0.0021 | 0.8688±0.0042 | 0.5200±0.0098 |
| 0.5 | 3 | 0.9338±0.0027 | 0.8989±0.0047 | 0.9339±0.0026 | 0.9296±0.0028 | 0.8592±0.0056 | 0.5113±0.0113 |
| 0.7 | 3 | 0.9362±0.0030 | 0.9032±0.0028 | 0.9361±0.0033 | 0.9317±0.0039 | 0.8635±0.0078 | 0.5280±0.0117 |
| single-task | 3 | 0.9363±0.0005 | 0.9016±0.0005 | 0.9366±0.0006 | 0.9327±0.0007 | 0.8654±0.0013 | — |

## Table A2. Paired dual-task vs single-task, IoU(saline), same seeds

| lambda | mean delta IoU | t | df | p | 95% CI |
|---|---:|---:|---:|---:|---|
| 1.0 | -0.0014 | -0.496 | 2 | 0.6688 | [-0.0138, +0.0110] |
| 0.3 | +0.0035 | 1.981 | 2 | 0.1862 | [-0.0041, +0.0110] |
| 0.5 | -0.0026 | -0.886 | 2 | 0.4692 | [-0.0155, +0.0102] |
| 0.7 | +0.0016 | 0.993 | 2 | 0.4252 | [-0.0054, +0.0087] |

> Read: the defensible headline is the lambda=1.0 paired row (same seeds, same config). The best-lambda row shows where the dual-task head *can* help, but it must be reported as a lambda-selected value, not an unbiased estimate.

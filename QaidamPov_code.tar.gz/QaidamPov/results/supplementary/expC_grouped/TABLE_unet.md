# EXP-C — U-Net baseline (ddof=1)

| model | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |
|---|---:|---|---|---|---|---|---|
| UNet-single | 3 | 0.8344±0.0074 | 0.7886±0.0086 | 0.8245±0.0078 | 0.8028±0.0088 | 0.6129±0.0171 | nan±nan |
| UNet-dual | 3 | 0.8512±0.0129 | 0.8055±0.0121 | 0.8440±0.0156 | 0.8257±0.0187 | 0.6562±0.0349 | 0.4351±0.0098 |

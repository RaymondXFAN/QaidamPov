# QaidamSalineBench

**A leakage-aware, proxy-labelled saline mapping benchmark for the Qaidam Basin — built entirely from free Sentinel-2 and ESA WorldCover data, reporting the negative results as carefully as the positive ones.**

---

## What this is

This repository is the full, runnable code behind our study of saline-land mapping in the
Qaidam Basin (Qinghai–Tibet Plateau, China). It rebuilds the Sentinel-2 + ESA WorldCover
dataset from public, account-free sources; trains and evaluates a family of models —
pixel-level Random Forest and XGBoost, a 6.10 M-parameter dual-task CNN, a U-Net, and a
LoRA-tuned Prithvi-EO foundation model — under **two evaluation protocols at once** (the
conventional overlapping **patch-level** split and a **leakage-free** spatially disjoint
split); and ships every result as machine-readable JSON plus Markdown. Because there is no
field EC ground truth, all "accuracy" here is explicitly **proxy-label agreement**: IoU
against ESA WorldCover class 60, never against measured soil salinity. The headline is
deliberately unglamorous — the auxiliary change-regularization head buys **no** robust
accuracy gain at this sample size, a six-band pixel-level Random Forest is the strongest
model under the patch-level protocol, and the patch-level protocol itself inflates IoU by
**0.04–0.12 and reorders the models**, because 100 % of test patches share their source
tile with the training data. We ship both protocols precisely because that reordering is
the finding.

---

## What it answers

1. **Can saline land be mapped basin-wide with no ground-truth labels?** Yes — using ESA
   WorldCover class 60 as a saline proxy over single-date Sentinel-2 imagery, at a stated
   and quantified proxy-label cost.
2. **Does a dual-task network beat a single-task one?** No. Not at 274–280 training
   patches. Every paired ΔIoU is non-significant under the patch-level split (a tight null,
   bounded below ~0.9 pp), and under the leakage-free split the sign turns negative in nine
   of twelve seed×λ configurations.
3. **Is the patch-level evaluation everyone uses trustworthy?** No. Fixing the 50 % patch
   overlap changes both the numbers and the model ranking.

**What it is not:** no field EC validation, no multi-decadal trend product, no operational
change detector. The four-class "stability" head is an *auxiliary regularizer* and a
transparency baseline, not a production output — its rare-class F1 stays at 0.00–0.07 under
three different rebalancing schemes, and we say so.

---

## Repository layout

```
rebuild/          dataset reconstruction: public sources → .npy tensors
                  rb_common.py · rebuild_dataset.py · run_rebuild.sh · selftest_rebuild.py
supp/             the experiment suite — this is the interesting part
                  common.py (models, metrics, hand-rolled paired t-test)
                  exp_a … exp_j (10 controlled experiments)
                  paired_stats.py (pure-numpy inference kernel: McNemar, cluster bootstrap)
                  run_supplementary.sh · run_p1_extra.sh (idempotent runners with gates)
                  selftest_supp.py · selftest_p1_extra.py (offline, CPU, no network)
figures/          standalone figure pipeline — no data needed, values are embedded
                  make_fig1.py (study area) · make_figures.py (architecture, IoU, λ ablation)
                  fig1–fig4 as .pdf (vector) and .png (300 dpi) · geo/ (study-area polygons)
results/          every table as JSON + Markdown  ← the deliverable
docs/             RESULTS_CANONICAL.md — the canonical number set, with provenance
DATA.md           what the inputs are, where to get them, and how they are preprocessed
DEPLOY.md         the full reproduction guide (environment, CLIs, runtimes, the traps)
```

**Data are not committed.** Raw tensors are ~250 MB and every byte is regenerable from
public sources — see [`DATA.md`](DATA.md) and `rebuild/`.

---

## Quickstart

```bash
pip install -r requirements.txt

# 1) two-minute sanity check — CPU, no GPU, no network
python rebuild/selftest_rebuild.py     # expect: PASS
python supp/selftest_supp.py           # expect: PASS
python supp/selftest_p1_extra.py       # expect: PASS   (26 checks; 36 with torch)

# 2) figures — no GPU, no data, under five seconds
python figures/make_fig1.py            # study-area map (3 panels)
python figures/make_figures.py         # architecture · IoU comparison · λ ablation

# 3) dataset, then experiments  (defaults assume PROJECT_DIR=/root/autodl-tmp/QaidamPov)
export PROJECT_DIR="$PWD"
cd rebuild && bash run_rebuild.sh gate && nohup bash run_rebuild.sh all > logs/boot.log 2>&1 &
cd ../supp  && bash run_supplementary.sh gate && nohup bash run_supplementary.sh all > logs/boot.log 2>&1 &
bash run_supplementary.sh status        # non-blocking; never use `tail -f`
```

Every runner has a **gate** step that proves data loading, forward/backward passes and
result-file writing on a tiny configuration before any long job starts, and every runner is
**idempotent** — it skips steps whose output files already exist. Full CLI flags, runtime
budgets and the mistakes that cost us days are in [`DEPLOY.md`](DEPLOY.md).

> `PROJECT_DIR` defaults to `/root/autodl-tmp/QaidamPov`, our working-directory name. Any
> checkout location works as long as you export `PROJECT_DIR` first.

---

## Headline numbers

Proxy-label IoU for the saline class (agreement with WorldCover class 60):

| Model | Patch-level split | Leakage-free split |
|---|---|---|
| Random Forest (pixel, 6 bands) | **0.926** [0.854, 0.972] | **0.869** |
| XGBoost (pixel, 6 bands) | 0.920 [0.841, 0.969] | 0.859 |
| Prithvi-EO-1.0-100M + LoRA (n = 3, preliminary) | 0.895 ± 0.007 | 0.856 ± 0.013 |
| CNN, single-task | 0.902 ± 0.001 | 0.825 ± 0.045 |
| U-Net, dual head | 0.911 ± 0.001 | 0.806 ± 0.012 |
| CNN, dual-task (λ = 1.0) | 0.900 ± 0.005 | 0.800 ± 0.023 |

Brackets are 95 % cluster-bootstrap intervals where computed. Values are as reported in the
accompanying manuscript; per-seed, per-configuration and per-class figures, together with
their confidence intervals and McNemar p-values, are in [`results/`](results/).

Three results matter more than the ranking:

- **The multi-task gain is a tight null, not an underpowered one.** Across 12 seed×λ
  pairings the tile-cluster bootstrap CI contains zero in 10 and reverses sign in the other
  two. The same 18 tiles resolve a 3.2 pp difference between Random Forest and the dual-task
  CNN (CI [+0.004, +0.071]) and a 0.8 pp difference between Random Forest and XGBoost, so a
  multi-task gain of that size would have been detected. The largest gain still compatible
  with the data is ≈0.9 pp.
- **Under a spatially disjoint split the sign turns negative.** At the resolution of the
  predictions the dual-task model is worse in 9 of 12 configurations (8 with a CI excluding
  zero, by 0.022–0.063) and in 2 of 3 seeds; the degradation is asymmetric (−0.03 for the
  single-task model, −0.06 to −0.08 for the dual-task one), which is what a
  capacity-competition account predicts rather than a uniform loss of data.
- **Rebalancing does not rescue the rare classes.** Class-weighted CE, focal loss (γ = 2),
  and focal + class-balanced weights give expansion F1 of 0.25, 0.00 and 0.23 — so the
  four-class head is reported as an auxiliary regularizer, not a stability product.

---

## Reproducibility contract

- One random seed per experiment is never enough: every comparison is **paired** across
  identical seeds (42 / 123 / 2024) and reported with a CI.
- Statistics run **without scipy**: the paired t-test, the exact McNemar test and the
  cluster bootstrap are implemented in `supp/common.py` and `supp/paired_stats.py`
  (pure numpy, so the inference kernel can be unit-tested offline).
- Bootstrap resampling is done over **spatial units**, not pixels. At n ≈ 10⁶, pixel-level
  CIs are anti-conservative to the point of being meaningless — the repo prints both so the
  contrast is visible.
- The split geometry is written to `dataset_card.json` at rebuild time; **no result is
  reported without the split it came from**.
- `selftest_*.py` are offline and CPU-only, so the pipeline can be validated before a GPU
  is ever booked.

---

## Data

All inputs are free and account-free: **Sentinel-2 L2A** via the AWS Earth Search STAC API,
**ESA WorldCover** v100/v200 for the saline proxy, and the open **Prithvi-EO-1.0-100M**
weights (Apache-2.0). Acquisition, band selection, cloud/season filtering, patch slicing,
label construction, split logic and the known WorldCover v100→v200 product drift are
documented in [`DATA.md`](DATA.md). Nothing needs to be downloaded by hand.

---

## Citation

If you use this benchmark, please cite the accompanying paper (BibTeX in
[`CITATION.cff`](CITATION.cff)). Please also cite the upstream data products: ESA
WorldCover (© ESA WorldCover project, CC BY 4.0), Copernicus Sentinel-2, and
Prithvi-EO-1.0 (IBM/NASA).

---

## Licence

Code released under the **MIT Licence** (see [`LICENSE`](LICENSE)). Data products are
third-party and carry their own terms — WorldCover is CC BY 4.0, Sentinel-2 is Copernicus
open data, Prithvi-EO-1.0 is Apache-2.0.

---

*Built because a benchmark that hides its null results is not a benchmark.*

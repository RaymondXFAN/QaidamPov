# results/ — every table, as JSON and Markdown

This directory is the actual deliverable of the repository. Each experiment writes:

- `*.json` — machine-readable, one file per run, with the configuration recorded inside;
- `TABLE_*.md` — the same numbers as a Markdown table, ready to paste into a manuscript;
- `SUMMARY*.txt` / `*.log` — per-run logs, kept because "which run produced this number" is
  part of the result.

## Directory map

| Directory | Produced by | Contents |
|---|---|---|
| `expA_multiseed_lambda/` | `supp/exp_a_multiseed_lambda.py` | seeds × λ grid (3 seeds × 4 λ) + paired single-task baselines; checkpoints in `ckpts/` (**not committed**) |
| `expA_grouped/` | same, on the group-disjoint data | the leakage-free twin of the above |
| `expB_raw_metrics/` | `supp/exp_b_export_raw_metrics.py` | pooled confusion matrices, per-class precision/recall/F1 |
| `expC_unet/`, `expC_grouped/` | `supp/exp_c_unet_baseline.py` | U-Net, patch-level and leakage-free |
| `expD_spatial/` | `supp/exp_d_spatial_split.py` | the leakage-free split construction + audit (including `patch_tiles` coverage) |
| `expE_diagnostic/` | `supp/exp_e_diagnostic.py` | difficulty-stratified paired ΔIoU (high-salinity / balanced / change-rich subsets) |
| `expF_classical/`, `expF_grouped/` | `supp/exp_f_classical_baselines.py` | pixel-level Random Forest and XGBoost |
| `expG_prithvi/`, `expG_grouped/` | `supp/exp_g_prithvi_rerun.py` | Prithvi-EO-1.0-100M + LoRA (preliminary) |
| `expH_paired_pixel/` | `supp/exp_h_paired_pixel_tests.py` | paired inference at the resolution of the predictions — patch-level split |
| `expH_paired_pixel_grouped/` | same, leakage-free | paired inference under the group-disjoint split |
| `expI_change_head/` | `supp/exp_i_change_head_loss.py` | change-head loss comparison: class-weighted CE, focal (γ = 2), focal + balanced |
| `expJ_split/` | `supp/exp_j_split_report.py` | split census: how many patches per partition, and how many tiles they share |
| `_gate/` | any runner's `gate` step | the two-minute proof that data loads, models train and result files are written |

## What is deliberately absent

- `ckpts/` — every `*.pth` / `*.pt`. Regenerate by rerunning the experiment; they are large,
  and a checkpoint without its split is worthless anyway.
- `data/` — every `*.npy`. Regenerate with `rebuild/` (see `../DATA.md`).

## Two fields worth knowing before you read a JSON

- **`cluster_kind`** — which unit the bootstrap resampled. `tile-boot` means whole MGRS tiles
  (the defensible choice); `patch-boot` means individual patches, used when the split carries
  no tile identifier. A result computed with `patch-boot` on data whose test patches share
  tiles has an **anti-conservative** interval, and the code says so in the file.
- **`protocol_warning`** — set when a checkpoint directory and a data directory disagree
  about whether the split is spatially disjoint (e.g. patch-trained weights scored on a
  group-disjoint test set). If this field is present, the number is not interpretable as a
  leakage-free result. It exists because we shipped exactly that mistake once.

## Reproducing the pair of tables that matter most

```bash
cd supp
bash run_p1_extra.sh gate                       # proves the path works, ~2 min
bash run_p1_extra.sh expH                       # paired inference, patch-level split
bash run_p1_extra.sh expJ                       # split census
bash run_p1_extra.sh expI                       # change-head loss sweep (needs a GPU)
bash run_p1_extra.sh summary                    # one-screen digest of everything above
```

For the leakage-free counterpart of `expH`, both members of every pair must be the
group-disjoint checkpoints:

```bash
CKPT_DIR="$PROJECT_DIR/results/supplementary/expA_grouped/ckpts" \
  bash run_p1_extra.sh expHg
```

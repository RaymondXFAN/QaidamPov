# Split composition

Data dir: `/root/autodl-tmp/QaidamPov/data/processed_dual`

| split | patches | tiles | tile ids |
|---|---|---|---|
| train | 280 | **18** | 1, 2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22 |
| val | 60 | **18** | 1, 2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22 |
| test | 60 | **18** | 1, 2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22 |

Total tiles: **18**  |  tiles appearing in more than one split: **[{'pair': ['train', 'val'], 'tiles': [1, 2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22]}, {'pair': ['test', 'train'], 'tiles': [1, 2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22]}, {'pair': ['test', 'val'], 'tiles': [1, 2, 3, 4, 6, 7, 8, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22]}]**
# EXP-I verdict

DOWNGRADE — best expansion F1 = 0.251; the head is an auxiliary regularizer, not a stability assessment

Action: rename to 'auxiliary change regularizer' in the title/abstract

Decoder of the columns: `expansion F1` is the class that fails today (≈0.25); the threshold for keeping the 'stability assessment' wording is 0.4.

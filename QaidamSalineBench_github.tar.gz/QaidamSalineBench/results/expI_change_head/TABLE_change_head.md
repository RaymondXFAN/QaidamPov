# EXP-I — change-head loss comparison

All configs share encoder, optimiser, seeds and epochs; **only the change-head loss differs**. `ce` reproduces the published recipe.

| config | change macro-F1 | expansion F1 | shrinkage F1 | change acc | static IoU |
|---|---|---|---|---|---|
| ce | 0.5150 ± 0.0103 | **0.251** ± 0.024 | 0.002 ± 0.003 | 0.8401 | 0.8902 |
| focal_g2 | 0.4687 ± 0.0003 | **0.000** ± 0.000 | 0.000 ± 0.000 | 0.9176 | 0.9042 |
| focal_g2_bal | 0.5160 ± 0.0164 | **0.231** ± 0.022 | 0.069 ± 0.032 | 0.8114 | 0.8945 |
| _prior-only_ | 0.1886 | 0.000 | 0.000 | 0.6058 | — |

_per-class support (test set): {'stable non-saline': 338194, 'stable saline': 595512, 'expansion': 30092, 'shrinkage': 19242}_

## Verdict

**DOWNGRADE — best expansion F1 = 0.251; the head is an auxiliary regularizer, not a stability assessment**

Action: rename to 'auxiliary change regularizer' in the title/abstract

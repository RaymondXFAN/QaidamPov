# EXP-H — paired pixel-level inference

Split: **test**  |  models: `cnn_dual_seed123_lam0.3, cnn_dual_seed123_lam0.5, cnn_dual_seed123_lam0.7, cnn_dual_seed123_lam1.0, cnn_dual_seed2024_lam0.3, cnn_dual_seed2024_lam0.5, cnn_dual_seed2024_lam0.7, cnn_dual_seed2024_lam1.0, cnn_dual_seed42_lam0.3, cnn_dual_seed42_lam0.5, cnn_dual_seed42_lam0.7, cnn_dual_seed42_lam1.0, cnn_single_seed123, cnn_single_seed2024, cnn_single_seed42, rf, xgb`  |  clustering: **tile** (60 units)

| comparison | ΔIoU (A−B) | pixel-boot 95% CI | tile-boot 95% CI | McNemar p | n pixels | n units |
|---|---|---|---|---|---|---|
| cnn_dual_seed42_lam1.0 vs cnn_single_seed42 | -0.0069 | [-0.0074, -0.0064] | [-0.0295, +0.0085] | 5.67e-275 | 983040 | 18 |
| cnn_dual_seed42_lam0.3 vs cnn_single_seed42 | +0.0069 | [+0.0065, +0.0074] | [-0.0004, +0.0167] | 1.13e-163 | 983040 | 18 |
| cnn_dual_seed42_lam0.5 vs cnn_single_seed42 | -0.0086 | [-0.0090, -0.0082] | [-0.0163, -0.0027] | 2.15e-311 | 983040 | 18 |
| cnn_dual_seed42_lam0.7 vs cnn_single_seed42 | +0.0022 | [+0.0017, +0.0026] | [-0.0030, +0.0113] | 0.000166 | 983040 | 18 |
| cnn_dual_seed123_lam1.0 vs cnn_single_seed123 | -0.0002 | [-0.0008, +0.0003] | [-0.0151, +0.0158] | 3.81e-17 | 983040 | 18 |
| cnn_dual_seed123_lam0.3 vs cnn_single_seed123 | +0.0020 | [+0.0016, +0.0025] | [-0.0060, +0.0119] | 9.98e-08 | 983040 | 18 |
| cnn_dual_seed123_lam0.5 vs cnn_single_seed123 | +0.0001 | [-0.0005, +0.0007] | [-0.0176, +0.0170] | 5.72e-23 | 983040 | 18 |
| cnn_dual_seed123_lam0.7 vs cnn_single_seed123 | -0.0014 | [-0.0021, -0.0008] | [-0.0221, +0.0160] | 1.04e-54 | 983040 | 18 |
| cnn_dual_seed2024_lam1.0 vs cnn_single_seed2024 | +0.0028 | [+0.0024, +0.0033] | [-0.0015, +0.0083] | 4.97e-41 | 983040 | 18 |
| cnn_dual_seed2024_lam0.3 vs cnn_single_seed2024 | +0.0014 | [+0.0010, +0.0018] | [-0.0049, +0.0070] | 6.73e-14 | 983040 | 18 |
| cnn_dual_seed2024_lam0.5 vs cnn_single_seed2024 | +0.0006 | [+0.0001, +0.0011] | [-0.0137, +0.0116] | 0.00292 | 983040 | 18 |
| cnn_dual_seed2024_lam0.7 vs cnn_single_seed2024 | +0.0042 | [+0.0037, +0.0046] | [+0.0011, +0.0085] | 1.13e-69 | 983040 | 18 |
| rf vs xgb | +0.0079 | [+0.0075, +0.0083] | [+0.0028, +0.0151] | <1e-300 | 983040 | 18 |
| rf vs cnn_dual_seed42_lam1.0 | +0.0320 | [+0.0312, +0.0327] | [+0.0043, +0.0706] | <1e-300 | 983040 | 18 |

## Per-tile paired ΔIoU (a paired test with 60 units, not 3)

- **cnn_dual_seed42_lam1.0 vs cnn_single_seed42**: mean -0.0008 ± 0.0356 (n=18 tiles), range [-0.1037, +0.0655]
- **cnn_dual_seed42_lam0.3 vs cnn_single_seed42**: mean +0.0166 ± 0.0314 (n=18 tiles), range [+0.0000, +0.1211]
- **cnn_dual_seed42_lam0.5 vs cnn_single_seed42**: mean -0.0153 ± 0.0212 (n=18 tiles), range [-0.0649, +0.0002]
- **cnn_dual_seed42_lam0.7 vs cnn_single_seed42**: mean +0.0135 ± 0.0336 (n=18 tiles), range [-0.0094, +0.1266]
- **cnn_dual_seed123_lam1.0 vs cnn_single_seed123**: mean +0.0053 ± 0.0419 (n=18 tiles), range [-0.0589, +0.1105]
- **cnn_dual_seed123_lam0.3 vs cnn_single_seed123**: mean +0.0011 ± 0.0227 (n=18 tiles), range [-0.0566, +0.0556]
- **cnn_dual_seed123_lam0.5 vs cnn_single_seed123**: mean +0.0142 ± 0.0443 (n=18 tiles), range [-0.0949, +0.1072]
- **cnn_dual_seed123_lam0.7 vs cnn_single_seed123**: mean +0.0148 ± 0.0470 (n=18 tiles), range [-0.1022, +0.1187]
- **cnn_dual_seed2024_lam1.0 vs cnn_single_seed2024**: mean +0.0019 ± 0.0185 (n=18 tiles), range [-0.0283, +0.0504]
- **cnn_dual_seed2024_lam0.3 vs cnn_single_seed2024**: mean +0.0014 ± 0.0187 (n=18 tiles), range [-0.0517, +0.0395]
- **cnn_dual_seed2024_lam0.5 vs cnn_single_seed2024**: mean -0.0025 ± 0.0622 (n=18 tiles), range [-0.1603, +0.1327]
- **cnn_dual_seed2024_lam0.7 vs cnn_single_seed2024**: mean +0.0085 ± 0.0231 (n=18 tiles), range [-0.0407, +0.0635]
- **rf vs xgb**: mean +0.0118 ± 0.0202 (n=18 tiles), range [-0.0148, +0.0709]
- **rf vs cnn_dual_seed42_lam1.0**: mean +0.0728 ± 0.0995 (n=18 tiles), range [-0.0001, +0.3222]

## How to read this

- If the **tile-bootstrap 95% CI contains 0**, the difference is not resolvable at the spatial scale that matters — a *precise* null, not an underpowered one.
- The **pixel** bootstrap assumes independent pixels and is therefore anti-conservative; it is reported because it was requested, but the tile-level CI is the one to quote.
- **McNemar tests accuracy, not IoU.** At ~1e6 pixels even a trivial accuracy difference can reach significance; always read it beside ΔIoU and its CI, never on its own.
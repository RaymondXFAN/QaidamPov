# EXP-H — paired pixel-level inference

Split: **test**  |  models: `cnn_dual_seed123_lam0.3, cnn_dual_seed123_lam0.5, cnn_dual_seed123_lam0.7, cnn_dual_seed123_lam1.0, cnn_dual_seed2024_lam0.3, cnn_dual_seed2024_lam0.5, cnn_dual_seed2024_lam0.7, cnn_dual_seed2024_lam1.0, cnn_dual_seed42_lam0.3, cnn_dual_seed42_lam0.5, cnn_dual_seed42_lam0.7, cnn_dual_seed42_lam1.0, cnn_single_seed123, cnn_single_seed2024, cnn_single_seed42, rf, xgb`  |  clustering: **patch** (66 units)

| comparison | ΔIoU (A−B) | pixel-boot 95% CI | patch-boot 95% CI | McNemar p | n pixels | n units |
|---|---|---|---|---|---|---|
| cnn_dual_seed42_lam1.0 vs cnn_single_seed42 | -0.0523 | [-0.0530, -0.0517] | [-0.0766, -0.0303] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed42_lam0.3 vs cnn_single_seed42 | -0.0553 | [-0.0560, -0.0546] | [-0.0771, -0.0349] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed42_lam0.5 vs cnn_single_seed42 | -0.0396 | [-0.0401, -0.0390] | [-0.0597, -0.0213] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed42_lam0.7 vs cnn_single_seed42 | -0.0626 | [-0.0633, -0.0620] | [-0.0904, -0.0344] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed123_lam1.0 vs cnn_single_seed123 | +0.0109 | [+0.0104, +0.0114] | [-0.0032, +0.0244] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed123_lam0.3 vs cnn_single_seed123 | -0.0045 | [-0.0049, -0.0042] | [-0.0118, +0.0011] | 2.29e-52 | 1081344 | 66 |
| cnn_dual_seed123_lam0.5 vs cnn_single_seed123 | +0.0063 | [+0.0058, +0.0067] | [-0.0067, +0.0188] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed123_lam0.7 vs cnn_single_seed123 | +0.0481 | [+0.0475, +0.0487] | [+0.0205, +0.0741] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed2024_lam1.0 vs cnn_single_seed2024 | -0.0333 | [-0.0337, -0.0329] | [-0.0492, -0.0187] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed2024_lam0.3 vs cnn_single_seed2024 | -0.0251 | [-0.0255, -0.0247] | [-0.0381, -0.0127] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed2024_lam0.5 vs cnn_single_seed2024 | -0.0269 | [-0.0273, -0.0265] | [-0.0400, -0.0146] | <1e-300 | 1081344 | 66 |
| cnn_dual_seed2024_lam0.7 vs cnn_single_seed2024 | -0.0220 | [-0.0223, -0.0216] | [-0.0336, -0.0113] | <1e-300 | 1081344 | 66 |
| rf vs xgb | +0.0025 | [+0.0021, +0.0028] | [+0.0007, +0.0043] | 1.9e-40 | 1081344 | 66 |
| rf vs cnn_dual_seed42_lam1.0 | +0.0271 | [+0.0265, +0.0279] | [+0.0096, +0.0450] | <1e-300 | 1081344 | 66 |

## Per-patch paired ΔIoU (a paired test with 66 units, not 3)

- **cnn_dual_seed42_lam1.0 vs cnn_single_seed42**: mean -0.0529 ± 0.0878 (n=66 patchs), range [-0.3346, +0.0598]
- **cnn_dual_seed42_lam0.3 vs cnn_single_seed42**: mean -0.0447 ± 0.0719 (n=66 patchs), range [-0.2962, +0.0408]
- **cnn_dual_seed42_lam0.5 vs cnn_single_seed42**: mean -0.0356 ± 0.0651 (n=66 patchs), range [-0.3157, +0.0554]
- **cnn_dual_seed42_lam0.7 vs cnn_single_seed42**: mean -0.0285 ± 0.0697 (n=66 patchs), range [-0.2757, +0.0759]
- **cnn_dual_seed123_lam1.0 vs cnn_single_seed123**: mean -0.0445 ± 0.1318 (n=66 patchs), range [-0.5014, +0.1185]
- **cnn_dual_seed123_lam0.3 vs cnn_single_seed123**: mean -0.0294 ± 0.0811 (n=66 patchs), range [-0.3478, +0.0549]
- **cnn_dual_seed123_lam0.5 vs cnn_single_seed123**: mean -0.0454 ± 0.1213 (n=66 patchs), range [-0.4024, +0.1179]
- **cnn_dual_seed123_lam0.7 vs cnn_single_seed123**: mean -0.0156 ± 0.1075 (n=66 patchs), range [-0.3638, +0.2439]
- **cnn_dual_seed2024_lam1.0 vs cnn_single_seed2024**: mean -0.0197 ± 0.0418 (n=66 patchs), range [-0.1972, +0.0332]
- **cnn_dual_seed2024_lam0.3 vs cnn_single_seed2024**: mean -0.0148 ± 0.0391 (n=66 patchs), range [-0.1746, +0.0750]
- **cnn_dual_seed2024_lam0.5 vs cnn_single_seed2024**: mean -0.0164 ± 0.0395 (n=66 patchs), range [-0.2002, +0.0532]
- **cnn_dual_seed2024_lam0.7 vs cnn_single_seed2024**: mean -0.0178 ± 0.0412 (n=66 patchs), range [-0.1683, +0.0412]
- **rf vs xgb**: mean +0.0029 ± 0.0076 (n=66 patchs), range [-0.0129, +0.0316]
- **rf vs cnn_dual_seed42_lam1.0**: mean +0.0369 ± 0.0852 (n=66 patchs), range [-0.1420, +0.2867]

## How to read this

- If the **tile-bootstrap 95% CI contains 0**, the difference is not resolvable at the spatial scale that matters — a *precise* null, not an underpowered one.
- The **pixel** bootstrap assumes independent pixels and is therefore anti-conservative; it is reported because it was requested, but the tile-level CI is the one to quote.
- **McNemar tests accuracy, not IoU.** At ~1e6 pixels even a trivial accuracy difference can reach significance; always read it beside ΔIoU and its CI, never on its own.
#!/usr/bin/env python3
"""Query AWS Earth Search STAC for the Sentinel-2 tiles behind our dataset.

Reproduces the rebuild/preprocessing footprint: bbox 90-100E / 36-39N,
2020 growing season, cloud < 15%, one lowest-cloud scene per MGRS tile.
Outputs geo/tiles.json  (tile id -> representative footprint polygon + cloud).
"""
import json, os, urllib.request

STAC = "https://earth-search.aws.element84.com/v1/search"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tiles.json")

BODY = {
    "collections": ["sentinel-2-l2a"],
    "bbox": [90, 36, 100, 39],
    "datetime": "2020-06-01T00:00:00Z/2020-09-30T23:59:59Z",
    "query": {"eo:cloud_cover": {"lt": 15}},
    "limit": 200,
    "fields": {"include": ["id", "properties", "geometry"],
               "exclude": ["assets", "links"]},
}


def main():
    req = urllib.request.Request(
        STAC, data=json.dumps(BODY).encode(),
        headers={"Content-Type": "application/json", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        d = json.loads(r.read())
    feats = d.get("features", [])
    print("returned items:", len(feats))

    tiles = {}
    for f in feats:
        p = f["properties"]
        tid = p.get("grid:code") or p.get("sentinel:grid_square") or f["id"]
        cc = p.get("eo:cloud_cover", 999)
        if tid not in tiles or cc < tiles[tid]["cloud"]:
            tiles[tid] = {"cloud": cc, "datetime": p.get("datetime"),
                          "tile_id": p.get("sentinel:utm_zone", "") and tid,
                          "geometry": f.get("geometry")}
        tiles[tid].setdefault("geometry", f.get("geometry"))

    out = {"bbox": [90, 36, 100, 39], "n_items": len(feats),
           "n_tiles": len(tiles), "tiles": tiles}
    with open(OUT, "w") as fh:
        json.dump(out, fh)
    print(f"distinct MGRS tiles: {len(tiles)} -> {OUT}")
    for t, v in sorted(tiles.items()):
        print(f"   {t:12s} cloud={v['cloud']:.1f}  {str(v['datetime'])[:10]}")


if __name__ == "__main__":
    main()

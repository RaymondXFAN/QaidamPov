#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fig. 1 — Study area and workflow (simple, self-contained).

  (a) China locator  : provinces, Qinghai highlighted, red box = study window
  (b) Study area     : 90-100.5E / 36-39N with lat/lon grid, Qaidam Basin corridor,
                       ESA WorldCover 3-deg tile grid, towns, north arrow, scale bar
  (c) Workflow       : data -> patches -> models -> two evaluation protocols

Scheme: "burgundy silver". Times-style serif, >=12 pt. PDF + PNG@300dpi.
    python make_fig1.py
"""
import json
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as _fm
import numpy as np
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon as MplPoly, Rectangle

# pick the best available Times-like serif (Times on your box, Liberation Serif on Linux)
_PREF = ["Times New Roman", "Nimbus Roman", "Liberation Serif", "TeX Gyre Termes",
         "DejaVu Serif"]
_AVAIL = {f.name for f in _fm.fontManager.ttflist}
FONT_FAMILY = [f for f in _PREF if f in _AVAIL] or ["DejaVu Serif"]
print("[font]", FONT_FAMILY[0])

HERE = os.path.dirname(os.path.abspath(__file__))
GEO = os.path.join(HERE, "geo")

# --------------------------------------------------------------------- theme
WINE, SILVER, WINE2, SLATE = "#7B2233", "#B4B6BA", "#9E4A5C", "#6E7377"
PINK, PINKL, TXT, GRID = "#C08A96", "#D9AEB6", "#3A3A3A", "#DCDEE0"

matplotlib.rcParams.update({
    "font.family": FONT_FAMILY,
    "font.size": 12, "axes.labelsize": 12, "xtick.labelsize": 12,
    "ytick.labelsize": 12, "legend.fontsize": 12,
    "axes.edgecolor": TXT, "axes.labelcolor": TXT, "text.color": TXT,
    "xtick.color": TXT, "ytick.color": TXT,
    "figure.dpi": 120, "savefig.dpi": 300, "mathtext.fontset": "stix",
})

ASPECT = 1.26  # ~1/cos(37.5 deg) for an equirectangular look


# --------------------------------------------------------------------- helpers
def iter_polys(geom):
    if geom is None:
        return
    t, c = geom["type"], geom["coordinates"]
    if t == "Polygon":
        for ring in c:
            yield ring
    elif t == "MultiPolygon":
        for poly in c:
            for ring in poly:
                yield ring


def draw_rings(ax, rings, **kw):
    for ring in rings:
        a = np.asarray(ring, float)
        if a.shape[0] < 3:
            continue
        ax.add_patch(MplPoly(a, closed=True, **kw))


def despine(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


def panel_label(ax, s, x=-0.06, y=1.09, size=14):
    ax.text(x, y, s, transform=ax.transAxes, size=size, weight="bold",
            va="bottom", ha="left", color=TXT)


def overlap_check(fig, name):
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    items = []
    for k, ax in enumerate(fig.axes):
        items += [(k, t) for t in ax.texts if t.get_text().strip()]
        items += [(k, t) for t in list(ax.get_xticklabels()) + list(ax.get_yticklabels())
                  if t.get_text().strip()]
    bad = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            (ki, ti), (kj, tj) = items[i], items[j]
            if ki != kj:
                continue
            if ti.get_window_extent(r).overlaps(tj.get_window_extent(r)):
                bad.append((ki, ti.get_text()[:16], tj.get_text()[:16]))
    print(f"[check] {name}: {len(items)} texts, {len(bad)} overlaps"
          + ("" if not bad else f" -> {bad[:8]}"))
    return bad


def save_fig(fig, name):
    out = []
    for fmt in ("pdf", "png"):
        p = os.path.join(HERE, f"{name}.{fmt}")
        fig.savefig(p, format=fmt, bbox_inches="tight", pad_inches=0.06, dpi=300)
        out.append(p)
    print("[save]", "  |  ".join(out))


# --------------------------------------------------------------------- data
def load_geo():
    prov = json.load(open(os.path.join(GEO, "china_provinces.json")))
    qh = json.load(open(os.path.join(GEO, "qinghai.json")))
    return prov, qh


# Approximate Qaidam Basin outline (hand-digitised; labelled "approx." in-figure)
BASIN = [
    (90.25, 38.05), (91.30, 38.75), (92.80, 39.05), (94.30, 38.95), (95.80, 38.75),
    (97.10, 38.35), (98.20, 37.60), (98.75, 36.95), (98.30, 36.45), (97.20, 36.15),
    (95.80, 35.95), (94.30, 35.85), (92.80, 35.95), (91.50, 36.30), (90.60, 36.85),
    (90.15, 37.50),
]

TOWNS = [
    ("Golmud",    94.90, 36.40),
    ("Delingha",  97.36, 37.37),
    ("Da Qaidam", 95.28, 37.85),
    ("Lenghu",    93.10, 38.73),
    ("Mangya",    90.86, 38.25),
    ("Dulan",     98.09, 36.30),
]

LAKES = [(95.30, 36.90, 0.75, 0.22), (96.90, 37.15, 0.35, 0.16)]


# --------------------------------------------------------------------- (a)
def panel_china(ax, prov):
    for ft in prov["features"]:
        nm = ft["properties"].get("name", "")
        rings = list(iter_polys(ft.get("geometry")))
        if nm.startswith("青海"):
            draw_rings(ax, rings, facecolor=PINKL, edgecolor=WINE, lw=0.9, zorder=3)
        elif "南海" in nm:
            draw_rings(ax, rings, facecolor="#EDEEF0", edgecolor=SILVER, lw=0.4, zorder=2)
        else:
            draw_rings(ax, rings, facecolor="#E9EAEC", edgecolor="white", lw=0.6, zorder=2)

    ax.add_patch(Rectangle((90, 36), 10.5, 3, fill=False, edgecolor=WINE,
                           lw=1.6, zorder=6))
    ax.annotate("Qaidam Basin\nstudy area", xy=(100.2, 37.2), xytext=(117.5, 29.5),
                fontsize=12, color=WINE, ha="left", va="center",
                arrowprops=dict(arrowstyle="-", color=WINE, lw=1.1))
    ax.set_xlim(72, 136); ax.set_ylim(17, 55)
    ax.set_aspect(1.22)
    ax.set_xticks([75, 90, 105, 120, 135])
    ax.set_yticks([20, 30, 40, 50])
    ax.set_xticklabels([f"{t}°E" for t in (75, 90, 105, 120, 135)])
    ax.set_yticklabels([f"{t}°N" for t in (20, 30, 40, 50)])
    ax.tick_params(labelsize=11)
    ax.set_title("China", fontsize=13, pad=12)
    panel_label(ax, "(a)", x=-0.075)


# --------------------------------------------------------------------- (b)
def panel_map(ax, qh):
    ax.set_aspect(ASPECT)

    for ft in qh["features"]:
        draw_rings(ax, list(iter_polys(ft.get("geometry"))),
                   facecolor="none", edgecolor="#CFD1D5", lw=0.7, zorder=2)

    for x, y, w, h in LAKES:
        ax.add_patch(MplPoly([(x - w / 2, y), (x, y + h / 2), (x + w / 2, y),
                              (x, y - h / 2)], closed=True, facecolor=SILVER,
                             edgecolor=SLATE, lw=0.8, zorder=3))
    ax.text(95.98, 36.90, "Qarhan", fontsize=12, color=SLATE, ha="left", va="center",
            zorder=9)

    ax.add_patch(MplPoly(BASIN, closed=True, facecolor=PINKL, alpha=0.55,
                         edgecolor=WINE, lw=1.6, zorder=4))
    ax.text(94.40, 37.58, "Qaidam Basin", fontsize=15, color=WINE, weight="bold",
            ha="center", va="center", alpha=0.95, zorder=5)
    ax.text(94.40, 37.15, "(saline corridor)", fontsize=12, color=WINE,
            ha="center", va="center", alpha=0.9, zorder=5)

    for x in (93, 96, 99):
        ax.plot([x, x], [36, 39], ls=(0, (5, 4)), lw=0.9, color=SLATE, zorder=1.5)

    for nm, x, y in TOWNS:
        ax.plot(x, y, "o", ms=5, mfc="white", mec=WINE, mew=1.5, zorder=7)
        ax.text(x + 0.12, y, nm, fontsize=12, color=TXT, ha="left", va="center", zorder=7)

    ax.add_patch(Rectangle((90, 36), 10.5, 3, fill=False, edgecolor=WINE,
                           lw=1.4, ls="--", zorder=6))

    ax.set_xlim(90, 100.5); ax.set_ylim(36, 39)
    ax.set_xticks([90, 91.5, 93, 94.5, 96, 97.5, 99, 100.5])
    ax.set_yticks([36, 36.5, 37, 37.5, 38, 38.5, 39])
    ax.set_xticklabels([f"{t:g}°E" for t in ax.get_xticks()])
    ax.set_yticklabels([f"{t:g}°N" for t in ax.get_yticks()])
    ax.tick_params(labelsize=11)
    ax.grid(color=GRID, lw=0.5, alpha=0.7, zorder=0)
    despine(ax)
    ax.set_title("Qaidam Basin study area", fontsize=13, pad=12)

    ax.annotate("", xy=(99.85, 38.93), xytext=(99.85, 38.50),
                arrowprops=dict(arrowstyle="-|>", color=TXT, lw=1.6), zorder=9)
    ax.text(99.85, 38.99, "N", fontsize=12, ha="center", va="bottom", color=TXT, zorder=9)

    x0, y0, L = 90.35, 36.14, 100 / (111.32 * np.cos(np.radians(37.5)))
    ax.plot([x0, x0 + L], [y0, y0], color=TXT, lw=2.4, solid_capstyle="butt", zorder=9)
    for xx in (x0, x0 + L):
        ax.plot([xx, xx], [y0 - 0.035, y0 + 0.035], color=TXT, lw=1.6, zorder=9)
    ax.text(x0 + L / 2, y0 + 0.055, "100 km", fontsize=12, ha="center", va="bottom")

    ax.text(100.42, 38.55, "18 Sentinel-2 tiles\n400 patches (280/60/60)",
            fontsize=12, ha="right", va="top", color=TXT, zorder=9)

    panel_label(ax, "(b)", x=-0.02)


# --------------------------------------------------------------------- (c)
def panel_flow(fig, cell):
    ax = fig.add_subplot(cell)
    ax.set_xlim(-0.14, 12.14); ax.set_ylim(0, 2.30); ax.axis("off")

    steps = [
        ("Sentinel-2 L2A", "6 bands · 10 m"),
        ("ESA WorldCover", "class 60 → saline"),
        ("Patches", "128×128 · stride 64"),
        ("Models", "RF · CNN · U-Net"),
        ("Evaluation", "2 protocols → IoU, κ"),
    ]
    n = len(steps); gap = 0.30; w = (12 - gap * (n - 1)) / n; h = 1.15; y = 0.52
    for i, (t, s) in enumerate(steps):
        x = i * (w + gap)
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                                    boxstyle="round,pad=0.04,rounding_size=0.10",
                                    linewidth=1.3, edgecolor=WINE,
                                    facecolor=PINKL if i % 2 == 0 else "#EDEEF0"))
        ax.text(x + w / 2, y + h * 0.66, t, ha="center", va="center", fontsize=12.5,
                weight="bold", color=WINE if i % 2 == 0 else TXT)
        ax.text(x + w / 2, y + h * 0.27, s, ha="center", va="center", fontsize=12,
                color=TXT)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + w + 0.04, y + h / 2),
                                         (x + w + gap - 0.04, y + h / 2),
                                         arrowstyle="-|>", mutation_scale=13,
                                         linewidth=1.4, color=SLATE))
    panel_label(ax, "(c)", x=0.004, y=0.86)
    return ax


# --------------------------------------------------------------------- main
def main():
    prov, qh = load_geo()
    fig = plt.figure(figsize=(12.0, 7.0))
    gs = fig.add_gridspec(2, 3, height_ratios=[3.0, 0.95], hspace=0.34, wspace=0.24)

    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1:])
    panel_china(ax_a, prov)
    panel_map(ax_b, qh)
    panel_flow(fig, gs[1, :])

    overlap_check(fig, "fig1")
    save_fig(fig, "fig1_study_area")
    print("done")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QaidamPov — regenerate the paper figures (self-contained; no external skill needed).

Scheme: "burgundy silver" (deep wine-red + silver greys), Times-style serif, >=12 pt.
Outputs PDF (vector) + PNG (300 dpi) next to this file.

    python make_figures.py

Figures
    fig2_architecture   dual-task CNN block diagram
    fig3_model_comparison   static saline IoU, patch-level vs leakage-free tile-level
    fig4_lambda_ablation    (a) IoU vs lambda   (b) paired ΔIoU with 95% CI
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as _fm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.colors import to_rgba
import numpy as np

# pick the best available Times-like serif
_PREF = ["Times New Roman", "Nimbus Roman", "Liberation Serif", "TeX Gyre Termes",
         "DejaVu Serif"]
_AVAIL = {f.name for f in _fm.fontManager.ttflist}
FONT_FAMILY = [f for f in _PREF if f in _AVAIL] or ["DejaVu Serif"]
print("[font]", FONT_FAMILY[0])

OUT = os.path.dirname(os.path.abspath(__file__))
PNG_DPI = 300

# --------------------------------------------------------------------------
# theme (vendored): Times-style serif, base 12 pt, burgundy-silver palette
# --------------------------------------------------------------------------
_PALETTE = {
    "main": ["#7B2233", "#B4B6BA", "#9E4A5C", "#6E7377",
             "#C08A96", "#8E9196", "#4A1620", "#D5D7DA"],
    "light": ["#D9AEB6", "#DCDEE0", "#E3C3C9", "#CFD1D5",
              "#EBD8DC", "#E0E2E5", "#C9A2AA", "#EDEEF0"],
    "text": "#3A3A3A",
    "grid": "#D9D9DE",
}
C = _PALETTE["main"]
TXT = _PALETTE["text"]
GRID = _PALETTE["grid"]

matplotlib.rcParams.update({
    "font.family": FONT_FAMILY,
    "font.size": 12,
    "axes.titlesize": 14, "axes.labelsize": 13,
    "xtick.labelsize": 12, "ytick.labelsize": 12, "legend.fontsize": 12,
    "axes.edgecolor": TXT, "axes.labelcolor": TXT, "text.color": TXT,
    "xtick.color": TXT, "ytick.color": TXT,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.7, "grid.alpha": 0.9,
    "axes.axisbelow": True, "figure.dpi": 120, "savefig.dpi": PNG_DPI,
    "mathtext.fontset": "stix",
})


def despine(ax, which=("top", "right")):
    for s in which:
        ax.spines[s].set_visible(False)


def soft_legend(ax, **kw):
    kw.setdefault("frameon", True)
    kw.setdefault("framealpha", 0.9)
    kw.setdefault("edgecolor", GRID)
    return ax.legend(**kw)


def panel_label(ax, label, x=-0.14, y=1.05, size=14):
    return ax.text(x, y, label, transform=ax.transAxes, size=size,
                   weight="bold", va="bottom", ha="left", color=TXT)


def save_fig(fig, name, outdir=OUT, dpi=PNG_DPI):
    os.makedirs(outdir, exist_ok=True)
    paths = []
    for fmt in ("pdf", "png"):
        p = os.path.join(outdir, f"{name}.{fmt}")
        fig.savefig(p, format=fmt, bbox_inches="tight", pad_inches=0.05, dpi=dpi)
        paths.append(p)
    print("[save_fig]", "  |  ".join(paths))
    return paths


def overlap_check(fig, name):
    """Programmatic bbox check: catches label collisions that 70-dpi previews hide."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    items = []
    for ax in fig.axes:
        items += [t for t in ax.texts if t.get_text().strip()]
        items += [t for t in list(ax.get_xticklabels()) + list(ax.get_yticklabels())
                  if t.get_text().strip()]
    bad = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            if items[i].axes is not items[j].axes:
                continue
            if items[i].get_window_extent(r).overlaps(items[j].get_window_extent(r)):
                bad.append((items[i].get_text()[:18], items[j].get_text()[:18]))
    print(f"[check] {name}: {len(items)} text items, {len(bad)} overlaps"
          + ("" if not bad else f" -> {bad[:5]}"))


# ---------------------------------------------------------------------------
def fig2():
    fig, ax = plt.subplots(figsize=(7.4, 5.2))
    ax.set_xlim(0, 10.2); ax.set_ylim(0, 6.9); ax.axis("off")

    def box(x, y, w, h, title, sub="", fc="#FFFFFF", ec=None, tc=None):
        ax.add_patch(FancyBboxPatch((x, y), w, h,
                                    boxstyle="round,pad=0.05,rounding_size=0.09",
                                    linewidth=1.3, edgecolor=ec or C[0], facecolor=fc))
        c = tc or TXT
        if sub:
            ax.text(x + w / 2, y + h * 0.67, title, ha="center", va="center",
                    fontsize=12, color=c, weight="bold")
            ax.text(x + w / 2, y + h * 0.27, sub, ha="center", va="center", fontsize=11, color=c)
        else:
            ax.text(x + w / 2, y + h / 2, title, ha="center", va="center",
                    fontsize=12, weight="bold", color=c)

    def arrow(x1, y1, x2, y2):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                     mutation_scale=13, linewidth=1.4, color=TXT,
                                     shrinkA=1, shrinkB=1))

    YC = 5.55
    box(0.05, 5.05, 1.60, 1.00, "Sentinel-2", "6×128×128", fc=C[1])
    arrow(1.68, YC, 2.10, YC)
    box(2.10, 5.05, 1.48, 1.00, "Conv 64", "128×128")
    arrow(3.61, YC, 4.03, YC)
    box(4.03, 5.05, 1.48, 1.00, "Conv 128", "64×64")
    arrow(5.54, YC, 5.96, YC)
    box(5.96, 5.05, 1.48, 1.00, "Conv 256", "32×32")
    ax.text(9.05, 5.95, "shared encoder\n(2× max-pool)", ha="center", va="center",
            fontsize=11, color=C[0])

    ax.plot([6.70, 6.70], [5.05, 4.20], color=TXT, lw=1.3)
    arrow(6.70, 4.20, 8.45, 4.05)
    arrow(6.70, 4.20, 8.45, 2.10)
    box(8.45, 3.60, 1.55, 1.00, "Static head", "↑/↓ Conv, 1×1", fc=C[2], ec=C[2], tc="#FFFFFF")
    box(8.45, 1.75, 1.55, 1.00, "Change head", "↑/↓ Conv, 1×1", fc=C[4], ec=C[4], tc="#FFFFFF")
    ax.text(9.22, 3.47, "2 classes\n(saline / non-saline)", ha="center", va="top", fontsize=11)
    ax.text(9.22, 1.62, "4 classes\n(stability 0–3)", ha="center", va="top", fontsize=11)

    ax.text(0.05, 1.18, "Head detail:", fontsize=11, weight="bold", color=C[0])
    xs = [0.05, 2.05, 4.05, 6.05]
    for i, (t, s) in enumerate([("Up ×2", "→64×64"), ("Conv 128", "3×3"),
                                ("Up ×2", "→128×128"), ("Conv 64 + 1×1", "→ H×W")]):
        box(xs[i], 0.14, 1.72, 0.86, t, s, fc="#FFFFFF", ec=C[2])
        if i < 3:
            arrow(xs[i] + 1.77, 0.57, xs[i] + 1.98, 0.57)

    overlap_check(fig, "fig2")
    save_fig(fig, "fig2_architecture")


# ---------------------------------------------------------------------------
def fig3():
    models = ["Random\nForest", "XGBoost", "Prithvi-EO\n+ LoRA", "CNN\n(single)",
              "U-Net", "Dual-task\nCNN"]
    patch = [0.926, 0.920, 0.895, 0.902, 0.911, 0.900]
    pe = [0.000, 0.000, 0.007, 0.001, 0.001, 0.005]
    tile = [0.869, 0.859, 0.856, 0.825, 0.806, 0.800]
    te = [0.000, 0.000, 0.013, 0.045, 0.012, 0.023]
    cols = [C[0], C[2], C[6], C[5], C[3], C[4]]

    fig, ax = plt.subplots(figsize=(7.2, 4.3))
    x = np.arange(len(models)); w = 0.38
    ax.bar(x - w / 2, patch, w, yerr=pe, capsize=3, color=cols, edgecolor=cols,
           linewidth=1.0, label="Patch-level (conventional)", zorder=3,
           error_kw=dict(ecolor=TXT, lw=1.1))
    ax.bar(x + w / 2, tile, w, yerr=te, capsize=3,
           color=[to_rgba(c, 0.30) for c in cols], edgecolor=cols, linewidth=1.0,
           hatch="///", label="Tile-level (leakage-free)", zorder=3,
           error_kw=dict(ecolor=TXT, lw=1.1))
    for xi, (p, t) in enumerate(zip(patch, tile)):
        ax.text(xi - w / 2, p + pe[xi] + 0.004, f"{p:.3f}", ha="center", va="bottom", fontsize=11)
        ax.text(xi + w / 2, t + te[xi] + 0.004, f"{t:.3f}", ha="center", va="bottom", fontsize=11)
        ax.annotate(f"$\\Delta$ = {t - p:+.3f}", (xi, max(p, t) + 0.030),
                    ha="center", va="bottom", fontsize=11, color=C[0])
    ax.set_ylim(0.75, 0.995)
    ax.set_ylabel("IoU (saline class)")
    ax.set_xticks(x); ax.set_xticklabels(models)
    despine(ax); soft_legend(ax, loc="lower left")
    overlap_check(fig, "fig3")
    save_fig(fig, "fig3_model_comparison")


# ---------------------------------------------------------------------------
def fig4():
    lam = np.array([0.3, 0.5, 0.7, 1.0])
    iou = np.array([0.905, 0.899, 0.903, 0.900])
    err = np.array([0.0035, 0.0047, 0.0028, 0.0045])
    single = 0.9016
    delta = np.array([+0.0035, -0.0026, +0.0016, -0.0014])
    lo = np.array([-0.0041, -0.0155, -0.0054, -0.0138])
    hi = np.array([+0.0110, +0.0102, +0.0087, +0.0110])
    pv = np.array([0.186, 0.469, 0.425, 0.669])

    fig, axes = plt.subplots(1, 2, figsize=(7.4, 3.5))

    ax = axes[0]
    ax.axhline(single, ls="--", lw=1.4, color=C[3], label=f"single-task = {single:.3f}")
    ax.errorbar(lam, iou, yerr=err, marker="o", ms=7, lw=1.8, capsize=4,
                color=C[0], ecolor=C[2], mfc="white", mew=1.6, zorder=3)
    for a, b in zip(lam, iou):
        ax.text(a, b + 0.0035, f"{b:.3f}", ha="center", va="bottom", fontsize=11, color=C[0])
    ax.set_xlabel(r"change-task loss weight $\lambda$")
    ax.set_ylabel("IoU (saline class)")
    ax.set_xticks(lam); ax.set_ylim(0.888, 0.914)
    despine(ax); soft_legend(ax, loc="lower right"); panel_label(ax, "(a)")

    ax = axes[1]
    ax.axhline(0.0, ls="-", lw=1.0, color=GRID)
    ax.errorbar(lam, delta, yerr=np.vstack([delta - lo, hi - delta]),
                fmt="none", ecolor=C[2], capsize=4, lw=1.4)
    ax.scatter(lam, delta, s=70, color=[C[0] if dd > 0 else C[4] for dd in delta],
               zorder=3, edgecolor="white", linewidth=1.2)
    for a, dd, p in zip(lam, delta, pv):
        ax.text(a, dd + (0.006 if dd >= 0 else -0.006), f"p={p:.3f}",
                ha="center", va="bottom" if dd >= 0 else "top", fontsize=11, color=TXT)
    ax.set_xlabel(r"change-task loss weight $\lambda$")
    ax.set_ylabel(r"paired $\Delta$IoU (dual $-$ single)")
    ax.set_xticks(lam); ax.set_ylim(-0.030, 0.028)
    despine(ax); panel_label(ax, "(b)")

    fig.tight_layout()
    overlap_check(fig, "fig4")
    save_fig(fig, "fig4_lambda_ablation")


if __name__ == "__main__":
    fig2(); fig3(); fig4()
    print("done ->", OUT)

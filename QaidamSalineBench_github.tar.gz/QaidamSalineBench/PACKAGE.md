# PACKAGE.md — how to build the release tarball

**Goal:** one tarball containing *all the code* (data reconstruction, experiments,
figures), the *key intermediate artifacts*, and *no manuscript material*.

## What goes in, what stays out

| In ✅ | Out ❌ (why) |
|---|---|
| `rebuild/` — dataset reconstruction (code) | `*.npy` raw tensors (~250 MB) — regenerate or Release |
| `supp/` — seven experiments + runners + selftests | `*.pt / *.pth` checkpoints — regenerate by rerunning |
| `figures/make_figures.py` + rendered PDF/PNG | `data/`, `rebuild_out/` — regenerable |
| `results/supplementary/**/*.json`, `TABLE_*.md` | any manuscript: `*.docx`, `MANUSCRIPT_*.md`, |
| `README.md`, `DEPLOY.md`, `PACKAGE.md`, `requirements.txt`, `.gitignore` | `apply_tranche*.py`, `CHANGELOG_tranche*.md`, `*_dump.txt` |
| `patch_tiles.npy`, `dataset_card.json` (small, key) | `__pycache__`, logs |

> `results/supplementary/**/*.npy` (the expanded `data_grouped/` arrays) are excluded by
> the `--exclude='*.npy'` rule below; the JSON/Markdown tables are what you cite, so that
> is intentional.

## Build it (run **on the server**, from the project root)

```bash
cd /root/autodl-tmp
tar -czf QaidamPov_code.tar.gz \
  --exclude='__pycache__' --exclude='*.pyc' \
  --exclude='*.npy' --exclude='*.pt' --exclude='*.pth' \
  --exclude='./QaidamPov/data' --exclude='./QaidamPov/rebuild_out' \
  --exclude='./QaidamPov/logs' --exclude='*.log' \
  --exclude='./QaidamPov/original' \
  --exclude='*.docx' \
  --exclude='./QaidamPov/apply_tranche*.py' \
  --exclude='./QaidamPov/CHANGELOG_tranche*.md' \
  --exclude='./QaidamPov/MANUSCRIPT_*.md' \
  --exclude='./QaidamPov/REFACTOR_BLUEPRINT_*.md' \
  --exclude='./QaidamPov/tranche*_dump.txt' \
  --exclude='./QaidamPov/full_dump.txt' --exclude='./QaidamPov/index.txt' \
  --exclude='./QaidamPov/*.tar.gz' \
  QaidamPov/rebuild QaidamPov/supp QaidamPov/figures \
  QaidamPov/results QaidamPov/README.md QaidamPov/DEPLOY.md \
  QaidamPov/PACKAGE.md QaidamPov/requirements.txt QaidamPov/.gitignore

ls -lh QaidamPov_code.tar.gz
tar -tzf QaidamPov_code.tar.gz | head -40
```

**Add the two small key artifacts** (if present):

```bash
# patch_tiles.npy makes the leakage-free split possible — it is ~3 KB, keep it
tar -rf QaidamPov_code.tar.gz QaidamPov/data/processed_dual/patch_tiles.npy \
    QaidamPov/data/processed_dual/dataset_card.json 2>/dev/null || true
gzip -f QaidamPov_code.tar.gz    # recompress if you used tar -r
```

**Verify no manuscript leaked in:**

```bash
tar -tzf QaidamPov_code.tar.gz | grep -Ei 'docx|tranche|MANUSCRIPT|dump' \
  && echo "❌ manuscript file present — fix the excludes" \
  || echo "✅ clean: no manuscript material"
```

## Push to GitHub

```bash
mkdir -p /tmp/QaidamPov_repo && tar -xzf QaidamPov_code.tar.gz -C /tmp/QaidamPov_repo
cd /tmp/QaidamPov_repo/QaidamPov
git init && git add . && git commit -m "QaidamPov: reproducible, leakage-aware salinization benchmark"
git branch -M main
git remote add origin git@github.com:<you>/QaidamPov.git
git push -u origin main
```

Everything committed stays well under 100 MB because the tensors and checkpoints live
in a **Release** (2 GB/file limit) rather than in git history. To attach the data:

```bash
# on the server, package just the tensors for a Release
cd /root/autodl-tmp/QaidamPov/rebuild_out && tar -czf processed_dual.tar.gz processed_dual
# then upload processed_dual.tar.gz via the GitHub "Releases → Draft a new release" UI
```

## If you only want the figure script

It is fully standalone — copy `figures/` alone and it runs:

```bash
python figures/make_figures.py   # needs only matplotlib + numpy
```

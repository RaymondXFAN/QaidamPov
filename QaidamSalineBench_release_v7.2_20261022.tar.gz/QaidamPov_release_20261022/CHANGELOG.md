# CHANGELOG

All dates are 2026. The manuscript is `manuscript/final/`. Earlier revisions are **not**
shipped in this archive (they run to ~7 MB of Word files for little value, and the
repository has a size budget); they are available from the author on request. The
human-readable diff below is the record of what changed and when.

---

## v7.2 — 22 Oct 2026 (current)

**Presentation and integrity pass.** Triggered by four rounds of self-review plus two
external reads. No new experiments were run: every number here already existed in
`results/`, four of them were simply wrong in the text or in a figure.

### Added
- **Six numbered equations instead of four.** IoU; per-band Fisher ratio; the
  single-band threshold rule; the constant-classifier floor `q/(2−q)`; the Share
  normalisation (moved out of a table note into the method); the exact sign-flip
  permutation p-value.
- **Six figures embedded in the body text** (previously they sat in a caption block at
  the end, which made the draft look figures-free). Figures are now placed at first
  citation and followed by their caption.
- **New Fig. 4**, the sample-size-matched arm C′: a dumbbell of B / C′ / C and a
  decomposition of B → C into spatial source versus the 42 extra patches. This figure
  replaces a paragraph of prose that listed eleven numbers.
- **Appendix Table A1**, the 18-tile inventory: MGRS tile, scene identifier, UTM zone,
  acquisition date, constructed from `data/processed_dual/dataset_card.json`.
- Acquisition window (25 Jul – 30 Sep 2020) and the 15 % scene-level cloud ceiling are
  now stated in §II-B rather than only in the code.

### Fixed
- **Band-11 and band-12 single-threshold IoU were transposed in Fig. 1**, and **B08 was
  missing entirely.** Correct values, from one pass over the same subsamples:
  B04 0.820, B03 0.802, B02 0.796, B12 0.714, B08 0.644, B11 0.644. The band ordering now
  matches the Fisher ordering (Spearman ρ = 0.94), which is a stronger statement than
  the one the figure previously made.
- **Table VI was labelled "tile-level" but its pixel count (983,040 = 60 × 128²) and its
  static IoU (0.894–0.909) both identify the patch-level split.** The caption now says
  so, restores the explicit count of twelve runs (3 seeds × 4 λ), and states that the
  change-head figures are therefore not leakage-free.
- `0.821` → `0.820` throughout (abstract, contribution 2, §IV-A, Fig. 1, conclusion).
  The recomputed value is 0.8202; leaving 0.821 in the text while the figure said 0.820
  was a 0.1 pp mismatch waiting to be caught.
- Figure numbering reordered to first-citation order (the previous draft introduced
  Fig. 1 in §IV-C but Fig. 3 in §IV-A, which IEEE production would flag).

### Changed
- **Em dashes: 75 → 0.** Paired parenthetical dashes became commas or were split into
  separate sentences; eight remaining dashes are empty table cells.
- **Long explanatory parentheses: 13 → 3.** The three kept are parameter lists.
- **Body text: 10,867 → 9,241 words (−15 %).** Removed genuine repetition: the
  replication numbers duplicated between the Table III note and §IV-C, the restatement
  of the 11.61-versus-11.5 comparison, a two-sentence transition between §IV-B and
  §IV-C, and the pixel-wise interval caveat that appeared in both a table note and the
  text.
- Subscripts are now real subscripts (`E_seen` → `E`ₛₑₑₙ, `Δ_seen`, `IoU_const`), not
  underscore characters.
- Figures redrawn in the **Morandi** palette (previously sea-salt/coral), 16 pt minimum,
  600 dpi PNG plus vector PDF, with a programmatic overlap and edge-clipping self-check
  in `save()`.

---

## v7.1 — 21 Oct 2026

Content fixes only; layout and length were explicitly out of scope.

- Fixed six dead citations and nine out-of-order citation numbers; all thirteen
  `[TO ADD]` placeholders replaced by real references with verified DOIs.
- Three-cohort definition of the duplication effect (1.71 on the duplicated patches,
  1.24 rescaled to all 66, 1.30 pooled) stated once, in the Table III note, with the
  sentence "one effect, not three".
- Run-to-run non-reproducibility quantified and disclosed in §III-B: ≈0.2 pp for a
  single run, one 3.9 pp excursion, ≈0.5 pp on an eight-seed mean; the interval tables
  now say explicitly that they cover seed variation only.
- Table I caption corrected (only IoU carries a spread), Table V note explains that the
  permutation distribution uses magnitudes, not sign counts.
- Proxy prevalence (62 %) and the constant-classifier floor (IoU 0.62) added to the
  separability ladder; the ladder now reads 0.62 → 0.820 → 0.890 → 0.927 → 0.910.
- Table A1 was introduced here; the 18 tile identifiers had been requested by a reviewer.

---

## v7 — 21 Oct 2026

Experimental completion: the manuscript moved from "claims" to "measured".

- **Table I recomputed on all eight seeds** for all ten configurations, including the
  runs that underperform.
- **Five-family controlled ablation (EXP-U):** U-Net, plain CNN, Prithvi+LoRA, XGBoost,
  random forest × arms A / B / C × 8 seeds. Duplication effect 1.71 / 2.06 / 2.97 /
  4.40 / 5.19 points, p = 0.0078 in every case.
- **Placebo arm for all five families (EXP-T):** Δ_unseen 3.68–6.88 points. For the two
  pixel-wise ensembles the placebo exceeds the effect it controls, so ignoring it
  overstates duplication by a factor of 2.3–2.6.
- **Replication batch (EXP-W), seeds 1001–1008:** CNN 1.82, Prithvi 3.11, XGB 4.44,
  RF 5.12; ordering preserved. The U-Net is the exception (1.71 → 0.90).
- **Sample-size-matched arm C′ (EXP-V):** 6.54 of the U-Net's 6.71 points are spatial
  source, 0.17 are the extra patches. This also killed an earlier explanation of ours,
  that the pixel-wise neighbourhood term was negative because of the 42 extra patches.
- Seed 777's dual-task run replaced by its re-execution (0.868 → 0.907); the original is
  disclosed in the Table I footnote.

---

## v6 — 20 Oct 2026

- Leakage mechanism separated into duplication and neighbourhood, with the three-stage
  decomposition on a common 66-patch evaluation set (1.24 + 3.68 + 6.71 = 11.63 against
  a measured 11.61).
- Share column introduced and normalised by 48/66; the previous un-normalised share was
  off by a factor of 1.375.
- §V-E rewritten: the dual-task head is neither a liability nor an advantage under the
  leaked protocol; the difference is −0.03 pp patch-level against +2.01 pp tile-level.

## v5.1 – v5.5 — 19–20 Oct 2026

Successive passes over the reviewer reports: contribution list tightened, foundation-model
section made explicit about fine-tuning rather than parameter-efficient tuning, auxiliary
task section reduced to the one nominally significant cell plus its Bonferroni outcome.

## v4 draft — 18 Oct 2026

First complete draft: abstract, five sections, thirteen figures/tables, forty references.
Not shipped. Most of the numbers in it are superseded, and the argument moved far enough
that reading it alongside v7.2 invites confusion rather than insight.

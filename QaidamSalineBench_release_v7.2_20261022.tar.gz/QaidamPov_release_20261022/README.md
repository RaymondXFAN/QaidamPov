# QaidamPov — a leakage-audited salinization benchmark

> **One-line repository title**
> `QaidamSalineBench: a leakage-audited Sentinel-2 benchmark showing that in proxy-labelled salinity mapping the label and the split, not the architecture, set the reported accuracy`

> **One-paragraph repository description**
> A fully public-data, from-scratch benchmark for proxy-labelled soil-salinization
> mapping in the Qaidam Basin, China: 400 Sentinel-2 L2A patches over 18 MGRS tiles,
> labelled by the bare-ground class of ESA WorldCover, evaluated simultaneously under
> the conventional patch-level split and a leakage-free tile-level split. The
> repository rebuilds the dataset from open archives (no credentials), reruns five
> model families under eight seeds, and ships every table as machine-readable JSON.
> Its result is deliberately uncomfortable: a single spectral band with one threshold
> already reaches IoU 0.820 of the 0.927 that the best model achieves, a U-Net's
> reported score is inflated by 11.6 points by patch-level evaluation, only 1.2 of
> those points are caused by exact duplication while 6.7 come from evaluating inside
> the spatial support of the training sample, and multi-task learning provides no
> gain that survives correction. Code, splits, per-seed metrics and figure scripts are
> included so that the negative results can be checked as easily as the positive ones.

Maintainer: **Raymond Fan** · fanxiaohu@whcp.edu.cn · see [`DEPLOY.md`](DEPLOY.md) for
installation, data provenance and run commands.

---

## Why this exists

Three claims are routine in this literature, and all three are usually asserted
rather than measured:

1. that a better architecture buys accuracy on proxy labels;
2. that multi-task learning improves the primary task;
3. that a random patch-level split is an acceptable evaluation.

We measured all three on one basin, with eight seeds, a common evaluation set, and an
intervention on the training set rather than a comparison of two splits. None of the
three survives.

## Headline numbers

| Model | Params | Patch-level IoU | Tile-level IoU |
|---|---:|---:|---:|
| Random forest, raw bands | — | **0.9267** | 0.8564 |
| Random forest, + 3 indices | — | 0.9259 | **0.8686** |
| XGBoost, + 3 indices | — | 0.9196 | 0.8591 |
| U-Net, dual task | 6.1 M | 0.9101 ± 0.0027 | 0.8158 ± 0.0121 |
| U-Net, single task | 6.1 M | 0.9104 ± 0.0024 | 0.7957 ± 0.0146 |
| CNN, single task | 6.1 M | 0.9050 ± 0.0037 | 0.7895 ± 0.0284 |
| Prithvi-EO-1.0 + LoRA | 62.7 M | 0.8987 ± 0.0037 | 0.8205 ± 0.0279 |
| Constant classifier | 0 | 0.620 | — |
| One band, one threshold | 0 | 0.820 | — |
| Six-band linear model | — | 0.890 | — |

Decomposition of the 11.6-point protocol gap, on one common 66-patch evaluation set:

| Component | Points | Share |
|---|---:|---:|
| Exact duplication (48 patches appear in training) | 1.24 | 11 % |
| Ordinary data loss (placebo, never-seen patches) | 3.68 | 32 % |
| Withheld neighbourhood (spatial source) | 6.71 | 58 % |

The duplication component is family-dependent, from 1.71 points for the U-Net to 5.19
for the random forest, and the ordering replicates on a disjoint seed set. A
sample-size-matched arm shows that 6.5 of the U-Net's 6.7-point neighbourhood term
comes from the change of spatial source, not from the 42 extra training patches.

## What is in the box

| Folder | Contents |
|---|---|
| `code/rebuild/` | Dataset reconstruction from Sentinel-2 L2A + ESA WorldCover, no credentials |
| `code/supp/` | 20 experiments, self-tests, idempotent runners |
| `code/build/` | Markdown → IEEE-style Word converter used for the manuscript |
| `figures/` | Six figures, Morandi palette, 600 dpi PNG + vector PDF, plus scripts |
| `manuscript/` | Final `.md` / `.docx` / `.pdf` |

## Quick start

```bash
pip install -r requirements.txt
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
cd code/supp && python selftest_supp.py          # no GPU, no data
cd ../rebuild && bash run_rebuild.sh gate        # 2 tiles, ~5 min
nohup bash run_rebuild.sh all > logs/boot.log 2>&1 &
```

Full instructions, data provenance, hardware notes and a list of things that break:
**[`DEPLOY.md`](DEPLOY.md)**. What changed between revisions: **[`CHANGELOG.md`](CHANGELOG.md)**.

## What this is not

Not a field-validated salinity product. The label is ESA WorldCover class 60, bare
ground, and it is a proxy; the ceiling of IoU ≈ 0.93 is a property of the label, not
of the models. Not a multi-decadal trend product. Not a claim about foundation models
in general: one backbone, one basin, one season, and a single-date input that bypasses
the model's temporal capacity.

## Licence and credits

Code: MIT. Manuscript: author's copy, please cite the journal version.
Sentinel-2: contains modified Copernicus Sentinel data (2020), processed by ESA.
WorldCover: © ESA WorldCover project 2020, CC BY 4.0.
Prithvi-EO-1.0 weights: IBM/NASA, Apache-2.0.

AI-use statement: drafting, translation and language polishing were assisted by Kimi K3
and GLM; all code, experiments, numbers and interpretation are the author's. See §11 of
[`DEPLOY.md`](DEPLOY.md).

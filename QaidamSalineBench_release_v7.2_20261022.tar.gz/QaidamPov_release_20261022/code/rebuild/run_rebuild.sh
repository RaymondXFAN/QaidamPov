#!/bin/bash
# =============================================================================
# QaidamPov dataset rebuild — one-click runner
#
#   PROJECT = /root/autodl-tmp/QaidamPov
#   scripts = $PROJECT/rebuild          (this folder)
#   out     = $PROJECT/rebuild_out
#
# Usage:
#   bash run_rebuild.sh gate     # ~5-10 min tiny run (2 tiles) to validate
#   bash run_rebuild.sh plan     # STAC query -> work/manifest.json (no download)
#   bash run_rebuild.sh build    # full rebuild (22 tiles -> 400 patches)
#   bash run_rebuild.sh all      # gate -> build -> summary
#   bash run_rebuild.sh status   # non-blocking progress
#   bash run_rebuild.sh summary  # print dataset card
#
# Long run (detached):
#   nohup bash run_rebuild.sh all > logs/boot.log 2>&1 &
# =============================================================================
set -uo pipefail

PROJECT="${PROJECT_DIR:-/root/autodl-tmp/QaidamPov}"
RB="${PROJECT}/rebuild"
OUT="${PROJECT}/rebuild_out"
LOGS="${RB}/logs"
PY="${PYTHON:-python}"

BBOX="${BBOX:-90 36 100 39}"
DATE_RANGE="${DATE_RANGE:-2020-06-01/2020-09-30}"
MAX_CLOUD="${MAX_CLOUD:-15}"
MAX_TILES="${MAX_TILES:-22}"
REGION_PX="${REGION_PX:-640}"
TOTAL="${TOTAL:-400}"
SALINE_CLASSES="${SALINE_CLASSES:-60}"

mkdir -p "${OUT}" "${LOGS}"
cd "${RB}"

log()  { echo "[$(date '+%F %T')] $*"; }
ok()   { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
die()  { echo "❌ $*"; exit 1; }
have() { [ -e "$1" ]; }

gate() {
    log "=== GATE: tiny real run (2 tiles) to validate data path ==="
    local g="${OUT}/_gate"
    rm -rf "${g}"
    ${PY} -u rebuild_dataset.py all --bbox ${BBOX} --date-range "${DATE_RANGE}" \
        --max-cloud "${MAX_CLOUD}" --max-tiles 2 --region-px 320 \
        --total 8 --patches-per-tile 4 --split 6,1,1 \
        --out-dir "${g}" --saline-classes "${SALINE_CLASSES}" || die "gate run crashed"
    have "${g}/processed_dual/train_x.npy" || die "gate: no train_x.npy written"
    have "${g}/processed_dual/patch_tiles.npy" || die "gate: no patch_tiles.npy"
    ok "gate passed — STAC + Sentinel-2 + WorldCover + patching all OK"
}

plan() {
    log "=== PLAN: STAC query only ==="
    ${PY} -u rebuild_dataset.py plan --bbox ${BBOX} --date-range "${DATE_RANGE}" \
        --max-cloud "${MAX_CLOUD}" --max-tiles "${MAX_TILES}" \
        --out-dir "${OUT}" || die "plan failed"
    ok "manifest -> ${OUT}/work/manifest.json"
}

build() {
    log "=== BUILD: full rebuild (${MAX_TILES} tiles -> ${TOTAL} patches) ==="
    if have "${OUT}/processed_dual/dataset_card.json" && [ "${FORCE:-0}" != "1" ]; then
        warn "already built -> SKIP (set FORCE=1 to rebuild)"; return
    fi
    ${PY} -u rebuild_dataset.py build --bbox ${BBOX} --date-range "${DATE_RANGE}" \
        --max-cloud "${MAX_CLOUD}" --max-tiles "${MAX_TILES}" \
        --region-px "${REGION_PX}" --total "${TOTAL}" --split-mode "${SPLIT_MODE:-patch}" \
        --out-dir "${OUT}" --saline-classes "${SALINE_CLASSES}" || die "build failed"
    ok "dataset -> ${OUT}/processed_dual"
}

status() {
    echo "--- rebuild progress ---"
    echo "out : ${OUT}"
    for p in "work/manifest.json|plan" \
             "processed_dual/train_x.npy|build" \
             "processed_dual/dataset_card.json|validate"; do
        f="${p%%|*}"; n="${p##*|}"
        if have "${OUT}/${f}"; then echo "  [done] ${n}"; else echo "  [    ] ${n}"; fi
    done
    echo "--- running jobs ---"; pgrep -af "rebuild_dataset.py" || echo "  (none)"
    ls -t "${LOGS}"/*.log 2>/dev/null | head -1 | xargs -r tail -n 15
}

summary() {
    local c="${OUT}/processed_dual/dataset_card.json"
    have "${c}" || die "no dataset_card.json yet"
    echo "=== dataset card ==="; ${PY} -c "import json,sys;print(json.dumps(json.load(open('${c}')),indent=2,ensure_ascii=False))"
}

case "${1:-all}" in
    gate) gate ;;
    plan) plan ;;
    build) build ;;
    status) status ;;
    summary) summary ;;
    all) gate; build; summary; ok "REBUILD DONE" ;;
    *) die "unknown command: ${1:-} (gate|plan|build|all|status|summary)" ;;
esac

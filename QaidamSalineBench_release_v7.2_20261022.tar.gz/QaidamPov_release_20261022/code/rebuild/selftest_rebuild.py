#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest_rebuild.py — OFFLINE self-test for the rebuild pipeline (no network).

Fabricates tiny but real GeoTIFFs:
  * 6 Sentinel-2-like bands (UTM EPSG:32646, 10 m, uint16)
  * an SCL band (uint8)
  * two WorldCover-like rasters (EPSG:4326, uint8), 2020 & 2021, with class-60
    (saline) regions that expand / shrink between the two years
then runs the full read -> align -> slice -> label -> split -> save -> validate
path and asserts shapes, dtypes and label consistency.

Usage:  python selftest_rebuild.py
Exit 0 + "✅ PASS" means the pipeline logic is sound.
"""
from __future__ import annotations

import os
import sys
import json
import tempfile

import numpy as np
import rasterio
from rasterio.transform import from_origin

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rb_common as R  # noqa: E402


def _write(path, arr, transform, crs, dtype, nodata=None):
    arr = arr.astype(dtype)
    with rasterio.open(path, "w", driver="GTiff", height=arr.shape[0],
                       width=arr.shape[1], count=1, dtype=dtype, crs=crs,
                       transform=transform, nodata=nodata, compress="lzw") as dst:
        dst.write(arr, 1)


def make_fake_world(tmp):
    H = W = 320
    s2_tr = from_origin(500000, 4100000, 10, 10)     # UTM 46N, 10 m
    crs = "EPSG:32646"
    paths = {}
    rng = np.random.RandomState(0)
    for _, key in R.S2_BANDS:
        a = (rng.rand(H, W) * 8000 + 500).astype(np.uint16)
        p = os.path.join(tmp, f"{key}.tif")
        _write(p, a, s2_tr, crs, "uint16"); paths[key] = p
    scl = np.full((H, W), 4, np.uint8)                # 4 = vegetation (valid)
    p = os.path.join(tmp, "scl.tif"); _write(p, scl, s2_tr, crs, "uint8"); paths["scl"] = p

    # WorldCover: coarse 4326 grid covering the UTM region (~ lon 92-95, lat 36-38)
    res = 1.0 / 1200.0
    wc_tr = from_origin(92.0, 38.0, res, res)
    n = 2400
    wc20 = np.full((n, n), 10, np.uint8)              # 10 = tree cover (non-saline)
    wc21 = np.full((n, n), 10, np.uint8)
    # saline patch in 2020 (stable) + a region that expands in 2021 + one that shrinks
    wc20[1000:1400, 1000:1500] = 60                   # stable saline
    wc21[1000:1400, 1000:1500] = 60
    wc20[600:800, 600:900] = 10                       # expansion: 10 -> 60
    wc21[600:800, 600:900] = 60
    wc20[1700:1900, 1700:2000] = 60                   # shrinkage: 60 -> 10
    wc21[1700:1900, 1700:2000] = 10
    for yr, arr in ((2020, wc20), (2021, wc21)):
        p = os.path.join(tmp, f"wc{yr}.tif")
        _write(p, arr, wc_tr, "EPSG:4326", "uint8"); paths[f"wc{yr}"] = p
    return paths, crs


def main():
    print("=" * 62)
    # ---- pure-logic checks ----
    assert R.wc_tile_name(95.0, 37.0) == "N36E093", R.wc_tile_name(95.0, 37.0)
    assert R.wc_tile_name(90.0, 39.0) == "N39E090"
    print("  ✅ wc_tile_name")

    s20 = np.array([[0, 1], [1, 1]], bool)
    s21 = np.array([[1, 0], [1, 1]], bool)
    yc = R.label_change(s20, s21)
    assert yc.tolist() == [[2, 3], [1, 1]], yc.tolist()   # exp, shrink, stable
    print("  ✅ label_change (0 stable-non, 1 stable-sal, 2 exp, 3 shrink)")

    assert list(R.iter_patch_coords(320, 320, 128, 64))[0] == (0, 0)
    idx = R.split_indices(400, 280, 60, 60, seed=1)
    assert len(idx["train"]) == 280 and len(idx["val"]) == 60 and len(idx["test"]) == 60
    g = np.repeat(np.arange(20), 20)          # 20 groups
    ig = R.split_indices(400, 280, 60, 60, groups=g, mode="group", seed=1)
    assert len(set(g[ig["train"]]) & set(g[ig["test"]])) == 0
    print("  ✅ split_indices (patch + group, no group leakage)")

    # ---- full raster path on synthetic GeoTIFFs ----
    tmp = tempfile.mkdtemp(prefix="qaidam_rb_selftest_")
    paths, crs = make_fake_world(tmp)
    scene = {"grid": "46SFF", "id": "TEST", "assets": {k: paths[k] for _, k in R.S2_BANDS},
             "scl": paths["scl"], "wc2020": paths["wc2020"], "wc2021": paths["wc2021"]}
    with R._rio_env():
        with R.open_src(paths["blue"]) as src:
            tgt = R.centered_target(src, 256)
    rng = np.random.RandomState(0)
    xs, yss, ycs, meta = R.build_patches_for_tile(
        scene, tgt, 128, 64, 256, [60], 0.05, rng)
    print(f"  ✅ build_patches_for_tile -> {len(xs)} patches from {meta['candidates']} candidates")
    assert len(xs) > 0
    assert xs[0].shape == (6, 128, 128) and xs[0].dtype == np.float32
    assert yss[0].shape == (128, 128) and yss[0].dtype == np.int64
    assert set(np.unique(ycs[0]).tolist()) <= {0, 1, 2, 3}

    X = np.stack(xs, 0).astype(np.float32)
    YS = np.stack(yss, 0).astype(np.int64)
    YC = np.stack(ycs, 0).astype(np.int64)
    groups = np.ones(len(xs), dtype=np.int64)
    # force a clean 3-way split regardless of count
    n = len(xs); ntr = max(1, int(n * 0.7)); nva = max(1, int(n * 0.15)); nte = n - ntr - nva
    splits = R.split_indices(n, ntr, nva, nte, groups=groups, mode="patch", seed=42)
    out = os.path.join(tmp, "processed_dual")
    counts = R.save_processed_dual(out, X, YS, YC, groups, splits)
    print(f"  ✅ save_processed_dual -> {counts}")
    assert os.path.exists(os.path.join(out, "patch_tiles.npy"))
    assert np.load(os.path.join(out, "patch_tiles.npy")).shape[0] == counts["train"] + counts["val"] + counts["test"]

    rep = R.validate_dataset(out, verbose=False)
    assert rep["all_zero_patches"] == 0
    print(f"  ✅ validate_dataset -> saline share {rep['share_saline_2020_pct']}%  "
          f"change {rep['change_shares_pct']}")

    # deliberate corruption must be caught
    bad = os.path.join(tmp, "bad"); os.makedirs(bad)
    for nm in ("train", "val", "test"):
        np.save(os.path.join(bad, f"{nm}_x.npy"), np.zeros((2, 6, 128, 128), np.float32))
        np.save(os.path.join(bad, f"{nm}_y_static.npy"), np.zeros((2, 128, 128), np.int64))
        np.save(os.path.join(bad, f"{nm}_y_change.npy"), np.zeros((2, 128, 128), np.int64))
    try:
        R.validate_dataset(bad, verbose=False); raise SystemExit("validator missed all-zero patches!")
    except AssertionError:
        print("  ✅ validate_dataset correctly flags all-zero patches")

    print("\n" + "=" * 62)
    print("✅ PASS — rebuild pipeline runs end-to-end offline (synthetic rasters)")
    print(f"   temp dir: {tmp}")
    print("=" * 62)


if __name__ == "__main__":
    main()

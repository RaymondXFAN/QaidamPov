#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rebuild_dataset.py — rebuild the QaidamPov training tensors from public sources.

Produces (in --data-dir):
    train_x.npy (280,6,128,128) float32   *_y_static.npy int64   *_y_change.npy int64
    val_x.npy   (60,...)                  ...                    ...
    test_x.npy  (60,...)                  ...                    ...
    patch_tiles.npy   (400,) int64        <- group id per patch (for EXP-D)
    dataset_card.json                     <- provenance + params + class shares

Subcommands
    plan    STAC-query Earth Search, pick lowest-cloud scene per MGRS tile, save manifest
    build   fetch each tile region, slice to patches, split, save, validate
    all     plan + build

Example
    python rebuild_dataset.py all \
        --bbox 90 36 100 39 --date-range 2020-06-01/2020-09-30 \
        --max-tiles 22 --total 400 --out-dir /root/autodl-tmp/QaidamPov/rebuild_out

No account / credentials are required (Earth Search + ESA WorldCover S3).
"""
from __future__ import annotations

import os
import sys
import json
import time
import math
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rb_common as R  # noqa: E402


def cmd_plan(args):
    print("🔎 planning: querying Earth Search STAC ...")
    tiles = R.plan_tiles(tuple(args.bbox), args.date_range,
                         max_cloud=args.max_cloud, max_tiles=args.max_tiles)
    tiles = [R.annotate_worldcover(t) for t in tiles]
    manifest = {"bbox": args.bbox, "date_range": args.date_range,
                "max_cloud": args.max_cloud, "n_tiles": len(tiles), "tiles": tiles}
    os.makedirs(args.work_dir, exist_ok=True)
    path = os.path.join(args.work_dir, "manifest.json")
    with open(path, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"✅ manifest -> {path}  ({len(tiles)} tiles)")
    for t in tiles:
        print(f"   {t['grid']:8s} {t['id']:28s} cloud={t['cloud']:5.2f}  wc={t['wc_tile']}")
    return manifest


def _load_or_plan(args):
    path = os.path.join(args.work_dir, "manifest.json")
    if os.path.exists(path):
        with open(path) as f:
            m = json.load(f)
        print(f"📄 using existing manifest ({m['n_tiles']} tiles)")
        return m
    return cmd_plan(args)


def _region_center_lonlat(tgt):
    from rasterio.warp import transform as rio_transform
    import rasterio.transform as rt
    cx, cy = rt.xy(tgt.transform, tgt.width / 2.0, tgt.height / 2.0)
    lon, lat = rio_transform(tgt.crs, "EPSG:4326", [cx], [cy])
    return float(lon[0]), float(lat[0])


def cmd_build(args):
    manifest = _load_or_plan(args)
    tiles = manifest["tiles"]
    rng = np.random.RandomState(args.seed)
    per_tile = args.patches_per_tile or max(1, int(math.ceil(args.total / max(1, len(tiles)) * 1.6)))

    X, YS, YC, groups, tile_report = [], [], [], [], []
    saline_classes = [int(c) for c in str(args.saline_classes).split(",")]

    for i, t in enumerate(tiles, 1):
        print(f"\n[{i}/{len(tiles)}] tile {t['grid']} scene {t['id']} "
              f"(cloud {t['cloud']:.2f})")
        try:
            with R._rio_env():
                with R.open_src(t["assets"]["blue"]) as src:
                    tgt = R.centered_target(src, args.region_px)
            # refine WorldCover tile from the region centre
            lon, lat = _region_center_lonlat(tgt)
            wc = R.wc_tile_name(lon, lat)
            t["wc_tile"], t["wc2020"], t["wc2021"] = wc, R.wc_href(2020, wc), R.wc_href(2021, wc)
            xs, yss, ycs, meta = R.build_patches_for_tile(
                t, tgt, args.patch, args.stride, args.region_px,
                saline_classes, args.max_invalid, rng)
            k = min(per_tile, len(xs))
            if k == 0:
                print("   ⚠️  no valid patches (all cloudy/invalid) -> skip")
                continue
            X.extend(xs[:k]); YS.extend(yss[:k]); YC.extend(ycs[:k])
            groups.extend([i] * k)
            tile_report.append({"tile": t["grid"], "scene": t["id"], "epsg": str(tgt.crs),
                                "region_px": tgt.width, "wc_tile": wc,
                                "candidates": meta["candidates"], "used": k})
            print(f"   ✅ {k} patches (of {meta['candidates']} candidates)")
        except Exception as e:
            print(f"   ❌ tile failed: {type(e).__name__}: {e}")
        time.sleep(0.2)

    n = len(X)
    print(f"\n📦 assembled {n} patches from {len(tile_report)} tiles")
    if n == 0:
        print("❌ nothing to save"); sys.exit(1)

    # cap to --total for a clean 280/60/60 unless user set different split
    if args.split:
        n_tr, n_va, n_te = [int(x) for x in args.split.split(",")]
    else:
        n_tr, n_va, n_te = 280, 60, 60
    need = n_tr + n_va + n_te
    X = np.stack(X, 0).astype(np.float32)
    YS = np.stack(YS, 0).astype(np.int64)
    YC = np.stack(YC, 0).astype(np.int64)
    groups = np.asarray(groups, dtype=np.int64)

    # trim to the requested total (random, seeded) so the split is always clean
    if n > need:
        keep = rng.permutation(n)[:need]
        keep.sort()
        X, YS, YC, groups = X[keep], YS[keep], YC[keep], groups[keep]
        n = need
        print(f"✂️  trimmed to {n} patches (target {need})")

    if n < need:
        print(f"⚠️  only {n} patches < requested {need}; scaling the split "
              f"proportionally (raise --max-tiles / --region-px / --patches-per-tile "
              f"for a full 280/60/60).")
        sc = n / need
        n_te = max(1, int(round(n_te * sc)))
        n_va = max(1, int(round(n_va * sc)))
        n_tr = max(1, n - n_va - n_te)
    else:
        n_tr, n_va, n_te = 280, 60, 60

    splits = R.split_indices(n, n_tr, n_va, n_te, groups=groups,
                             mode=args.split_mode, seed=args.seed)
    counts = R.save_processed_dual(args.data_dir, X, YS, YC, groups, splits)
    print(f"✅ saved processed_dual -> {args.data_dir}  {counts}")

    rep = R.validate_dataset(args.data_dir)
    card = {"created": time.strftime("%F %T"),
            "bbox": manifest["bbox"], "date_range": manifest["date_range"],
            "max_cloud": manifest["max_cloud"], "saline_classes": saline_classes,
            "patch": args.patch, "stride": args.stride, "region_px": args.region_px,
            "split_mode": args.split_mode, "seed": args.seed, "counts": counts,
            "n_patches": int(n), "tiles": tile_report, "validation": rep,
            "sources": {"stac": R.STAC_URL, "collection": R.S2_COLLECTION,
                        "worldcover": R.WC_BASE, "bands": [b for b, _ in R.S2_BANDS]}}
    with open(os.path.join(args.data_dir, "dataset_card.json"), "w") as f:
        json.dump(card, f, indent=2)
    print(f"✅ dataset_card.json written")
    return card


def main():
    ap = argparse.ArgumentParser(description="QaidamPov dataset rebuild")
    ap.add_argument("cmd", choices=["plan", "build", "all"])
    ap.add_argument("--bbox", nargs=4, type=float, default=[90, 36, 100, 39],
                    metavar=("W", "S", "E", "N"))
    ap.add_argument("--date-range", default="2020-06-01/2020-09-30")
    ap.add_argument("--max-cloud", type=float, default=15.0)
    ap.add_argument("--max-tiles", type=int, default=22)
    ap.add_argument("--patch", type=int, default=128)
    ap.add_argument("--stride", type=int, default=64)
    ap.add_argument("--region-px", type=int, default=640)
    ap.add_argument("--patches-per-tile", type=int, default=0,
                    help="0 = auto (= total / n_tiles)")
    ap.add_argument("--total", type=int, default=400)
    ap.add_argument("--split", default="", help="train,val,test (default 280,60,60)")
    ap.add_argument("--split-mode", choices=["patch", "group"], default="patch")
    ap.add_argument("--saline-classes", default="60",
                    help="WorldCover classes treated as saline (paper: 60 only)")
    ap.add_argument("--max-invalid", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out-dir", default="/root/autodl-tmp/QaidamPov/rebuild_out")
    ap.add_argument("--work-dir", default="")
    ap.add_argument("--data-dir", default="")
    args = ap.parse_args()

    args.work_dir = args.work_dir or os.path.join(args.out_dir, "work")
    args.data_dir = args.data_dir or os.path.join(args.out_dir, "processed_dual")
    os.makedirs(args.work_dir, exist_ok=True)

    if args.cmd == "plan":
        cmd_plan(args)
    elif args.cmd == "build":
        cmd_build(args)
    else:
        cmd_plan(args)
        cmd_build(args)


if __name__ == "__main__":
    main()

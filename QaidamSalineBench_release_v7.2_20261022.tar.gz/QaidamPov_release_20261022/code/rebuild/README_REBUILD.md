# QaidamPov 数据重建管线（rebuild）

> 背景：QaidamPov 原机的 `processed_dual`（9 个 .npy）与预处理脚本已确认**全盘丢失**。
> 本管线**从公开源重新生成**同规格的训练张量，并**额外产出 `patch_tiles.npy`**（每 patch 的
> 空间组 id），正好补上 `supp/` 包里 EXP-D 缺的 `GROUPS` 输入。
> 生成日期：2026-10-11

---

## 0. 一句话说明

用 **AWS Earth Search STAC（免账号）** 取 Sentinel-2 L2A 的 B02/B03/B04/B08/B11/B12，
用 **ESA WorldCover S3（免账号）** 取 2020(v100)/2021(v200)，对齐后切成 128×128 patch、
按论文口径打标签，输出与原文**同名同形状同 dtype** 的 9 个 `.npy`。

| 产物 | 规格 |
|---|---|
| `train/val/test_x.npy` | `(280/60/60, 6, 128, 128)` **float32** |
| `train/val/test_y_static.npy` | `(N, 128, 128)` **int64**，`{0=非盐, 1=盐}` |
| `train/val/test_y_change.npy` | `(N, 128, 128)` **int64**，`{0稳定非盐,1稳定盐,2扩张,3收缩}` |
| `patch_tiles.npy` | `(400,)` int64，每 patch 的 tile 组 id（顺序 = train\|val\|test）|
| `dataset_card.json` | 溯源信息 + 参数 + 类别占比 |

---

## 1. 目录 / 依赖

```
rebuild/
├── rb_common.py         # STAC/WorldCover/对齐读取/切片/打标签/划分/校验
├── rebuild_dataset.py   # CLI: plan | build | all
├── selftest_rebuild.py  # 离线自测（合成栅格，无需联网）
├── run_rebuild.sh       # 一键 runner（含预检闸门/幂等/汇总）
└── README_REBUILD.md
```

依赖（无账号、无密钥）：`rasterio pystac-client shapely pyproj requests numpy`。
安装：`pip install rasterio pystac-client shapely pyproj requests`

---

## 2. 上机操作

### 2.1 放置与自测
```bash
tar -xzf QaidamPov_rebuild.tar.gz -C /root/autodl-tmp/
cd /root/autodl-tmp/QaidamPov/rebuild
python selftest_rebuild.py        # 应打印 ✅ PASS（不需联网）
```

### 2.2 预检闸门（2 个真实 tile，约 5–10 分钟）
```bash
bash run_rebuild.sh gate          # 看到 ✅ gate passed 再继续
```

### 2.3 全量重建（默认 22 tile → 400 patch）
```bash
nohup bash run_rebuild.sh all > logs/boot.log 2>&1 &
bash run_rebuild.sh status        # 非阻塞监控（别用 tail -f）
bash run_rebuild.sh summary       # 跑完看 dataset_card
```
**预估耗时：约 20–40 分钟**（主要花在从 S3 拉每 tile 的栅格窗口，约 150–200 MB）。

### 2.4 产物落地
`/root/autodl-tmp/QaidamPov/rebuild_out/processed_dual/` → 把它接到项目：
```bash
ln -sfn /root/autodl-tmp/QaidamPov/rebuild_out /root/autodl-tmp/QaidamPov/data
# 或复制到旧位置： mkdir -p /root/autodl-tmp/data && cp -r rebuild_out/processed_dual /root/autodl-tmp/data/
```

---

## 3. 关键参数（都可 CLI / 环境变量覆盖）

| 参数 | 默认 | 说明 |
|---|---|---|
| `--bbox W S E N` | `90 36 100 39` | 研究区（论文 36–39°N, 90–100°E）|
| `--date-range` | `2020-06-01/2020-09-30` | 2020 生长季 |
| `--max-cloud` | `15` | 每 tile 选云量最低、且低于阈值的场景 |
| `--max-tiles` | `22` | tile 数（bbox 内自动选取、均匀抽样）|
| `--region-px` | `640` | 每 tile 采样的中心方窗边长（10 m 像素）= 6.4 km |
| `--total` | `400` | 目标 patch 总数（=280+60+60）|
| `--patches-per-tile` | 0=自动 | =total/tile 数 |
| `--patch / --stride` | `128 / 64` | 与原文一致（stride64 → 50 % 重叠）|
| `--saline-classes` | `60` | **论文口径：仅 WorldCover class 60**；如需 60+70 写 `60,70` |
| `--split-mode` | `patch` | 也可 `group`（按 tile 划分，**顺带消除空间泄漏**）|
| `--seed` | `42` | 抽样/划分随机种子 |

---

## 4. 校验 & 溯源

- 每次 build 自动 `validate_dataset()`：断言形状/dtype、**全零 patch 数必须为 0**，并打印类别占比；
- `dataset_card.json` 记录：bbox / 日期 / 云量阈值 / tile→scene 清单（含 scene id、云量、EPSG）/ 切片参数 / 划分 / 类别占比 / 数据源链接——**可直接写进论文 Methods**。

---

## 5. ⚠️ 三条必须知道的代价与注意

1. **重建 = 新数据集**：抽样/季节/场景但凡有差异，训出的 IoU **不会正好等于论文的 0.803 / 0.785 / 0.777**。
   → 走重建，就要接受**论文结果表整体重算**。数据无关的返修（引用/口径/格式/诚实声明）不受影响。
2. **WorldCover 版本差会抬高"扩张"比例**：2020 用 **v100**、2021 用 **v200** 是两个版本，存在版本性差异
   （小样本实测 expansion ≈ 18 %，远高于论文的 0.7 %）。若想更接近论文，可尝试：
   - 统一到同一版本网格后比较，或
   - 加一个"最小变化连通面积"过滤（需小改 `label_change`）。
3. **磁盘**：本机数据盘曾 87 % 满；重建产物仅 ~250 MB，但要确认有空间。

---

## 6. 与 `supp/` 补充实验包的衔接

重建完成后：
```bash
# EXP-A / EXP-C 直接吃重建后的数据
DATA_DIR=/root/autodl-tmp/QaidamPov/rebuild_out/processed_dual bash run_supplementary.sh expA
# EXP-D 用重建产出的 patch_tiles.npy 当 GROUPS，量化/消除空间泄漏
GROUPS=/root/autodl-tmp/QaidamPov/rebuild_out/processed_dual/patch_tiles.npy \
  bash ../supp/run_supplementary.sh expD
```
> 注：`patch_tiles.npy` 的组 id 与 `--split-mode patch` 下的 patch 顺序一致（train\|val\|test）。

---

## 7. 自测覆盖
`selftest_rebuild.py` 在**无网络**下用合成 GeoTIFF 覆盖：WorldCover 命名、变化标签、patch 坐标、
两种划分（patch/group 无泄漏）、完整"读→对齐→切片→打标签→存盘→校验"链路，并验证校验器能**抓出全零 patch**。

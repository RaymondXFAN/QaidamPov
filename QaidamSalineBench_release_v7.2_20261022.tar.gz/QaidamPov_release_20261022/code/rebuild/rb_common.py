#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rb_common.py — shared helpers for the QaidamPov dataset rebuild pipeline.

The pipeline reproduces the exact training tensors the original project used:

    processed_dual/
      train_x.npy (280, 6, 128, 128) float32      val_x.npy (60,...)   test_x.npy (60,...)
      *_y_static.npy (N, 128, 128) int64  {0,1}   (0 = non-saline, 1 = saline)
      *_y_change.npy (N, 128, 128) int64  {0,1,2,3}
          0 = stable non-saline, 1 = stable saline, 2 = expansion, 3 = shrinkage

Data sources (both free, NO account needed):
  * Sentinel-2 L2A COG  via AWS Earth Search STAC  (collection sentinel-2-l2a)
  * ESA WorldCover 10 m v100(2020) / v200(2021)  via the ESA S3 bucket

Extra output: patch_tiles.npy  (one integer group id per patch, in train|val|test
order) -> this is exactly the `GROUPS` input that EXP-D needs to measure/remediate
spatial leakage.
"""
from __future__ import annotations

import os
import json
import math
import warnings
from dataclasses import dataclass, asdict

import numpy as np

warnings.filterwarnings("ignore")

# rasterio is optional at import time so that pure-logic unit tests can run
try:
    import rasterio
    from rasterio.windows import Window
    from rasterio.vrt import WarpedVRT
    from rasterio.enums import Resampling
    from rasterio.warp import transform_bounds
    _HAS_RIO = True
except Exception:  # pragma: no cover
    _HAS_RIO = False

STAC_URL = "https://earth-search.aws.element84.com/v1"
S2_COLLECTION = "sentinel-2-l2a"
WC_BASE = "https://esa-worldcover.s3.eu-central-1.amazonaws.com"

# 6 bands used by the paper: B02 B03 B04 B08 B11 B12  (Earth Search asset key)
S2_BANDS = [("B02", "blue"), ("B03", "green"), ("B04", "red"),
            ("B08", "nir"), ("B11", "swir16"), ("B12", "swir22")]

# Sentinel-2 SCL classes treated as invalid (nodata / shadow / cloud)
SCL_BAD = {0, 1, 3, 8, 9, 10, 11}


# ============================================================================
#  WorldCover naming  (SW-corner grid, 3x3 degrees)
# ============================================================================
def wc_tile_name(lon: float, lat: float) -> str:
    """ESA WorldCover tile name for the 3x3-degree tile containing (lon,lat)."""
    lat0 = int(math.floor(lat / 3.0) * 3)
    lon0 = int(math.floor(lon / 3.0) * 3)
    ns = "N" if lat0 >= 0 else "S"
    ew = "E" if lon0 >= 0 else "W"
    return f"{ns}{abs(lat0):02d}{ew}{abs(lon0):03d}"


def wc_href(year: int, tile: str) -> str:
    if int(year) == 2020:
        return f"{WC_BASE}/v100/2020/map/ESA_WorldCover_10m_2020_v100_{tile}_Map.tif"
    if int(year) == 2021:
        return f"{WC_BASE}/v200/2021/map/ESA_WorldCover_10m_2021_v200_{tile}_Map.tif"
    raise ValueError(f"unsupported WorldCover year: {year}")


# ============================================================================
#  Target grid
# ============================================================================
@dataclass
class Target:
    crs: object
    transform: object
    width: int
    height: int

    def as_dict(self):
        return {"crs": str(self.crs), "width": self.width, "height": self.height,
                "transform": list(self.transform)[:6]}


def _rio_env():
    return rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR",
                        GDAL_HTTP_MULTIRANGE="YES", GDAL_HTTP_MERGE_CONSECUTIVE_RANGES="YES",
                        VSI_CACHE=True, VSI_CACHE_SIZE=536870912)


def open_src(href):
    return rasterio.open(href)


def centered_target(src, size_px: int) -> Target:
    """A size_px x size_px window centred on the granule (in its native CRS)."""
    w, h = src.width, src.height
    size = min(int(size_px), w, h)
    left = max(0, (w - size) // 2)
    top = max(0, (h - size) // 2)
    tr = src.window_transform(Window(left, top, size, size))
    return Target(src.crs, tr, size, size)


def read_to_grid(href: str, tgt: Target, resampling) -> np.ndarray:
    """Read `href`, warped onto the target grid. Works across CRS / resolution."""
    with _rio_env():
        with rasterio.open(href) as src:
            with WarpedVRT(src, crs=tgt.crs, transform=tgt.transform,
                           width=tgt.width, height=tgt.height,
                           resampling=resampling, nodata=src.nodata) as vrt:
                return vrt.read(1)


# ============================================================================
#  STAC planning
# ============================================================================
def plan_tiles(bbox, date_range, max_cloud=15.0, max_tiles=22, max_workers=None):
    """Query Earth Search; return {grid:code -> best (lowest-cloud) scene info}."""
    from pystac_client import Client
    cat = Client.open(STAC_URL)
    search = cat.search(collections=[S2_COLLECTION], bbox=list(bbox),
                        datetime=date_range,
                        query={"eo:cloud_cover": {"lt": float(max_cloud)}})
    best = {}
    n = 0
    for it in search.items():
        n += 1
        grid = it.properties.get("grid:code") or it.id.split("_")[1]
        cc = it.properties.get("eo:cloud_cover", 999)
        if grid not in best or cc < best[grid]["cloud"]:
            best[grid] = {
                "grid": grid, "id": it.id, "cloud": float(cc),
                "datetime": str(it.datetime),
                "epsg": it.properties.get("proj:epsg") or _epsg_from_grid(grid),
                "assets": {a: it.assets[a].href for b, a in S2_BANDS if a in it.assets},
                "scl": it.assets["scl"].href if "scl" in it.assets else None,
                "bbox": list(it.bbox),
            }
    print(f"  STAC: scanned {n} items, {len(best)} distinct MGRS tiles")
    # sort tiles by longitude then latitude for determinism, then cap
    tiles = sorted(best.values(), key=lambda t: (t["epsg"], t["grid"]))
    if max_tiles and len(tiles) > max_tiles:
        # even spatial sampling across the sorted list
        idx = np.linspace(0, len(tiles) - 1, max_tiles).round().astype(int)
        tiles = [tiles[i] for i in sorted(set(idx.tolist()))]
    return tiles


def _epsg_from_grid(grid):
    """Fallback: MGRS -> UTM EPSG (e.g. 46SFF -> 32646 if N, 32746 if S)."""
    try:
        zone = int(grid[0:2])
        band = grid[2]
        south = band < "N"  # MGRS latitude bands C..M are southern
        return 32700 + zone if south else 32600 + zone
    except Exception:
        return None


def annotate_worldcover(tile):
    """Attach WorldCover hrefs (2020/2021) covering the scene centre."""
    b = tile.get("bbox")
    if b:
        lon = (b[0] + b[2]) / 2.0
        lat = (b[1] + b[3]) / 2.0
    else:
        lon, lat = 95.0, 37.0
    wc = wc_tile_name(lon, lat)
    tile["wc_tile"] = wc
    tile["wc2020"] = wc_href(2020, wc)
    tile["wc2021"] = wc_href(2021, wc)
    return tile


# ============================================================================
#  Patch extraction + labelling
# ============================================================================
def iter_patch_coords(h, w, patch, stride):
    for y in range(0, h - patch + 1, stride):
        for x in range(0, w - patch + 1, stride):
            yield y, x


def label_change(sal2020: np.ndarray, sal2021: np.ndarray) -> np.ndarray:
    """4-class change code from two boolean saline masks."""
    yc = np.zeros(sal2020.shape, dtype=np.int64)
    yc[sal2020 & sal2021] = 1          # stable saline
    yc[~sal2020 & sal2021] = 2         # expansion (non-saline -> saline)
    yc[sal2020 & ~sal2021] = 3         # shrinkage (saline -> non-saline)
    return yc


def build_patches_for_tile(scene, tgt: Target, patch, stride, region_px,
                           saline_classes, max_invalid, rng):
    """Return (x_list, y_static_list, y_change_list, meta) for one tile."""
    bands = []
    for bname, key in S2_BANDS:
        href = scene["assets"].get(key)
        if href is None:
            raise RuntimeError(f"scene {scene['id']} missing asset {key}")
        # spectral bands -> bilinear (20 m SWIR resampled to the 10 m grid)
        bands.append(("spectral", read_to_grid(href, tgt, Resampling.bilinear)))
    scl = (read_to_grid(scene["scl"], tgt, Resampling.nearest)
           if scene.get("scl") else np.zeros((tgt.height, tgt.width), np.uint8))

    wc20 = read_to_grid(scene["wc2020"], tgt, Resampling.nearest)
    wc21 = read_to_grid(scene["wc2021"], tgt, Resampling.nearest)

    X = np.stack([b[1] for b in bands], axis=0).astype(np.float32)  # (6,H,W)
    invalid = np.isin(scl, list(SCL_BAD))

    sal20 = np.isin(wc20, saline_classes)
    sal21 = np.isin(wc21, saline_classes)
    ys_full = sal20.astype(np.int64)
    yc_full = label_change(sal20, sal21)

    xs, yss, ycs, coords = [], [], [], []
    for y, x in iter_patch_coords(tgt.height, tgt.width, patch, stride):
        inv_frac = invalid[y:y + patch, x:x + patch].mean()
        if inv_frac > max_invalid:
            continue
        xs.append(X[:, y:y + patch, x:x + patch].copy())
        yss.append(ys_full[y:y + patch, x:x + patch].copy())
        ycs.append(yc_full[y:y + patch, x:x + patch].copy())
        coords.append((y, x))
    order = rng.permutation(len(xs)) if xs else np.array([], dtype=int)
    meta = {"tile": scene["grid"], "scene": scene["id"], "region_px": region_px,
            "candidates": len(xs), "coords": [list(map(int, coords[i])) for i in order]}
    return ([xs[i] for i in order], [yss[i] for i in order],
            [ycs[i] for i in order], meta)


# ============================================================================
#  Split + save
# ============================================================================
def split_indices(n, n_train, n_val, n_test, groups=None, mode="patch", seed=42):
    """Return dict with train/val/test index arrays. mode in {patch,group}."""
    rng = np.random.RandomState(seed)
    if mode == "group" and groups is not None:
        uniq = np.unique(groups)
        rng.shuffle(uniq)
        n_val_g = max(1, int(round(len(uniq) * n_val / max(n, 1))))
        n_test_g = max(1, int(round(len(uniq) * n_test / max(n, 1))))
        test_g = set(uniq[:n_test_g].tolist())
        val_g = set(uniq[n_test_g:n_test_g + n_val_g].tolist())
        idx_all = np.arange(n)
        tr = idx_all[[g not in test_g and g not in val_g for g in groups]]
        va = idx_all[[g in val_g for g in groups]]
        te = idx_all[[g in test_g for g in groups]]
        return {"train": tr, "val": va, "test": te}
    perm = rng.permutation(n)
    return {"train": perm[:n_train], "val": perm[n_train:n_train + n_val],
            "test": perm[n_train + n_val:n_train + n_val + n_test]}


def save_processed_dual(out_dir, X, YS, YC, groups, splits):
    os.makedirs(out_dir, exist_ok=True)
    all_idx = np.concatenate([splits["train"], splits["val"], splits["test"]])
    order_groups = np.asarray(groups)[all_idx].astype(np.int64)
    for name in ("train", "val", "test"):
        idx = splits[name]
        np.save(os.path.join(out_dir, f"{name}_x.npy"), X[idx].astype(np.float32))
        np.save(os.path.join(out_dir, f"{name}_y_static.npy"), YS[idx].astype(np.int64))
        np.save(os.path.join(out_dir, f"{name}_y_change.npy"), YC[idx].astype(np.int64))
    # group id per patch in train|val|test order -> feeds EXP-D
    np.save(os.path.join(out_dir, "patch_tiles.npy"), order_groups)
    return {"train": len(splits["train"]), "val": len(splits["val"]),
            "test": len(splits["test"])}


def validate_dataset(data_dir, verbose=True):
    """Shape / dtype / distribution audit; returns a dict + prints a report."""
    rep = {}
    for name in ("train", "val", "test"):
        x = np.load(os.path.join(data_dir, f"{name}_x.npy"), mmap_mode="r")
        ys = np.load(os.path.join(data_dir, f"{name}_y_static.npy"), mmap_mode="r")
        yc = np.load(os.path.join(data_dir, f"{name}_y_change.npy"), mmap_mode="r")
        rep[name] = {"x_shape": list(x.shape), "x_dtype": str(x.dtype),
                     "ys_shape": list(ys.shape), "ys_dtype": str(ys.dtype),
                     "yc_shape": list(yc.shape), "yc_dtype": str(yc.dtype)}
        assert x.shape[1] == 6 and x.ndim == 4, f"{name}_x bad shape {x.shape}"
        assert ys.shape == yc.shape == x.shape[:1] + x.shape[2:], \
            f"{name} label shape mismatch"
        assert x.dtype == np.float32 and ys.dtype == np.int64 and yc.dtype == np.int64
    # aggregate distributions over the full set
    tot = 0
    sal = 0
    ch = np.zeros(4, dtype=np.int64)
    zero_rows = 0
    for name in ("train", "val", "test"):
        ys = np.load(os.path.join(data_dir, f"{name}_y_static.npy"))
        yc = np.load(os.path.join(data_dir, f"{name}_y_change.npy"))
        sal += int((ys == 1).sum())
        tot += ys.size
        for c in range(4):
            ch[c] += int((yc == c).sum())
        zero_rows += int((np.abs(np.load(os.path.join(data_dir, f"{name}_x.npy"))).sum(axis=(1, 2, 3)) == 0).sum())
    rep["share_saline_2020_pct"] = round(100 * sal / tot, 2)
    rep["change_shares_pct"] = {str(c): round(100 * ch[c] / tot, 2) for c in range(4)}
    rep["all_zero_patches"] = zero_rows
    if verbose:
        print(json.dumps(rep, indent=2))
        print(f"\n  reference (paper): stable saline ~79.6%, expansion ~0.7%, shrinkage ~3.5%")
    assert zero_rows == 0, "found all-zero patches -> check band scaling / nodata"
    return rep

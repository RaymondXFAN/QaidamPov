#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-A — Multi-seed x lambda grid + single-task paired baseline.

Why this exists
---------------
The manuscript's "six-run" headline mixes 3 seeds at lambda=1.0 with 3 lambdas at
a single seed (42), i.e. pseudo-replication. The honest paired comparison at
lambda=1.0 is +0.002 (n.s.). To replace that with a defensible number we need a
proper two-factor design:

    seeds  x  lambda  in  {0.3, 0.5, 0.7, 1.0}

plus a single-task baseline run over the SAME seeds, so the comparison is a true
paired test.

Outputs (in --out-dir/<tag>/)
    runs/dual_seed{S}_lam{L}.json      per-run metrics + confusion matrix
    runs/single_seed{S}.json
    ckpts/dual_seed{S}_lam{L}.pth      (for downstream re-evaluation)
    ckpts/single_seed{S}.pth
    grid_results.json                  everything, machine readable
    TABLE_multiseed_lambda.md          paper-ready tables + stats
"""
from __future__ import annotations

import os
import sys
import json
import time
import argparse

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import confusion_matrix

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    DualTaskModel, SingleTaskModel, build_loaders, load_split, train_stats,
    compute_class_weights, metrics_bundle, describe, ttest_rel, write_json,
    set_seed, get_device, makedirs, DEFAULT_DATA_DIR, DEFAULT_OUT_DIR,
)


def run_one(model_kind, seed, lam, data_dir, out_root, device,
            epochs, batch_size, lr, save_ckpt=True):
    """Train one configuration and return its metrics dict."""
    set_seed(seed)
    dual = (model_kind == "dual")
    tag = f"dual_seed{seed}_lam{lam}" if dual else f"single_seed{seed}"

    x_tr, ys_tr, yc_tr = load_split(data_dir, "train")
    mean, std = train_stats(x_tr)

    tr = build_loaders(data_dir, "train", mean, std, batch_size, augment=True,
                       num_workers=2)
    va = build_loaders(data_dir, "val", mean, std, batch_size, augment=False,
                       num_workers=2)
    te = build_loaders(data_dir, "test", mean, std, batch_size, augment=False,
                       num_workers=2)
    _, ys_te, yc_te = load_split(data_dir, "test")

    ws, wc = compute_class_weights(ys_tr, yc_tr, device)
    crit_s = nn.CrossEntropyLoss(weight=ws)
    crit_c = nn.CrossEntropyLoss(weight=wc)

    if dual:
        model = DualTaskModel(in_channels=x_tr.shape[1], num_classes=2,
                              num_change_classes=4).to(device)
    else:
        model = SingleTaskModel(in_channels=x_tr.shape[1], num_classes=2).to(device)

    print(f"\n{'='*64}\n[{tag}] epochs={epochs} lr={lr} bs={batch_size} "
          f"device={device}\n{'='*64}")
    t0 = time.time()
    best_state, pred_s, pred_c, hist, best_val = train_model_local(
        model, dual, tr, va, te, device, epochs, lr, lam, crit_s, crit_c,
        log_prefix=f"[{tag}] ")
    dt = time.time() - t0

    metrics = metrics_bundle(ys_te, yc_te, pred_s, pred_c)
    result = {
        "model": "DualTask" if dual else "SingleTask",
        "seed": int(seed),
        "lambda_change": float(lam) if dual else None,
        "train_seconds": round(dt, 2),
        "best_val_combined": float(best_val),
        "history": hist,
        **metrics,
    }
    run_dir = os.path.join(out_root, "runs")
    makedirs(run_dir)
    write_json(os.path.join(run_dir, tag + ".json"), result)

    if save_ckpt:
        ck_dir = os.path.join(out_root, "ckpts")
        makedirs(ck_dir)
        torch.save({"model_state_dict": best_state, "tag": tag,
                    "model": result["model"], "seed": int(seed),
                    "lambda_change": result["lambda_change"]},
                   os.path.join(ck_dir, tag + ".pth"))

    print(f"[{tag}] done in {dt:.1f}s | static IoU={metrics['static']['iou_saline']:.4f} "
          f"acc={metrics['static']['accuracy']:.4f} f1m={metrics['static']['f1_macro']:.4f} "
          f"kappa={metrics['static']['kappa']:.4f}"
          + (f" | change F1m={metrics['change']['f1_macro']:.4f}" if dual else ""))
    return result


def train_model_local(model, dual, tr, va, te, device, epochs, lr, lam,
                      crit_s, crit_c, log_prefix=""):
    from common import _predict
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    from torch.optim.lr_scheduler import CosineAnnealingLR
    sched = CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-6)
    best, best_state, hist = -1.0, None, []
    for epoch in range(1, epochs + 1):
        model.train()
        loss_sum, n = 0.0, 0
        for batch in tr:
            x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
            opt.zero_grad()
            out = model(x)
            if dual:
                os_, oc = out
                loss = crit_s(os_, ys) + lam * crit_c(oc, yc)
            else:
                loss = crit_s(out, ys)
            loss.backward()
            opt.step()
            loss_sum += loss.item() * x.size(0)
            n += x.size(0)
        sched.step()
        model.eval()
        cs = cc = tv = 0
        with torch.no_grad():
            for batch in va:
                x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
                out = model(x)
                if dual:
                    os_, oc = out
                    cc += (oc.argmax(1) == yc).sum().item()
                else:
                    os_ = out
                cs += (os_.argmax(1) == ys).sum().item()
                tv += ys.numel()
        vas = cs / tv
        vac = (cc / tv) if dual else 0.0
        comb = (vas + vac) / 2 if dual else vas
        hist.append({"epoch": epoch, "loss": loss_sum / max(n, 1),
                     "val_static_acc": float(vas), "val_change_acc": float(vac),
                     "combined": float(comb)})
        if comb > best:
            best, best_state = comb, {k: v.detach().cpu().clone()
                                      for k, v in model.state_dict().items()}
        if epoch % 5 == 0 or epoch == 1 or epoch == epochs:
            print(f"  {log_prefix}Ep {epoch:2d}/{epochs} | Loss {loss_sum/max(n,1):.4f} "
                  f"| ValS {vas:.3f}" + (f" | ValC {vac:.3f}" if dual else ""))
    model.load_state_dict(best_state)
    pred_s, pred_c = _predict(model, te, device, dual)
    return best_state, pred_s, pred_c, hist, best


def build_report(results, out_root, seeds, lambdas):
    """Aggregate + paired stats + paper-ready markdown."""
    dual = [r for r in results if r["model"] == "DualTask"]
    single = [r for r in results if r["model"] == "SingleTask"]

    def sel(rs, key_outer, key_inner):
        return {r: [x[key_outer][key_inner] for x in rs] for r in [0]}

    # ---- per-lambda dual aggregates (over seeds) ----
    per_lam = {}
    for lam in lambdas:
        rs = [r for r in dual if r["lambda_change"] == lam]
        per_lam[lam] = {
            "n": len(rs),
            "static_acc": describe([r["static"]["accuracy"] for r in rs]),
            "iou_saline": describe([r["static"]["iou_saline"] for r in rs]),
            "f1_weighted": describe([r["static"]["f1_weighted"] for r in rs]),
            "f1_macro": describe([r["static"]["f1_macro"] for r in rs]),
            "kappa": describe([r["static"]["kappa"] for r in rs]),
            "change_acc": describe([r["change"]["accuracy"] for r in rs]),
            "change_f1_macro": describe([r["change"]["f1_macro"] for r in rs]),
        }
    single_agg = {
        "n": len(single),
        "static_acc": describe([r["static"]["accuracy"] for r in single]),
        "iou_saline": describe([r["static"]["iou_saline"] for r in single]),
        "f1_weighted": describe([r["static"]["f1_weighted"] for r in single]),
        "f1_macro": describe([r["static"]["f1_macro"] for r in single]),
        "kappa": describe([r["static"]["kappa"] for r in single]),
    }

    # ---- paired comparisons (same seed) ----
    def align(rs_a, key, lam=None):
        out = []
        for s in seeds:
            for r in rs_a:
                if r["seed"] == s and (lam is None or r["lambda_change"] == lam):
                    out.append(r["static"][key])
        return out

    s_iou = align(single, "iou_saline")
    paired = {}
    for lam in lambdas:
        d_iou = align([r for r in dual if r["lambda_change"] == lam], "iou_saline", lam)
        if len(d_iou) == len(s_iou) and len(d_iou) > 1:
            paired[str(lam)] = ttest_rel(d_iou, s_iou)

    agg = {
        "seeds": list(seeds),
        "lambdas": list(lambdas),
        "per_lambda_dual": per_lam,
        "single_task": single_agg,
        "paired_dual_minus_single_iou": paired,
        "raw_results": results,
    }
    write_json(os.path.join(out_root, "grid_results.json"), agg)

    # ---- markdown ----
    L = []
    L.append("# EXP-A — Multi-seed x lambda grid (ddof=1)\n")
    L.append(f"seeds = {list(seeds)} | lambdas = {list(lambdas)} | "
             f"n_seeds = {len(seeds)}\n")
    L.append("## Table A1. Dual-task static metrics by lambda (mean +/- sample std over seeds)\n")
    L.append("| lambda | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |")
    L.append("|---|---:|---|---|---|---|---|---|")
    for lam in lambdas:
        a = per_lam[lam]
        L.append(f"| {lam} | {a['n']} | {a['static_acc']['mean']:.4f}±{a['static_acc']['std_ddof1']:.4f} "
                 f"| {a['iou_saline']['mean']:.4f}±{a['iou_saline']['std_ddof1']:.4f} "
                 f"| {a['f1_weighted']['mean']:.4f}±{a['f1_weighted']['std_ddof1']:.4f} "
                 f"| {a['f1_macro']['mean']:.4f}±{a['f1_macro']['std_ddof1']:.4f} "
                 f"| {a['kappa']['mean']:.4f}±{a['kappa']['std_ddof1']:.4f} "
                 f"| {a['change_f1_macro']['mean']:.4f}±{a['change_f1_macro']['std_ddof1']:.4f} |")
    s = single_agg
    L.append(f"| single-task | {s['n']} | {s['static_acc']['mean']:.4f}±{s['static_acc']['std_ddof1']:.4f} "
             f"| {s['iou_saline']['mean']:.4f}±{s['iou_saline']['std_ddof1']:.4f} "
             f"| {s['f1_weighted']['mean']:.4f}±{s['f1_weighted']['std_ddof1']:.4f} "
             f"| {s['f1_macro']['mean']:.4f}±{s['f1_macro']['std_ddof1']:.4f} "
             f"| {s['kappa']['mean']:.4f}±{s['kappa']['std_ddof1']:.4f} | — |\n")
    L.append("## Table A2. Paired dual-task vs single-task, IoU(saline), same seeds\n")
    L.append("| lambda | mean delta IoU | t | df | p | 95% CI |")
    L.append("|---|---:|---:|---:|---:|---|")
    for lam in lambdas:
        pr = paired.get(str(lam))
        if pr:
            L.append(f"| {lam} | {pr['mean_diff']:+.4f} | {pr['t']:.3f} | {pr['df']} "
                     f"| {pr['p_value']:.4f} | [{pr['ci95'][0]:+.4f}, {pr['ci95'][1]:+.4f}] |")
        else:
            L.append(f"| {lam} | (insufficient seeds) | | | | |")
    L.append("")
    L.append("> Read: the defensible headline is the lambda=1.0 paired row "
             "(same seeds, same config). The best-lambda row shows where the "
             "dual-task head *can* help, but it must be reported as a "
             "lambda-selected value, not an unbiased estimate.\n")
    with open(os.path.join(out_root, "TABLE_multiseed_lambda.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    return agg


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    p.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    p.add_argument("--tag", default="expA_multiseed_lambda")
    p.add_argument("--seeds", default="42,123,2024")
    p.add_argument("--lambdas", default="1.0,0.3,0.5,0.7")
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--no-single", action="store_true",
                   help="skip the single-task paired baseline")
    p.add_argument("--cpu", action="store_true")
    args = p.parse_args()

    seeds = [int(x) for x in args.seeds.split(",") if x.strip()]
    lambdas = [float(x) for x in args.lambdas.split(",") if x.strip()]
    device = get_device(prefer_cuda=not args.cpu)
    out_root = os.path.join(args.out_dir, args.tag)
    makedirs(out_root, os.path.join(out_root, "runs"), os.path.join(out_root, "ckpts"))

    print(f"🖥️  device={device} | data={args.data_dir} | out={out_root}")
    print(f"🌱 seeds={seeds} | lambdas={lambdas} | epochs={args.epochs}")

    results = []
    # single-task baseline first (one per seed)
    if not args.no_single:
        for s in seeds:
            results.append(run_one("single", s, None, args.data_dir, out_root,
                                   device, args.epochs, args.batch_size, args.lr))
    # dual-task grid
    for lam in lambdas:
        for s in seeds:
            results.append(run_one("dual", s, lam, args.data_dir, out_root,
                                   device, args.epochs, args.batch_size, args.lr))

    build_report(results, out_root, seeds, lambdas)
    print(f"\n✅ EXP-A done. See {out_root}/TABLE_multiseed_lambda.md")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""exp_x_table1_8seed.py — 把 Table I 的 U-Net / Prithvi 从 3 seeds 补到 8 seeds。

为什么
------
Table I 目前 U-Net 与 Prithvi 是三种子（脚注已注明），但 ±0.0009 这种数字会被审稿人
当成错误（"3 seeds 不可能只有 8 seeds 的 1/13"）。补到八种子后：
  * 与 Tables II–VI 口径统一
  * 那个可疑的 ± 自然消失
  * J-12 / J-13 两条意见彻底关闭

做法
----
* U-Net：`expC_unet/runs/` 是**逐 run 一个 json**，所以只补缺的种子，已有的不重跑。
* Prithvi：`expG_prithvi/prithvi_results.json` 是**一个聚合文件**，重跑会覆盖，
  所以先备份，再用完整的八个种子重算（三种子那三条会被确定性地重算一遍）。

用法
----
    cd /root/autodl-tmp/QaidamPov

    python supp/exp_x_table1_8seed.py --report                # 只看现在有几个种子
    python supp/exp_x_table1_8seed.py --what unet             # 约 10 分钟
    python supp/exp_x_table1_8seed.py --what prithvi --prithvi-dir weights   # 约 32 分钟
    python supp/exp_x_table1_8seed.py --report                # 看补前/补后对比
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import shutil
import subprocess
import sys

import numpy as np

TARGET = [42, 123, 2024, 7, 13, 99, 777, 2025]   # 与 Tables II–VI 同一组八种子
OLD = [42, 123, 2024]


def load(p):
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def seeds_in_unet(runs_dir):
    out = set()
    for f in glob.glob(os.path.join(runs_dir, "*.json")):
        m = re.search(r"seed(\d+)", os.path.basename(f))
        if m:
            out.add(int(m.group(1)))
    return sorted(out)


def agg(runs, model, seeds, field):
    vals = []
    for r in runs:
        if r.get("model") != model or r.get("seed") not in seeds:
            continue
        x = r.get("static", {}).get(field)
        if isinstance(x, (int, float)):
            vals.append(x)
    if not vals:
        return None
    return (float(np.mean(vals)),
            float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
            len(vals))


def read_c_runs(root):
    runs = []
    for f in glob.glob(os.path.join(root, "expC_unet", "runs", "*.json")):
        try:
            runs.append(load(f))
        except Exception:
            pass
    return runs


def report(root):
    print(f"# Table I 种子审计：{root}\n")
    cr = read_c_runs(root)
    have = seeds_in_unet(os.path.join(root, "expC_unet", "runs"))
    print(f"U-Net 现有种子：{have}  （目标 {TARGET}）")
    miss = [s for s in TARGET if s not in have]
    print(f"U-Net 缺：{miss if miss else '无'}\n")

    def s(t):
        return "—（缺种子）" if not t else f"{t[0]:.4f} ± {t[1]:.4f}"

    print("| model | 子集 | n | Acc | F1 (w) | κ | IoU |")
    print("|---|---|---:|---|---|---|---|")
    for model in ("UNet-dual", "UNet-single"):
        for lab, sub in (("3 seeds", OLD), ("8 seeds", TARGET)):
            acc = agg(cr, model, sub, "accuracy")
            f1 = agg(cr, model, sub, "f1_weighted")
            kap = agg(cr, model, sub, "kappa")
            iou = agg(cr, model, sub, "iou_saline")
            print(f"| {model} | {lab} | {acc[2] if acc else 0} | {s(acc)} | {s(f1)} "
                  f"| {s(kap)} | {s(iou)} |")

    pth = os.path.join(root, "expG_prithvi", "prithvi_results.json")
    print("\nPrithvi：")
    if not os.path.exists(pth):
        print("  未找到 expG_prithvi/prithvi_results.json")
    else:
        p = load(pth)
        ind = p.get("individual", [])
        got = sorted({int(r.get("seed")) for r in ind if r.get("seed") is not None})
        st = p.get("aggregated", {}).get("static", {})
        print(f"  现有种子：{got}  （目标 {TARGET}）")
        for fld in ("accuracy", "f1_weighted", "kappa", "iou_saline"):
            v = st.get(fld)
            if isinstance(v, dict) and "mean" in v:
                print(f"  {fld:12s} = {v['mean']:.4f} ± {v.get('std', float('nan')):.4f}")

    print("\n补种子后，这些地方要同步改：")
    print("  Table I（U-Net 两行 + Prithvi 行）、Table II 的 Δ 列、Fig. 3b、")
    print("  §IV-B 正文、§V-C 里 0.8205 vs 0.8158 的对比。")


def run_unet(root):
    have = seeds_in_unet(os.path.join(root, "expC_unet", "runs"))
    miss = [x for x in TARGET if x not in have]
    if not miss:
        print("U-Net 八个种子齐了，无需补。")
        return
    proj = os.path.dirname(os.path.dirname(os.path.abspath(root)))
    cmd = [sys.executable, "-u", os.path.join(proj, "supp", "exp_c_unet_baseline.py"),
           "--mode", "both", "--seeds", ",".join(str(x) for x in miss), "--tag", "expC_unet"]
    print("运行：" + " ".join(cmd))
    subprocess.run(cmd, cwd=proj, check=False)
    print(f"\n完成。现在 U-Net 种子：{seeds_in_unet(os.path.join(root, 'expC_unet', 'runs'))}")


def run_prithvi(root, prithvi_dir=None):
    src = os.path.join(root, "expG_prithvi", "prithvi_results.json")
    if os.path.exists(src):
        bak = src + ".3seed.bak"
        if not os.path.exists(bak):
            shutil.copy2(src, bak)
            print(f"[backup] {bak}")
    proj = os.path.dirname(os.path.dirname(os.path.abspath(root)))
    cmd = [sys.executable, "-u", os.path.join(proj, "supp", "exp_g_prithvi_rerun.py"),
           "--seeds", ",".join(str(x) for x in TARGET), "--tag", "expG_prithvi"]
    if prithvi_dir:
        cmd += ["--prithvi-dir", prithvi_dir]
    print("运行：" + " ".join(cmd))
    subprocess.run(cmd, cwd=proj, check=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default=os.environ.get("PROJECT_DIR", "/root/autodl-tmp/QaidamPov"))
    ap.add_argument("--root", default=None, help="supplementary 目录，默认 <project>/results/supplementary")
    ap.add_argument("--what", choices=["unet", "prithvi", "all"], default=None)
    ap.add_argument("--prithvi-dir", default=None)
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--dry", action="store_true")
    a = ap.parse_args()

    root = a.root or os.path.join(a.project, "results", "supplementary")
    if not os.path.isdir(root):
        sys.exit(f"[fatal] 目录不存在：{root}\n        用 --root 指定真实的 supplementary 目录")

    if a.what is None:
        report(root)
        print("\n（只做审计。补种子：--what unet / --what prithvi / --what all）")
        return

    if a.dry:
        have = seeds_in_unet(os.path.join(root, "expC_unet", "runs"))
        print(f"[dry] U-Net 现有 {have}，将补 {[s for s in TARGET if s not in have]}")
        return

    if a.what in ("unet", "all"):
        run_unet(root)
    if a.what in ("prithvi", "all"):
        run_prithvi(root, a.prithvi_dir)

    print("\n=== 补后审计 ===")
    report(root)


if __name__ == "__main__":
    main()

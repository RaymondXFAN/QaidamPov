#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exp_u_ablation_all.py — 把受控消融（EXP-T）扩到四个模型族。

背景
----
EXP-T 对 U-Net 做了「删掉与评测集重叠的 48 个训练 patch」的受控消融，得到：
    Δ_seen +4.94pp / Δ_unseen +3.55pp（安慰剂）/ DiD +1.39pp
但论文里"泄漏惩罚随架构变化"目前只能写成描述性，因为跨协议比较的两个测试集不同。
本脚本对每个模型族各做一次同样的消融：
    同架构、同超参、同种子、同评测集 E，唯一变量 = 训练集里有没有那 48 个 patch。

支持的族
--------
    unet     U-Net（skip-connected 分割器）
    cnn      6.10M 编解码器（无 skip）
    prithvi  Prithvi-EO-1.0 + LoRA（token 解码器，dual 头，λ=1）
    pixel    RF / XGB（无空间上下文；像素抽样种子作为配对单元）

产出
----
<out>/<family>/with/with_seed{S}.json
<out>/<family>/without/without_seed{S}.json      （per_patch: md5/tp/fp/fn）
<out>/TABLE_ablation_all.md                       （--compare）

用法
----
python exp_u_ablation_all.py --family unet --precheck         # 1 种子 1 epoch 快检
python exp_u_ablation_all.py --family cnn
python exp_u_ablation_all.py --family pixel
python exp_u_ablation_all.py --family prithvi --prithvi-dir /path/to/weights
python exp_u_ablation_all.py --compare
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exp_r_did import tstat_ci, signflip_p, iou_from_counts, pool   # noqa: E402

DEFAULT_SEEDS = "7,13,42,99,123,777,2024,2025"


# ------------------------------------------------------------------ helpers
def md5_of(a):
    return hashlib.md5(np.ascontiguousarray(a, dtype=np.float32).tobytes()).hexdigest()


def resolve_dirs(project):
    P = next((c for c in (f"{project}/data/data_geoaux",
                          f"{project}/results/supplementary/data_geoaux")
              if os.path.isdir(c)), None)
    E = next((c for c in (f"{project}/data/data_grouped_geoaux",
                          f"{project}/results/supplementary/expD_spatial/data_grouped_geoaux")
              if os.path.isdir(c)), None)
    return P, E


def counts(pred, gt):
    pred = np.asarray(pred).astype(np.int64)
    gt = np.asarray(gt).astype(np.int64)
    return {"tp": int(((pred == 1) & (gt == 1)).sum()),
            "fp": int(((pred == 1) & (gt == 0)).sum()),
            "fn": int(((pred == 0) & (gt == 1)).sum())}


# ------------------------------------------------------------------ deep path
def run_deep(args, family, PATCH, EVAL, x_tr, ys_tr, yc_tr, arms, x_ev, ys_ev, yc_ev,
             seen_md5, EVAL_MD5):
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
    from common import (UNet, SingleTaskModel, DualTaskModel, DualDataset,
                        load_split, train_stats, set_seed, get_device, train_model, _predict)

    torch.backends.cudnn.benchmark = True
    dev = get_device(not args.cpu)

    if family == "prithvi":
        import exp_g_prithvi_rerun as eg
        if eg.timm is None:
            sys.exit("[fatal] 需要 timm")
        search = [args.prithvi_dir] if args.prithvi_dir else [
            os.path.join(args.project, "weights"),
            os.path.join(args.project, "ckpts"),
            args.project]
        ckpt = eg.find_prithvi_checkpoint(search)
        if ckpt is None:
            sys.exit("[fatal] 找不到 Prithvi_100M.pt，用 --prithvi-dir 指定目录")

    va_x, va_ys, va_yc = load_split(PATCH, "val")

    for arm, sel in arms:
        outdir = os.path.join(args.out, family, arm)
        os.makedirs(outdir, exist_ok=True)
        xs, yss, ycs = x_tr[sel], ys_tr[sel], yc_tr[sel]
        mean, std = train_stats(xs)
        for seed in args.seed_list:
            tag = f"{arm}_seed{seed}"
            outp = os.path.join(outdir, f"{tag}.json")
            if os.path.exists(outp) and not args.force:
                print(f"[skip] {family}/{tag}")
                continue
            set_seed(seed)
            dual = family in ("prithvi",)          # Prithvi 按论文用 dual
            tr = DataLoader(DualDataset(xs, yss, ycs, mean, std, augment=True),
                            batch_size=args.batch_size, shuffle=True, num_workers=2)
            va = DataLoader(DualDataset(va_x, va_ys, va_yc, mean, std, augment=False),
                            batch_size=args.batch_size, shuffle=False, num_workers=2)
            ev = DataLoader(DualDataset(x_ev, ys_ev, yc_ev, mean, std, augment=False),
                            batch_size=args.batch_size, shuffle=False, num_workers=2)

            if family == "unet":
                model = UNet(in_channels=xs.shape[1], num_classes=2,
                             num_change_classes=4, base=args.base, dual=False).to(dev)
            elif family == "cnn":
                model = SingleTaskModel(in_channels=xs.shape[1], num_classes=2).to(dev)
            else:
                model = eg.PrithviDualTaskModel(img_size=128, in_channels=xs.shape[1],
                                                lora_r=args.lora_r,
                                                lora_alpha=args.lora_alpha).to(dev)
                eg.load_prithvi_weights(model, ckpt)

            # 与论文 Table I/II 完全同一套加权方案（clamped），保证消融的 A/B/C
            # 与主表口径一致；否则同一配置在两处会差 1–2 pp。
            from common import compute_class_weights
            ws, wc = compute_class_weights(yss, ycs, dev)
            crit_s = nn.CrossEntropyLoss(weight=ws)
            crit_c = nn.CrossEntropyLoss(weight=wc)

            t0 = time.time()
            print(f"\n{'='*66}\n[{family}/{tag}] n_train={len(xs)} epochs={args.epochs}\n{'='*66}", flush=True)
            _, pred_s, _, hist, best = train_model(
                model, dual, tr, va, ev, dev, args.epochs, args.lr,
                args.lambda_change, crit_s, crit_c, log_prefix=f"[{family}|{arm}] ")
            dt = (time.time() - t0) / 60
            rows = []
            for i in range(len(x_ev)):
                c = counts(pred_s[i], np.asarray(ys_ev[i]))
                c["md5"] = md5_of(np.asarray(x_ev[i], np.float32))
                rows.append(c)
            hit = sum(1 for r in rows if r["md5"] in EVAL_MD5)
            json.dump({"name": tag, "family": family, "protocol": arm, "seed": seed,
                       "n_train": len(xs), "epochs": args.epochs, "best_val": float(best),
                       "minutes": round(dt, 1), "per_patch": rows},
                      open(outp, "w", encoding="utf-8"), indent=1)
            print(f"[{family}/{tag}] {dt:.1f} min | best_val={best:.4f} | patches={hit}", flush=True)


# ----------------------------------------------------------------- pixel path
def run_pixel(args, PATCH, EVAL, x_tr, ys_tr, arms, x_ev, ys_ev):
    from sklearn.ensemble import RandomForestClassifier
    try:
        from xgboost import XGBClassifier
    except ImportError:
        XGBClassifier = None

    n, ch = x_ev.shape[0], x_ev.shape[1]
    Xe = np.asarray(x_ev, np.float32).transpose(0, 2, 3, 1).reshape(-1, ch)

    for clf in args.classifiers:
        if clf == "xgb" and XGBClassifier is None:
            print("[warn] 没有 xgboost，跳过 xgb")
            continue
        for arm, sel in arms:
            outdir = os.path.join(args.out, f"pixel_{clf}", arm)
            os.makedirs(outdir, exist_ok=True)
            xt = np.asarray(x_tr[sel], np.float32).transpose(0, 2, 3, 1).reshape(-1, ch)
            yt = np.asarray(ys_tr[sel]).reshape(-1)
            for seed in args.seed_list:
                tag = f"{arm}_seed{seed}"
                outp = os.path.join(outdir, f"{tag}.json")
                if os.path.exists(outp) and not args.force:
                    print(f"[skip] pixel_{clf}/{tag}")
                    continue
                rng = np.random.RandomState(seed)
                if args.max_pixels and args.max_pixels < len(xt):
                    idx = []
                    for cls in (0, 1):      # 分层抽样
                        ii = np.where(yt == cls)[0]
                        k = int(round(args.max_pixels * len(ii) / len(yt)))
                        idx.append(rng.choice(ii, min(k, len(ii)), replace=False))
                    idx = np.concatenate(idx)
                else:
                    idx = np.arange(len(xt))
                t0 = time.time()
                if clf == "rf":
                    clf_obj = RandomForestClassifier(
                        n_estimators=args.n_trees, n_jobs=-1, random_state=seed,
                        min_samples_leaf=1, max_features="sqrt")
                else:
                    clf_obj = XGBClassifier(
                        n_estimators=args.n_trees, max_depth=6, learning_rate=0.1,
                        subsample=0.8, colsample_bytree=0.8, tree_method="hist",
                        n_jobs=-1, random_state=seed, eval_metric="logloss")
                clf_obj.fit(xt[idx], yt[idx])
                pe = clf_obj.predict(Xe).reshape(n, 128, 128)
                rows = []
                for i in range(n):
                    c = counts(pe[i], np.asarray(ys_ev[i]))
                    c["md5"] = md5_of(np.asarray(x_ev[i], np.float32))
                    rows.append(c)
                json.dump({"name": tag, "family": f"pixel_{clf}", "protocol": arm,
                           "seed": seed, "n_train": int(len(sel)),
                           "n_pixels": int(len(idx)),
                           "minutes": round((time.time() - t0) / 60, 1),
                           "per_patch": rows},
                          open(outp, "w", encoding="utf-8"), indent=1)
                print(f"[pixel_{clf}/{tag}] done in {(time.time()-t0)/60:.1f} min", flush=True)
                del clf_obj


# --------------------------------------------------------------------- main
def run(args):
    project = args.project
    PATCH = args.patch_dir or resolve_dirs(project)[0]
    EVAL = args.eval_dir or resolve_dirs(project)[1]
    if not PATCH or not EVAL:
        sys.exit("[fatal] 找不到 data_geoaux / data_grouped_geoaux")

    idx = json.load(open(args.index, encoding="utf-8"))
    seen_md5 = {r["md5"] for r in idx["E"] if r["seen_in_training"]}
    eval_md5 = {r["md5"] for r in idx["E"]}
    print(f"[paths] PATCH={PATCH}\n[paths] EVAL={EVAL}\n[family] {args.family}\n[arm] {args.arm}")

    from common import load_split
    if args.arm == "tile":
        # 阶段 C：用 tile 级训练集（异瓦片），评测集仍是 E
        x_tr, ys_tr, yc_tr = load_split(EVAL, "train")
        arms = [("tile", list(range(len(x_tr))))]
        PATCH_TRAIN = EVAL
        print(f"[data] stage C: train={len(x_tr)}（异瓦片）  E={len(idx['E'])}")
    else:
        x_tr, ys_tr, yc_tr = load_split(PATCH, "train")
        mds = [md5_of(a) for a in x_tr]
        drop = [i for i, m in enumerate(mds) if m in seen_md5]
        keep = [i for i, m in enumerate(mds) if m not in seen_md5]
        arms = [("with", list(range(len(x_tr)))), ("without", keep)]
        PATCH_TRAIN = PATCH
        print(f"[data] train={len(x_tr)}  drop={len(drop)}  keep={len(keep)}")
        if len(drop) != len(seen_md5):
            print(f"[warn] 期望剔除 {len(seen_md5)}，实际 {len(drop)}")

    x_ev, ys_ev, yc_ev = load_split(EVAL, "test")
    print(f"[data] E={x_ev.shape[0]}")

    if args.family == "pixel":
        run_pixel(args, PATCH_TRAIN, EVAL, x_tr, ys_tr, arms, x_ev, ys_ev)
    else:
        run_deep(args, args.family, PATCH_TRAIN, EVAL, x_tr, ys_tr, yc_tr, arms,
                 x_ev, ys_ev, yc_ev, seen_md5, eval_md5)


# ------------------------------------------------------------------ compare
def compare(args):
    idx = json.load(open(args.index, encoding="utf-8"))
    seen = {r["md5"]: r["seen_in_training"] for r in idx["E"]}
    fams = sorted(d for d in os.listdir(args.out)
                  if os.path.isdir(os.path.join(args.out, d, "with")))
    if not fams:
        sys.exit("[fatal] 没有产出，先跑 --family")

    def load(fam, arm):
        o = {}
        d = os.path.join(args.out, fam, arm)
        for f in glob.glob(os.path.join(d, "*.json")):
            j = json.load(open(f, encoding="utf-8"))
            o[j["seed"]] = j["per_patch"]
        return o

    rows_all = []
    for fam in fams:
        A, B, C = load(fam, "with"), load(fam, "without"), load(fam, "tile")
        seeds = sorted(set(A) & set(B))
        for s in seeds:
            def grp(pc, want):
                return [p for p in pc if p["md5"] in seen and seen[p["md5"]] is want]
            r = {"family": fam, "seed": s}
            r["a_all"] = iou_from_counts(pool(A[s]))
            r["b_all"] = iou_from_counts(pool(B[s]))
            r["c_all"] = iou_from_counts(pool(C[s])) if s in C else float("nan")
            r["d_seen"] = (iou_from_counts(pool(grp(A[s], True)))
                           - iou_from_counts(pool(grp(B[s], True))))
            r["d_unseen"] = (iou_from_counts(pool(grp(A[s], False)))
                             - iou_from_counts(pool(grp(B[s], False))))
            r["did"] = r["d_seen"] - r["d_unseen"]
            rows_all.append(r)

    L = ["# EXP-U — 四族受控消融（同架构 / 同超参 / 同种子 / 同评测集 E）", "",
         "臂 A = patch 级全量（含 E 的 48 个）；B = 删掉那 48 个；C = tile 级（异瓦片）。",
         "A−B = 删重复的总代价；B−C = 留瓦片的代价；DiD = 扣掉安慰剂后的纯重复效应。", ""]

    L += ["| family | n | A | B | C | A−B | B−C | **DiD** | DiD/(A−C) |",
          "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    summary = {}
    for fam in fams:
        rs = [r for r in rows_all if r["family"] == fam]
        if not rs:
            continue
        def m(k):
            v = np.array([r[k] for r in rs], dtype=float)
            v = v[~np.isnan(v)]
            return float(v.mean()) if len(v) else float("nan")
        d = np.array([r["did"] for r in rs], dtype=float)
        t, lo, hi = tstat_ci(d) if len(d) > 1 else (np.nan, np.nan, np.nan)
        pp = signflip_p(d) if len(d) >= 3 else float("nan")
        tot = m("a_all") - m("c_all")
        share = (d.mean() / tot) if tot and not np.isnan(tot) else float("nan")
        summary[fam] = {"n": len(rs), "A": m("a_all"), "B": m("b_all"), "C": m("c_all"),
                        "ab": (m("a_all") - m("b_all")) * 100,
                        "bc": (m("b_all") - m("c_all")) * 100,
                        "d_seen": m("d_seen") * 100, "d_unseen": m("d_unseen") * 100,
                        "did": d.mean() * 100, "lo": lo * 100, "hi": hi * 100,
                        "p_perm": float(pp), "same_sign": int((d > 0).sum()),
                        "share_dup": share * 100}
        L.append(f"| {fam} | {len(rs)} | {m('a_all'):.4f} | {m('b_all'):.4f} | "
                 f"{m('c_all'):.4f} | {(m('a_all')-m('b_all'))*100:+.2f}pp | "
                 f"{(m('b_all')-m('c_all'))*100:+.2f}pp | **{d.mean()*100:+.2f}pp** | "
                 f"{share*100:.0f}% |")

    L += ["", "## 逐族 DiD 细节", "",
          "| family | Δ_seen | Δ_unseen（安慰剂） | DiD | 95% CI | p(perm) | 同号 |",
          "|---|---:|---:|---:|---|---:|---|"]
    for fam in fams:
        v = summary.get(fam)
        if not v:
            continue
        L.append(f"| {fam} | {v['d_seen']:+.2f}pp | {v['d_unseen']:+.2f}pp | "
                 f"**{v['did']:+.2f}pp** | [{v['lo']:+.2f}, {v['hi']:+.2f}] | "
                 f"{v['p_perm']:.4f} | {v['same_sign']}/{v['n']} |")

    L += ["", "按 DiD 排序："]
    for fam, v in sorted(summary.items(), key=lambda x: -x[1]["did"]):
        L.append(f"- {fam}: {v['did']:+.2f}pp（占该族总协议差距 {v['share_dup']:.0f}%）")

    md = os.path.join(args.out, "TABLE_ablation_all.md")
    open(md, "w", encoding="utf-8").write("\n".join(L))
    json.dump({"rows": rows_all, "summary": summary},
              open(os.path.join(args.out, "ablation_all.json"), "w"), indent=1)
    print("\n".join(L))
    print(f"\n[write] {md}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default="/root/autodl-tmp/QaidamPov")
    ap.add_argument("--patch-dir", default=None)
    ap.add_argument("--eval-dir", default=None)
    ap.add_argument("--index", default="/root/autodl-tmp/QaidamPov/results/supplementary/common_test/common_index.json")
    ap.add_argument("--out", default="/root/autodl-tmp/QaidamPov/results/supplementary/expU_ablation")
    ap.add_argument("--family", choices=["unet", "cnn", "prithvi", "pixel"], default="unet")
    ap.add_argument("--arm", choices=["ab", "tile"], default="ab",
                    help="ab=受控消融两臂；tile=阶段 C（异瓦片训练集，评测集仍为 E）")
    ap.add_argument("--classifiers", default="rf,xgb")
    ap.add_argument("--seeds", default=DEFAULT_SEEDS)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--base", type=int, default=32)
    ap.add_argument("--lambda-change", type=float, default=1.0)
    ap.add_argument("--lora-r", type=int, default=8)
    ap.add_argument("--lora-alpha", type=int, default=16)
    ap.add_argument("--prithvi-dir", default=None)
    ap.add_argument("--max-pixels", type=int, default=800000)
    ap.add_argument("--n-trees", type=int, default=200)
    ap.add_argument("--precheck", action="store_true")
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--cpu", action="store_true")
    a = ap.parse_args()
    if a.classifiers:
        a.classifiers = [c.strip() for c in a.classifiers.split(",") if c.strip()]
    if a.precheck:
        a.seeds, a.epochs = "42", 1
        a.out = a.out.rstrip("/") + "_precheck"
        a.max_pixels = min(a.max_pixels, 50000)
        print(f"[precheck] family={a.family} out={a.out}")
    a.seed_list = [int(s) for s in a.seeds.split(",") if s.strip()]
    if a.compare:
        compare(a)
    else:
        run(a)


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# run_expV_W.sh — 补两个实验的总控（幂等：已跑过的会自动 skip）
#
#   EXP-V  C′ 样本量匹配臂   → 拆开 B→C 的两重变化（空间来源 vs 样本量）
#   EXP-W  四族复制批        → 新种子 1001–1008 重跑 A/B，检验"单调梯度"不是一批种子的偶然
#
# 用法
#   bash supp/run_expV_W.sh precheck     # 闸门：每族 1 seed / 1 epoch，必须看到 json 落盘
#   bash supp/run_expV_W.sh matched      # C′：五族 × 8 seeds
#   bash supp/run_expV_W.sh replicate    # 复制：四族 × 8 seeds（A/B 两臂）
#   bash supp/run_expV_W.sh compare      # 出两张表
#   bash supp/run_expV_W.sh status       # 非阻塞看进度
#   bash supp/run_expV_W.sh all          # precheck → matched → replicate → compare
#
# 预计耗时（4090，参考值）：precheck 约 6 分钟；matched 约 1.5 小时；replicate 约 1.5 小时

set -uo pipefail

# 自动定位项目根：优先含 results/supplementary 的那个
if [ -z "${PROJECT:-}" ]; then
  for c in /root/autodl-tmp/QaidamPov /root/autodl-tmp/QaidamSalineBench ./; do
    [ -d "$c/results/supplementary" ] && { PROJECT="$c"; break; }
  done
fi
PROJECT="${PROJECT:-/root/autodl-tmp/QaidamPov}"
cd "$PROJECT" || { echo "[fatal] 进不去 $PROJECT"; exit 1; }
export PYTHONPATH="$PROJECT/supp:${PYTHONPATH:-}"
echo "[env] PROJECT=$PROJECT"
echo "[env] PYTHONPATH=$PYTHONPATH"

# 有些镜像把 OMP_NUM_THREADS 设成空串，libgomp 会报 Invalid value
case "${OMP_NUM_THREADS:-}" in
  ""|*[!0-9]*) export OMP_NUM_THREADS=8 ;;
esac
PY="${PY:-python}"

# 代码目录（脚本 .py 所在处）可能与结果目录不同
if [ -z "${CODE_DIR:-}" ]; then
  for c in "$PROJECT/supp" /root/autodl-tmp/QaidamPov/supp /root/autodl-tmp/QaidamSalineBench/supp; do
    [ -f "$c/exp_u_ablation_all.py" ] && { CODE_DIR="$c"; break; }
  done
fi
CODE_DIR="${CODE_DIR:-$PROJECT/supp}"
echo "[env] CODE_DIR=$CODE_DIR"
SEEDS8="7,13,42,99,123,777,2024,2025"
SEEDS_NEW="1001,1002,1003,1004,1005,1006,1007,1008"
OUT_V="$PROJECT/results/supplementary/expV_matched"
OUT_W="$PROJECT/results/supplementary/expW_replicate"
for c in "$PROJECT/results/supplementary/expU_ablation_all" "$PROJECT/results/supplementary/expU_ablation"; do
  [ -d "$c" ] && { BASE_U="$c"; break; }; done
BASE_U="${BASE_U:-$PROJECT/results/supplementary/expU_ablation}"
mkdir -p logs

# Prithvi 权重自动探测
PRITHVI_ARG=""
for d in "$PROJECT/weights" "$CODE_DIR/../weights" "$PROJECT/ckpts" "$PROJECT"; do
  if ls "$d"/Prithvi*100M*.pt >/dev/null 2>&1; then PRITHVI_ARG="--prithvi-dir $d"; break; fi
done
if [ -z "$PRITHVI_ARG" ]; then
  echo "[warn] 没找到 Prithvi_100M.pt，prithvi 族会被跳过（其余照跑）"
fi

log(){ echo "[$(date +%H:%M:%S)] $*"; }

# ---------------------------------------------------------------- 闸门
# 族名 → 实际输出子目录（pixel 族会分叉成 pixel_rf / pixel_xgb）
fam_dirs(){
  case "$1" in
    pixel) echo "pixel_rf pixel_xgb" ;;
    *)     echo "$1" ;;
  esac
}

gate_fam(){  # gate_fam <outroot> <fam> <arm>
  local root="$1" fam="$2" arm="$3" d
  for d in $(fam_dirs "$fam"); do
    compgen -G "$root/$d/$arm/*.json" >/dev/null || return 1
  done
  local n=0
  for d in $(fam_dirs "$fam"); do
    n=$((n + $(ls "$root/$d/$arm/"*.json 2>/dev/null | wc -l)))
  done
  echo "$n"
}

gate(){  # gate <tag> <expect_json_glob>
  local tag="$1" pat="$2"
  if compgen -G "$pat" >/dev/null; then
    log "  ✅ $tag 产出已存在：$(ls $pat | wc -l) 个"
    return 0
  fi
  return 1
}

do_precheck(){
  log "=== 预检闸门（1 seed / 1 epoch）==="
  rm -rf "$OUT_V"_precheck
  log "  已清空 $(basename "$OUT_V")_precheck（防止陈旧 json 被 [skip] 当成已完成）"
  FAIL=0
  for fam in unet cnn pixel; do
    log "  > $fam"
    timeout 1200 $PY -u "$CODE_DIR/exp_v_matched_arm.py" --project "$PROJECT" \
        --family "$fam" --precheck > "logs/v_precheck_$fam.log" 2>&1
    rc=$?
    if N=$(gate_fam "$OUT_V"_precheck "$fam" matched); then
      log "    rc=$rc  ✅ 落盘 ${N} 个"
    else
      log "    rc=$rc  ❌ 未落盘，日志尾部："; tail -n 25 "logs/v_precheck_$fam.log"; FAIL=1
    fi
  done
  if [ -n "$PRITHVI_ARG" ]; then
    log "  > prithvi"
    timeout 2400 $PY -u "$CODE_DIR/exp_v_matched_arm.py" --project "$PROJECT" \
        --family prithvi $PRITHVI_ARG --precheck > logs/v_precheck_prithvi.log 2>&1
    rc=$?
    if N=$(gate_fam "$OUT_V"_precheck prithvi matched); then
      log "    rc=$rc  ✅ 落盘 ${N} 个"
    else
      log "    rc=$rc  ❌ 未落盘，日志尾部："; tail -n 25 logs/v_precheck_prithvi.log; FAIL=1
    fi
  fi
  if [ "$FAIL" -ne 0 ]; then
    log "预检失败，中止。修好再跑 —— 不要带着假完成去跑全量。"
    exit 1
  fi
  log "预检全部通过。可以跑全量。"
  rm -rf "$OUT_V"_precheck
  return 0
}

# ---------------------------------------------------------------- C′
do_matched(){
  log "=== EXP-V：C′ 匹配臂（232 块，异瓦片，五族 × 8 seeds）==="
  for fam in unet cnn pixel; do
    log "  > $fam"
    $PY -u "$CODE_DIR/exp_v_matched_arm.py" --project "$PROJECT" --family "$fam" \
        --seeds "$SEEDS8" > "logs/v_$fam.log" 2>&1
    rc=$?; log "    rc=$rc （logs/v_$fam.log）"
    if [ "$rc" -ne 0 ]; then log "    ❌ 失败，末尾日志："; tail -n 15 "logs/v_$fam.log"; fi
  done
  if [ -n "$PRITHVI_ARG" ]; then
    log "  > prithvi"
    $PY -u "$CODE_DIR/exp_v_matched_arm.py" --project "$PROJECT" --family prithvi \
        $PRITHVI_ARG --seeds "$SEEDS8" > logs/v_prithvi.log 2>&1
    rc=$?; log "    rc=$rc"; if [ "$rc" -ne 0 ]; then tail -n 15 logs/v_prithvi.log; fi
  else
    log "  [skip] prithvi（无权重）"
  fi
  return 0
}

# ---------------------------------------------------------------- 复制批
do_replicate(){
  log "=== EXP-W：四族复制批（新种子 1001–1008，A/B 两臂）==="
  for fam in cnn pixel; do
    log "  > $fam"
    $PY -u "$CODE_DIR/exp_u_ablation_all.py" --project "$PROJECT" --family "$fam" \
        --seeds "$SEEDS_NEW" --out "$OUT_W" > "logs/w_$fam.log" 2>&1
    rc=$?; log "    rc=$rc （logs/w_$fam.log）"
    if [ "$rc" -ne 0 ]; then log "    ❌ 失败，末尾日志："; tail -n 15 "logs/w_$fam.log"; fi
  done
  if [ -n "$PRITHVI_ARG" ]; then
    log "  > prithvi"
    $PY -u "$CODE_DIR/exp_u_ablation_all.py" --project "$PROJECT" --family prithvi \
        $PRITHVI_ARG --seeds "$SEEDS_NEW" --out "$OUT_W" > logs/w_prithvi.log 2>&1
    rc=$?; log "    rc=$rc"; if [ "$rc" -ne 0 ]; then tail -n 15 logs/w_prithvi.log; fi
  else
    log "  [skip] prithvi（无权重）"
  fi
  # U-Net 的 A/B 已在上一批复制里跑过（1001–1008），如需并入本目录：
  log "  提示：U-Net 的 1001–1008 复制结果若在别处，可 cp 进 $OUT_W/unet/{with,without}/ 后一起 compare"
  return 0
}

# ---------------------------------------------------------------- 汇总
do_compare(){
  log "=== 汇总 ==="
  log "  [check] C′ 产出："
  for f in unet cnn prithvi pixel_rf pixel_xgb; do
    [ -d "$OUT_V/$f" ] && log "    $f: $(ls "$OUT_V/$f/matched/"*.json 2>/dev/null | wc -l) / 8"
  done
  log "  [check] 复制批产出："
  for f in unet cnn prithvi pixel_rf pixel_xgb; do
    if [ -d "$OUT_W/$f" ]; then
      log "    $f: with=$(ls "$OUT_W/$f/with/"*.json 2>/dev/null | wc -l) without=$(ls "$OUT_W/$f/without/"*.json 2>/dev/null | wc -l)"
    fi
  done
  if [ ! -d "$OUT_W" ] || [ -z "$(ls -A "$OUT_W" 2>/dev/null)" ]; then
    log "  ⚠ $OUT_W 为空 —— 复制批还没跑，跳过它的汇总（先跑：bash $0 replicate）"
  fi
  if [ -d "$OUT_V" ]; then
    $PY -u "$CODE_DIR/exp_v_matched_arm.py" --project "$PROJECT" --compare 2>&1 | tee logs/v_compare.log
    log "  → $OUT_V/TABLE_matched.md"
  else
    log "  [skip] C′ 无产出"
  fi
  if [ -d "$OUT_W" ]; then
    $PY -u "$CODE_DIR/exp_u_ablation_all.py" --project "$PROJECT" --out "$OUT_W" --compare 2>&1 | tee logs/w_compare.log
    log "  → $OUT_W/TABLE_ablation_all.md"
  else
    log "  [skip] 复制批无产出"
  fi
  return 0
}

do_status(){
  echo "--- C′（期望 5 族 × 8 = 40） ---"
  for fam in unet cnn prithvi pixel; do
    if [ "$fam" = "pixel" ]; then
      a=$(ls "$OUT_V/pixel_rf/matched/"*.json 2>/dev/null | wc -l)
      b=$(ls "$OUT_V/pixel_xgb/matched/"*.json 2>/dev/null | wc -l)
      [ $((a+b)) -gt 0 ] && echo "  pixel: rf=${a}/8 xgb=${b}/8"
    else
      n=$(gate_fam "$OUT_V" "$fam" matched 2>/dev/null) || n=0
      [ "${n:-0}" -gt 0 ] && echo "  $fam: ${n} / 8"
    fi
  done
  echo "--- 复制批（期望 4 族 × 8 × 2 = 64） ---"
  for fam in unet cnn prithvi pixel; do
    a=$(ls "$OUT_W/$fam/with/"*.json 2>/dev/null | wc -l)
    b=$(ls "$OUT_W/$fam/without/"*.json 2>/dev/null | wc -l)
    [ -d "$OUT_W/$fam" ] && echo "  $fam: with=${a:-0} without=${b:-0} / 8"
  done
  echo "--- GPU ---"
  nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader 2>/dev/null || echo "  (无 nvidia-smi)"
  echo "--- 最近日志 ---"
  ls -t logs/v_*.log logs/w_*.log 2>/dev/null | head -3 | while read f; do echo "== $f"; tail -n 3 "$f"; done
}

case "${1:-}" in
  precheck)  do_precheck ;;
  matched)   do_matched ;;
  replicate) do_replicate ;;
  compare)   do_compare ;;
  status)    do_status ;;
  all)       do_precheck && do_matched && do_replicate && do_compare ;;
  *) sed -n '2,20p' "$0" ;;
esac

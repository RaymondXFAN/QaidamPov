#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-M — build a CLEAN auxiliary task, free of WorldCover product-version drift.

Why this exists
---------------
The paper's published auxiliary head predicts the 2020→2021 four-class change
map. But 2020 comes from WorldCover v100 and 2021 from v200: two product
versions, not two epochs of one product. The auxiliary label is therefore partly
noise, and a reviewer can (rightly) say "of course a head trained on a corrupted
label buys nothing — you have not tested multi-task learning, you have tested
label noise."

This script builds a replacement auxiliary label that is *derived from the 2020
static label alone*, so no product-version difference can enter it:

    class 0 : non-saline
    class 1 : saline, within 2 px of a non-saline pixel   (fringe)
    class 2 : saline, 2-6 px inside                       (shoulder)
    class 3 : saline, more than 6 px inside               (core)

i.e. Euclidean depth into the saline body. It is a geometric, self-consistent
task that the same encoder can learn, and it is immune to v100→v200 drift.

Run the existing λ grid on the resulting directory and the sentence becomes
defensible either way:

    python exp_a_multiseed_lambda.py --data-dir <...>/data_geoaux --tag expA_geoaux

Usage
  python exp_m_clean_aux.py --src-dir "$PROJECT_DIR/data/processed_dual" \
      --dst-dir "$PROJECT_DIR/data/data_geoaux"
"""
import argparse
import json
import os
import shutil

import numpy as np

try:
    from scipy.ndimage import distance_transform_edt
    HAVE_SCIPY = True
except Exception:                                       # pragma: no cover
    HAVE_SCIPY = False

BINS = (2, 6)          # depth bins in pixels


def depth_map_2d(ys):
    """Distance (in pixels) from each saline pixel to the nearest non-saline one.

    MUST be called on a single 2-D patch.  Passing the whole (N, H, W) stack to
    distance_transform_edt silently measures distance in 3-D, so a pixel can be
    "close to background" through a neighbouring patch and every depth collapses
    to ~1.  The self-test caught exactly that; the per-patch loop below is the fix.
    """
    if HAVE_SCIPY:
        return distance_transform_edt(ys.astype(np.uint8)).astype(np.float32)
    # numpy fallback: count how many 4-neighbour erosions a pixel survives
    maxsteps = 32
    d = np.zeros(ys.shape, dtype=np.float32)
    cur = ys == 1
    k = 0
    while cur.any() and k < maxsteps:
        d[cur] = k
        nxt = cur.copy()
        nxt[:, 1:] &= cur[:, :-1]
        nxt[:, :-1] &= cur[:, 1:]
        nxt[1:, :] &= cur[:-1, :]
        nxt[:-1, :] &= cur[1:, :]
        cur = nxt
        k += 1
    d[cur] = k
    return d


def build_patch(ys2d):
    out = np.zeros_like(ys2d, dtype=np.int64)
    d = depth_map_2d(ys2d)
    sal = ys2d == 1
    out[sal & (d <= BINS[0])] = 1
    out[sal & (d > BINS[0]) & (d <= BINS[1])] = 2
    out[sal & (d > BINS[1])] = 3
    return out


def build_split(ys):
    """ys: (H, W) or (N, H, W) -> same shape, classes {0,1,2,3}."""
    if ys.ndim == 2:
        return build_patch(ys)
    return np.stack([build_patch(y) for y in ys])


def link_or_copy(src, dst):
    if os.path.exists(dst) or os.path.islink(dst):
        os.remove(dst)
    try:
        os.symlink(os.path.abspath(src), dst)
        return "symlink"
    except OSError:
        shutil.copy2(src, dst)
        return "copy"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src-dir", required=True)
    ap.add_argument("--dst-dir", required=True)
    ap.add_argument("--splits", default="train,val,test")
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    src, dst = args.src_dir, args.dst_dir
    if os.path.isdir(dst) and not args.overwrite:
        ap.error(f"{dst} already exists; pass --overwrite to rebuild")
    os.makedirs(dst, exist_ok=True)

    card = {"experiment": "EXP-M clean auxiliary task (geometric depth, no product drift)",
            "source_dir": os.path.abspath(src),
            "construction": {
                "aux_label": "Euclidean depth into the saline body, 3 bins + non-saline",
                "bins_px": list(BINS),
                "classes": {0: "non-saline", 1: f"saline depth<= {BINS[0]} px (fringe)",
                            2: f"saline {BINS[0]}<depth<= {BINS[1]} px (shoulder)",
                            3: f"saline depth> {BINS[1]} px (core)"},
                "derived_from": "2020 static label ONLY",
                "product_version_drift": "none by construction",
                "scipy_edt": HAVE_SCIPY,
            },
            "splits": {}}

    for split in [s.strip() for s in args.splits.split(",") if s.strip()]:
        xs = os.path.join(src, f"{split}_x.npy")
        ys_path = os.path.join(src, f"{split}_y_static.npy")
        if not (os.path.exists(xs) and os.path.exists(ys_path)):
            print(f"[skip] {split}: missing inputs", flush=True)
            continue
        ys = np.load(ys_path).astype(np.int64)
        aux = build_split(ys)
        np.save(os.path.join(dst, f"{split}_y_change.npy"), aux.astype(np.int64))
        how_x = link_or_copy(xs, os.path.join(dst, f"{split}_x.npy"))
        how_y = link_or_copy(ys_path, os.path.join(dst, f"{split}_y_static.npy"))
        shares = {int(c): round(float((aux == c).mean()), 6) for c in range(4)}
        card["splits"][split] = {
            "n_patches": int(aux.shape[0]),
            "class_shares": shares,
            "x": how_x, "y_static": how_y,
        }
        print(f"[{split}] {aux.shape[0]} patches | class shares "
              + " ".join(f"{c}:{v:.3f}" for c, v in shares.items()), flush=True)

    with open(os.path.join(dst, "dataset_card_geoaux.json"), "w",
              encoding="utf-8") as f:
        json.dump(card, f, indent=2, ensure_ascii=False)

    print(f"\n[done] {dst}")
    print("next:\n  python exp_a_multiseed_lambda.py --data-dir "
          f"{dst} --tag expA_geoaux\n")


if __name__ == "__main__":
    main()

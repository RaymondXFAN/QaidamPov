#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-G — re-run the Prithvi-EO (ViT-S/16) + LoRA dual-task benchmark on the
REBUILT dataset, so Table 3 is internally consistent (all rows on the same data).

Ported from the original repo's 03_train_prithvi.py (timm ViT + LoRA on qkv/proj,
ViT-token segmentation decoder), wrapped with:
  * a --data-dir / --out-dir CLI,
  * a 3-seed loop,
  * JSON output in the SAME schema as the original results/prithvi_results.json.

If a Prithvi-EO checkpoint is not found we WARN and continue with the timm
random init (identical fallback to the original script) so the run never dies.

Usage:
  python exp_g_prithvi_rerun.py --data-dir <.../processed_dual> \
      --out-dir <.../results/supplementary> --seeds 42,123,2024 --epochs 30 \
      [--prithvi-dir /path/to/prithvi-100M] [--no-pretrained]
"""
from __future__ import annotations

import os
import sys
import glob
import argparse

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    set_seed, get_device, write_json, makedirs, load_split, train_stats,
    build_loaders, compute_class_weights, metrics_bundle, describe,
    train_model, DEFAULT_DATA_DIR, DEFAULT_OUT_DIR,
)

try:
    import timm
except ImportError:
    timm = None


# ---------------------------------------------------------------------------
#  LoRA
# ---------------------------------------------------------------------------
class LoRALinear(nn.Module):
    def __init__(self, original, r=8, alpha=16):
        super().__init__()
        self.original = original
        self.scaling = alpha / r
        original.weight.requires_grad = False
        if original.bias is not None:
            original.bias.requires_grad = False
        d_in, d_out = original.in_features, original.out_features
        self.lora_A = nn.Parameter(torch.zeros(d_in, r))
        self.lora_B = nn.Parameter(torch.zeros(r, d_out))
        self.dropout = nn.Dropout(0.1)
        nn.init.kaiming_uniform_(self.lora_A, a=5 ** 0.5)
        nn.init.zeros_(self.lora_B)

    def forward(self, x):
        return self.original(x) + self.dropout(x) @ self.lora_A @ self.lora_B * self.scaling


def apply_lora(model, r=8, alpha=16, targets=("qkv", "proj")):
    """Replace matching nn.Linear layers with LoRALinear (collect names first)."""
    names = [n for n, m in model.named_modules()
             if any(t in n.lower() for t in targets) and isinstance(m, nn.Linear)]
    for name in names:
        parts = name.split(".")
        parent = model
        for p in parts[:-1]:
            parent = getattr(parent, p)
        child = getattr(parent, parts[-1])
        setattr(parent, parts[-1], LoRALinear(child, r=r, alpha=alpha))
    return len(names)


# ---------------------------------------------------------------------------
#  ViT-token segmentation decoder
# ---------------------------------------------------------------------------
class ViTSegDecoder(nn.Module):
    def __init__(self, embed_dim=768, img_size=128, patch_size=16, num_classes=2):
        super().__init__()
        self.img_size = img_size
        self.side = img_size // patch_size
        self.decoder = nn.Sequential(
            nn.Conv2d(embed_dim, 256, 3, padding=1), nn.BatchNorm2d(256), nn.GELU(),
            nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False),
            nn.Conv2d(256, 128, 3, padding=1), nn.BatchNorm2d(128), nn.GELU(),
            nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False),
            nn.Conv2d(128, 64, 3, padding=1), nn.BatchNorm2d(64), nn.GELU(),
            nn.Upsample(scale_factor=4, mode="bilinear", align_corners=False),
            nn.Conv2d(64, num_classes, 1),
        )

    def forward(self, tokens, B=None):
        B = tokens.shape[0]
        H = W = self.side
        x = tokens.transpose(1, 2).reshape(B, -1, H, W)
        x = self.decoder(x)
        if x.shape[2] != self.img_size or x.shape[3] != self.img_size:
            x = F.interpolate(x, size=(self.img_size, self.img_size),
                              mode="bilinear", align_corners=False)
        return x


class PrithviDualTaskModel(nn.Module):
    """timm ViT-S/16 (Prithvi-compatible keys) + LoRA + dual segmentation heads."""

    def __init__(self, img_size=128, in_channels=6, lora_r=8, lora_alpha=16):
        super().__init__()
        if timm is None:
            raise RuntimeError("timm is required (pip install timm)")
        self.img_size = img_size
        self.encoder = timm.create_model(
            "vit_small_patch16_224", pretrained=False, img_size=img_size,
            in_chans=in_channels, num_classes=0, embed_dim=768, depth=12, num_heads=12)
        self.n_lora = apply_lora(self.encoder, r=lora_r, alpha=lora_alpha)
        self.decoder_static = ViTSegDecoder(768, img_size, 16, 2)
        self.decoder_change = ViTSegDecoder(768, img_size, 16, 4)

    def forward(self, x):
        feats = self.encoder.forward_features(x)
        pt = feats[:, 1:]
        return self.decoder_static(pt), self.decoder_change(pt)


# ---------------------------------------------------------------------------
#  Prithvi checkpoint loading
# ---------------------------------------------------------------------------
def find_prithvi_checkpoint(search_dirs):
    for d in search_dirs:
        if d and os.path.isdir(d):
            for fname in ("Prithvi_100M.pt", "Prithvi_100M.pth",
                          "prithvi_100M.pt", "Prithvi_EO_1.0_100M.pt"):
                p = os.path.join(d, fname)
                if os.path.exists(p):
                    return p
    return None


def interpolate_pos_embed(pos_embed, new_size=8):
    cls = pos_embed[:, :1, :]
    patch = pos_embed[:, 1:, :]
    N, C = patch.shape[1], patch.shape[2]
    old = int(N ** 0.5)
    if old * old == N:
        if old == new_size:
            return pos_embed
        print(f"  📐 pos_embed 2D 插值 {old}->{new_size}")
        patch = patch.reshape(1, old, old, C).permute(0, 3, 1, 2)
        patch = F.interpolate(patch, size=(new_size, new_size),
                              mode="bilinear", align_corners=False)
        patch = patch.permute(0, 2, 3, 1).reshape(1, new_size * new_size, C)
        return torch.cat([cls, patch], dim=1)
    # multi-temporal: N = T * s * s
    for T in range(1, 20):
        s = int((N // T) ** 0.5)
        if s * s * T == N:
            print(f"  📐 多时相 pos_embed T={T}, s={s} -> {new_size}")
            try:
                r = patch.reshape(1, T, s, s, C)[:, T // 2]
                r = r.permute(0, 3, 1, 2)
                r = F.interpolate(r, size=(new_size, new_size),
                                  mode="bilinear", align_corners=False)
                r = r.permute(0, 2, 3, 1).reshape(1, new_size * new_size, C)
                return torch.cat([cls, r], dim=1)
            except Exception as e:  # noqa: BLE001
                print(f"  ⚠️ pos_embed 插值失败: {e}")
                return None
    return None


def load_prithvi_weights(model, ckpt_path):
    print(f"  📂 加载 Prithvi: {ckpt_path}")
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    sd = ckpt.get("model", ckpt.get("model_state_dict", ckpt))
    sd = {k.replace("encoder.", "").replace("backbone.", "")
            .replace("module.", ""): v for k, v in sd.items()}
    pe = "patch_embed.proj.weight"
    if pe in sd and sd[pe].shape[1] != 6:
        sd[pe] = sd[pe][:, :6].clone()
    if "pos_embed" in sd:
        want = 1 + (model.img_size // 16) ** 2
        if sd["pos_embed"].shape[1] != want:
            r = interpolate_pos_embed(sd["pos_embed"], new_size=model.img_size // 16)
            if r is not None:
                sd["pos_embed"] = r
            else:
                del sd["pos_embed"]
    enc = model.encoder.state_dict()
    matched = 0
    for k, v in sd.items():
        if k in enc and enc[k].shape == v.shape:
            enc[k] = v
            matched += 1
    missing, unexpected = model.encoder.load_state_dict(enc, strict=False)
    print(f"  ✅ Prithvi 权重匹配 {matched} 个 key (missing {len(missing)}, "
          f"unexpected {len(unexpected)})")
    return matched


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expG_prithvi")
    ap.add_argument("--seeds", default="42,123,2024")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=5e-4)
    ap.add_argument("--lambda-change", type=float, default=1.0)
    ap.add_argument("--lora-r", type=int, default=8)
    ap.add_argument("--lora-alpha", type=int, default=16)
    ap.add_argument("--prithvi-dir", default=None,
                    help="dir with Prithvi_100M.pt (else auto-search, else random init)")
    ap.add_argument("--no-pretrained", action="store_true",
                    help="skip checkpoint loading entirely (random init)")
    ap.add_argument("--cpu", action="store_true")
    args = ap.parse_args()

    if timm is None:
        print("❌ 需要 timm：pip install timm -i https://pypi.tuna.tsinghua.edu.cn/simple")
        sys.exit(1)

    device = get_device(prefer_cuda=not args.cpu)
    out_root = os.path.join(args.out_dir, args.tag)
    makedirs(out_root)
    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]

    x_tr, ys_tr, yc_tr = load_split(args.data_dir, "train")
    mean, std = train_stats(x_tr)
    _, ys_te, yc_te = load_split(args.data_dir, "test")
    tr = build_loaders(args.data_dir, "train", mean, std, args.batch_size, True)
    va = build_loaders(args.data_dir, "val", mean, std, args.batch_size, False)
    te = build_loaders(args.data_dir, "test", mean, std, args.batch_size, False)

    ws, wc = compute_class_weights(ys_tr, yc_tr, device)
    crit_s = nn.CrossEntropyLoss(weight=ws)
    crit_c = nn.CrossEntropyLoss(weight=wc)

    search = [args.prithvi_dir] if args.prithvi_dir else []
    search += [
        os.path.join(os.path.dirname(args.data_dir), "..", "models", "prithvi-100M"),
        "/root/autodl-tmp/models/prithvi-100M",
        "/root/autodl-tmp/prithvi-100M",
        "/root/autodl-tmp/QaidamPov/models/prithvi-100M",
    ]
    ckpt = None if args.no_pretrained else find_prithvi_checkpoint(search)
    if not args.no_pretrained and ckpt is None:
        print("⚠️  未找到 Prithvi checkpoint -> 使用 timm 随机初始化（与原脚本 fallback 一致）")
        print("    想加载预训练权重：--prithvi-dir <目录，内含 Prithvi_100M.pt>")

    records = []
    for seed in seeds:
        print(f"\n🌍 Prithvi+LoRA | seed={seed} | device={device}")
        set_seed(seed)
        model = PrithviDualTaskModel(128, 6, args.lora_r, args.lora_alpha).to(device)
        if ckpt:
            load_prithvi_weights(model, ckpt)
        n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"  可训练参数: {n_trainable:,}")
        _, ps, pc, _, best = train_model(
            model, True, tr, va, te, device, args.epochs, args.lr,
            args.lambda_change, crit_s, crit_c, log_prefix=f"s{seed} ")
        m = metrics_bundle(ys_te, yc_te, ps, pc)
        rec = {"seed": seed, "model": "Prithvi+LoRA",
               "static": m["static"], "change": m["change"],
               "best_val_combined": float(best),
               "pretrained": bool(ckpt)}
        records.append(rec)
        print(f"  seed{seed}: IoU={m['static']['iou_saline']:.4f} "
              f"acc={m['static']['accuracy']:.4f}")

    def agg(field, sub):
        v = [r[sub][field] for r in records]
        d = describe(v)
        return {"mean": d["mean"], "std": d["std_ddof1"], "values": v}

    agg_out = {"n_runs": len(records),
               "pretrained": bool(ckpt),
               "static": {f: agg(f, "static") for f in
                          ("accuracy", "f1_weighted", "f1_macro", "kappa", "iou_saline")},
               "change": {f: agg(f, "change") for f in
                          ("accuracy", "f1_weighted", "f1_macro")}}
    write_json(os.path.join(out_root, "prithvi_results.json"),
               {"individual": records, "aggregated": agg_out})
    iou = agg_out["static"]["iou_saline"]
    print(f"\n✅ EXP-G done -> {out_root}/prithvi_results.json")
    print(f"   Prithvi+LoRA saline IoU = {iou['mean']:.4f} ± {iou['std']:.4f} "
          f"(pretrained={bool(ckpt)})")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-F — classical pixel-level baselines on the REBUILT dataset.

Random Forest and XGBoost classify each pixel from its 6 Sentinel-2 bands plus
three simple spectral indices (NDVI / NDWI / salinity index). These are the
non-deep-learning reference rows of Table 3, so they must be re-fit on the same
rebuilt data as every other row.

Pixel counts are large (280x128x128 train pixels), so we STRATIFIED-subsample
the TRAIN pixels (fixed seed) and evaluate on the FULL test set (test metrics
are therefore not sampled).

Self-contained: depends only on numpy + scikit-learn (+ xgboost if available).
No torch / no common import, so it runs in a bare CPU environment.

Usage:
  python exp_f_classical_baselines.py --data-dir <.../processed_dual> \
      --out-dir <.../results/supplementary> [--max-train-pixels 800000]
"""
from __future__ import annotations

import os
import json
import argparse

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, f1_score, cohen_kappa_score,
                             confusion_matrix)

try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except Exception:  # noqa: BLE001
    HAS_XGB = False

DEFAULT_DATA_DIR = "/root/autodl-tmp/QaidamPov/data/processed_dual"
DEFAULT_OUT_DIR = "/root/autodl-tmp/QaidamPov/results/supplementary"


def _load(data_dir, split):
    x = np.load(os.path.join(data_dir, f"{split}_x.npy")).astype(np.float32)
    ys = np.load(os.path.join(data_dir, f"{split}_y_static.npy")).astype(np.int64)
    return x, ys


def build_features(x, mode="full"):
    """(N,6,H,W) float -> (N*H*W, F).

    mode="full"   : 6 bands + NDVI + NDWI + salinity index  (F = 9)
    mode="bands6" : the six raw bands only                  (F = 6)

    The two modes exist so that the classical baselines can be compared with the
    CNNs under a MATCHED feature set: the CNNs see six raw bands, so scoring a
    Random Forest that also receives spectral indices confounds "classical beats
    deep" with "classical got more features".
    """
    N, C, H, W = x.shape
    X = x.transpose(0, 2, 3, 1).reshape(-1, C).astype(np.float32)
    eps = 1e-6
    b2, b3, b4, b8, b11, b12 = (X[:, i] for i in range(6))
    if mode == "bands6":
        return np.stack([b2, b3, b4, b8, b11, b12], axis=1)
    ndvi = (b8 - b4) / (b8 + b4 + eps)
    ndwi = (b3 - b8) / (b3 + b8 + eps)
    si = np.sqrt(np.abs(b2 * b4))
    return np.stack([b2, b3, b4, b8, b11, b12, ndvi, ndwi, si], axis=1)


def _stratified_subsample(y, n, seed):
    if n is None or n >= len(y):
        return np.arange(len(y))
    rng = np.random.RandomState(seed)
    classes, counts = np.unique(y, return_counts=True)
    take = np.maximum(1, (counts / counts.sum() * n).astype(int))
    idx = []
    for c, k in zip(classes, take):
        ci = np.flatnonzero(y == c)
        idx.append(rng.choice(ci, size=min(k, len(ci)), replace=False))
    return np.sort(np.concatenate(idx))


def static_metrics(y_true, y_pred):
    y_true = y_true.reshape(-1)
    y_pred = y_pred.reshape(-1)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tp, fp, fn = cm[1, 1], cm[0, 1], cm[1, 0]
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "f1_weighted": float(f1_score(y_true, y_pred, average="weighted")),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro")),
        "kappa": float(cohen_kappa_score(y_true, y_pred)),
        "iou_saline": float(tp / (tp + fp + fn + 1e-8)),
        "confusion_matrix": cm.tolist(),
    }


def fit_eval(name, clf, Xtr, ytr, Xte, yte, out):
    print(f"  fitting {name} on {len(ytr):,} pixels ...", flush=True)
    clf.fit(Xtr, ytr)
    m = static_metrics(yte, clf.predict(Xte))
    out[name] = m
    print(f"  {name}: acc={m['accuracy']:.4f} F1w={m['f1_weighted']:.4f} "
          f"kappa={m['kappa']:.3f} IoU={m['iou_saline']:.4f}")
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expF_classical")
    ap.add_argument("--max-train-pixels", type=int, default=800_000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--features", default="full", choices=["full", "bands6"],
                    help="full = 6 bands + 3 indices; bands6 = raw six bands only")
    args = ap.parse_args()

    out_root = os.path.join(args.out_dir, args.tag)
    os.makedirs(out_root, exist_ok=True)

    x_tr, ys_tr = _load(args.data_dir, "train")
    x_te, ys_te = _load(args.data_dir, "test")
    print(f"🖥️  train {x_tr.shape}  test {x_te.shape}", flush=True)

    Xtr_full = build_features(x_tr, args.features)
    ytr_full = ys_tr.reshape(-1).astype(np.int64)
    Xte = build_features(x_te, args.features)
    yte = ys_te.reshape(-1).astype(np.int64)

    idx = _stratified_subsample(ytr_full, args.max_train_pixels, args.seed)
    Xtr, ytr = Xtr_full[idx], ytr_full[idx]
    print(f"  训练像素 子采样: {len(ytr_full):,} -> {len(ytr):,} | "
          f"测试像素全量: {len(yte):,}", flush=True)

    results = {"features": ("6 bands only" if args.features == "bands6"
                            else "6 bands + NDVI + NDWI + salinity index"),
               "feature_mode": args.features,
               "n_train_pixels": int(len(ytr)),
               "n_test_pixels": int(len(yte)),
               "models": {}}

    fit_eval("RandomForest",
             RandomForestClassifier(n_estimators=200, n_jobs=-1,
                                    random_state=args.seed, class_weight="balanced"),
             Xtr, ytr, Xte, yte, results["models"])

    if HAS_XGB:
        fit_eval("XGBoost",
                 XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.1,
                               subsample=0.8, colsample_bytree=0.8,
                               tree_method="hist", n_jobs=-1,
                               random_state=args.seed, eval_metric="logloss"),
                 Xtr, ytr, Xte, yte, results["models"])
    else:
        print("  ⚠️  xgboost 未安装，跳过（pip install xgboost 后可补跑）")

    with open(os.path.join(out_root, "classical_results.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\n✅ EXP-F done -> {out_root}/classical_results.json")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""review_patch_tables.py (v2) — 先探查、再出表；彻底避开历史 run 污染。

为什么有 v2
-----------
v1 直接扫 `results/` 下所有含 `iou_saline` 的 json，结果把**原始项目遗留的旧 run**
（DualTask λ=0.3/0.5/0.7、SingleTask、UNet-dual 等）也扫了进来，与 Table I 的
八种子实验根本不是一批，标准差差一个量级。v2 改成：

    1) --inventory  先列出「有哪些目录、里面什么结构、按什么分组」，不猜
    2) 只认**含 seed 字段 + static 指标块**的 json，并按 --include 路径关键字过滤
    3) 族级安慰剂改为**自动发现**含 with/without 两臂的消融目录

用法
----
    cd /root/autodl-tmp/QaidamSalineBench

    # 第 1 步：先看有什么（不做任何计算）
    python supp/review_patch_tables.py --inventory

    # 第 2 步：确认路径后出表
    python supp/review_patch_tables.py \
        --ablation results/supplementary/<消融目录> \
        --patchruns results/supplementary/<Table I 来源目录> \
        --include geoaux \
        --out logs/REVIEW_TABLES.md
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from collections import defaultdict

import itertools

import numpy as np
from scipy import stats

SEEN_KEYS = ("seen_in_training", "seen", "in_training")
DETAIL = {}


# ------------------------------------------------------------------ 基础
def load(p):
    try:
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def iou(tp, fp, fn):
    d = tp + fp + fn
    return float(tp) / float(d) if d else float("nan")


def walk_json(root):
    for dp, _, fs in os.walk(root):
        for f in sorted(fs):
            if f.endswith(".json"):
                yield os.path.join(dp, f)


# ------------------------------------------------------------------ 探查
def inventory(root):
    """按目录汇总：文件数、顶层键、是否含 per_patch / static / seed。"""
    dirs = defaultdict(list)
    for p in walk_json(root):
        d = load(p)
        if d is None:
            continue
        dirs[os.path.dirname(p)].append((os.path.basename(p), d))

    print(f"# 目录探查：{os.path.abspath(root)}\n")
    print("| 目录 | n | 顶层键 | per_patch | static 指标 | 有 seed | 样本 model 值 |")
    print("|---|---:|---|---|---|---|---|")
    for dp in sorted(dirs):
        items = dirs[dp]
        sample = None
        for _, d in items:
            if isinstance(d, dict):
                sample = d
                break
        if sample is None:
            continue
        keys = sorted(sample.keys())
        has_pp = any("per_patch" in d for _, d in items if isinstance(d, dict))
        has_st = any(isinstance(d.get("static") or d.get("metrics"), dict) for _, d in items if isinstance(d, dict))
        has_seed = any("seed" in d for _, d in items if isinstance(d, dict))
        names = sorted({str(d.get("model") or d.get("name") or d.get("family") or "?")
                        for _, d in items if isinstance(d, dict)})[:4]
        rel = os.path.relpath(dp, root)
        print(f"| `{rel}` | {len(items)} | {', '.join(keys[:6])}{'…' if len(keys) > 6 else ''} "
              f"| {'✅' if has_pp else '—'} | {'✅' if has_st else '—'} "
              f"| {'✅' if has_seed else '—'} | {', '.join(names)} |")
    print("\n下一步：把上面含 `per_patch` 的目录填给 --ablation，"
          "把含 `static`+`seed` 的目录填给 --patchruns，并按需加 --include 关键字。")


# ------------------------------------------------------------------ 表 A
def family_table(root, seen_map, n_boot=4000, seed=0):
    rng = np.random.default_rng(seed)
    arms = defaultdict(lambda: defaultdict(dict))   # fam -> arm -> seed -> {md5: rec}
    for p in walk_json(root):
        d = load(p)
        if not isinstance(d, dict) or "per_patch" not in d:
            continue
        fam = d.get("family") or d.get("model")
        arm = d.get("protocol") or os.path.basename(os.path.dirname(p))
        sd = d.get("seed")
        if fam is None or arm is None or sd is None:
            continue
        rec = {}
        for r in d["per_patch"]:
            m = r.get("md5")
            if m:
                rec[m] = r
        arms[fam][arm][sd] = rec

    rows = []
    for fam in sorted(arms):
        per = arms[fam]
        a_tag = next((t for t in ("with", "A", "a", "with_seen") if t in per), None)
        b_tag = next((t for t in ("without", "B", "b") if t in per), None)
        if not a_tag or not b_tag:
            rows.append((fam,))
            continue
        seeds = sorted(set(per[a_tag]) & set(per[b_tag]))
        if not seeds:
            rows.append((fam,))
            continue
        ref = per[a_tag][seeds[0]]
        mds = sorted(ref)
        seen = None
        for k in SEEN_KEYS:                      # json 自带标记优先
            if mds and all(k in ref[m] for m in mds):
                seen = {m for m in mds if bool(ref[m][k])}
                break
        if seen is None:                         # 否则用索引文件的 md5→seen
            seen = {m for m in mds if seen_map.get(m) is True}
        if not seen:
            rows.append((fam,))
            continue

        ds_l, du_l, did_l = [], [], []
        for s in seeds:
            A, B = per[a_tag][s], per[b_tag][s]
            mm = [m for m in mds if m in A and m in B]
            seen_set = seen
            ss = [m for m in mm if m in seen_set]
            us = [m for m in mm if m not in seen_set]
            if not ss or not us:
                continue

            def pool_iou(D, sub):
                return iou(sum(D[m]["tp"] for m in sub),
                           sum(D[m]["fp"] for m in sub),
                           sum(D[m]["fn"] for m in sub))
            ds = pool_iou(A, ss) - pool_iou(B, ss)
            du = pool_iou(A, us) - pool_iou(B, us)
            ds_l.append(ds); du_l.append(du); did_l.append(ds - du)
        if not did_l:
            rows.append((fam,))
            continue
        ds, du, dd = map(np.asarray, (ds_l, du_l, did_l))

        def tci(x):                      # 与 exp_r_did.tstat_ci 同口径
            n = len(x)
            if n < 2:
                return float("nan"), float("nan"), float("nan")
            m = float(x.mean())
            se = float(x.std(ddof=1) / np.sqrt(n))
            half = stats.t.ppf(0.975, n - 1) * se
            return m * 100, (m - half) * 100, (m + half) * 100

        # 精确符号翻转（n ≤ 14 时穷举 2^n，与论文口径一致）
        def signflip_exact(x):
            n = len(x)
            obs = abs(float(x.mean()))
            if n > 14:
                signs = rng.choice([-1, 1], size=(20000, n))
                return float((np.abs((signs * x).mean(axis=1)) >= obs).mean())
            cnt = tot = 0
            for combo in itertools.product([-1, 1], repeat=n):
                tot += 1
                if abs(float((np.array(combo) * x).mean())) >= obs - 1e-15:
                    cnt += 1
            return cnt / tot

        _, lo, hi = tci(dd)
        p = signflip_exact(dd)
        rows.append((fam, len(dd), ds.mean() * 100, du.mean() * 100, dd.mean() * 100,
                     lo, hi, p, int((dd > 0).sum())))
        DETAIL[fam] = {"seeds": [int(x) for x in seeds],
                       "d_seen": [round(float(v) * 100, 4) for v in ds_l],
                       "d_unseen": [round(float(v) * 100, 4) for v in du_l],
                       "did": [round(float(v) * 100, 4) for v in did_l]}
    return rows


# ------------------------------------------------------------------ 表 B
def patch_audit(root, include=None, exclude=None):
    inc = [s.lower() for s in (include or [])]
    exc = [s.lower() for s in (exclude or [])]
    groups = defaultdict(list)
    skipped = []
    for p in walk_json(root):
        rel = p.lower()
        if inc and not any(k in rel for k in inc):
            continue
        if exc and any(k in rel for k in exc):
            skipped.append(p)
            continue
        d = load(p)
        if not isinstance(d, dict):
            continue
        st = d.get("static") or d.get("metrics")
        if not isinstance(st, dict) or "iou_saline" not in st:
            continue
        if "seed" not in d:
            continue
        name = d.get("model") or d.get("name") or "?"
        lam = d.get("lambda_change", d.get("lam"))
        key = f"{name}" + (f" (λ={lam})" if lam is not None else "")
        groups[key].append((st, p))
    return groups, skipped


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="/root/autodl-tmp/QaidamSalineBench/results")
    ap.add_argument("--ablation", default=None, help="含 with/without 两臂 per_patch 的目录")
    ap.add_argument("--patchruns", default=None, help="Table I 八种子 run json 所在目录")
    ap.add_argument("--include", default=None, help="路径必须包含的逗号分隔关键字，如 geoaux,expA")
    ap.add_argument("--exclude", default=None, help="路径需排除的逗号分隔关键字，如 legacy,old")
    ap.add_argument("--index", default=None,
                    help="common_index.json（提供 md5 → seen_in_training）；默认自动找")
    ap.add_argument("--inventory", action="store_true")
    ap.add_argument("--out", default="logs/REVIEW_TABLES.md")
    a = ap.parse_args()

    if a.inventory:
        inventory(a.root)
        return

    # 索引文件：决定哪些 patch 属于「见过的」
    seen_map = {}
    R = a.root.rstrip("/")
    idx_cands = [a.index] if a.index else []
    idx_cands += [
        os.path.join(R, "common_test/common_index.json"),        # --root 已在 supplementary 里
        os.path.join(R, "supplementary/common_test/common_index.json"),
        os.path.join(os.path.dirname(R), "supplementary/common_test/common_index.json"),
        os.path.join(os.path.dirname(R), "common_test/common_index.json"),
    ]
    for c in idx_cands:
        if c and os.path.exists(c):
            try:
                j = json.load(open(c, encoding="utf-8"))
                seen_map = {r["md5"]: bool(r.get("seen_in_training")) for r in j["E"]}
                print(f"[index] {c}  ({len(seen_map)} 个 patch，其中 seen={sum(seen_map.values())})")
            except Exception as e:
                print(f"[warn] 读索引失败 {c}: {e}")
            break
    if not seen_map:
        print("[debug] 试过这些路径：")
        for c in idx_cands:
            print("   ", c, "→", "存在" if c and os.path.exists(c) else "不存在")
        print("[warn] 没找到 common_index.json —— 表 A 需要它来区分 seen/unseen，"
              "请用 --index 指定；否则表 A 会全部为空。")

    inc = [s.strip() for s in a.include.split(",")] if a.include else None
    exc = [s.strip() for s in a.exclude.split(",")] if a.exclude else None

    L = ["# 审稿要求补齐的两张表（v2）", ""]

    # ---- 表 A
    L.append("## 表 A. 族级安慰剂（用于扩写 Table IV）\n")
    if not a.ablation:
        L.append("> 未给 --ablation。先跑 `--inventory` 看哪个目录有 per_patch，再回填。\n")
    elif not os.path.isdir(a.ablation):
        L.append(f"> ⚠ 目录不存在：{a.ablation}（用 `--inventory` 找真实路径）\n")
    else:
        rows = family_table(a.ablation, seen_map)
        L.append("| family | n | Δ_seen (pp) | Δ_unseen (pp) | DiD (pp) | 95% CI | p(perm) | 同号 |")
        L.append("|---|---:|---:|---:|---|---:|---:|---:|")
        for r in rows:
            if len(r) == 1:
                L.append(f"| {r[0]} | — | — | — | — | — | — | — |")
            else:
                fam, n, ds, du, dd, lo, hi, p, k = r
                L.append(f"| {fam} | {n} | {ds:+.2f} | {du:+.2f} | **{dd:+.2f}** | "
                         f"[{lo:+.2f}, {hi:+.2f}] | {p:.4f} | {k}/{n} |")
        L.append("")

    # ---- 表 B
    L.append("## 表 B. patch 级 run 审计（核对 3 vs 8 seeds）\n")
    root_b = a.patchruns or a.root
    if not os.path.isdir(root_b):
        L.append(f"> ⚠ 目录不存在：{root_b}\n")
    else:
        groups, skipped = patch_audit(root_b, inc, exc)
        if not groups:
            L.append(f"> 在 `{root_b}` 下没找到「含 seed + static.iou_saline」的 json。"
                     f"先跑 `--inventory` 看结构。\n")
        else:
            L.append("| model | n | Acc | F1 (w) | κ | IoU | 来源目录 |")
            L.append("|---|---:|---|---|---|---|---|")
            for k, items in sorted(groups.items()):
                def agg(f):
                    v = [x[0][f] for x in items if isinstance(x[0].get(f), (int, float))]
                    return (float(np.mean(v)), float(np.std(v, ddof=1)) if len(v) > 1 else 0.0) if v else None
                def s(t):
                    return "—" if not t else f"{t[0]:.4f} ± {t[1]:.4f}"
                srcs = sorted({os.path.relpath(os.path.dirname(p), root_b) for _, p in items})
                L.append(f"| {k} | {len(items)} | {s(agg('accuracy'))} | {s(agg('f1_weighted'))} "
                         f"| {s(agg('kappa'))} | {s(agg('iou_saline'))} | `{srcs[0]}`"
                         f"{' 等 %d 处' % len(srcs) if len(srcs) > 1 else ''} |")
            L.append("")
            if skipped:
                L.append(f"> 按 --exclude 跳过 {len(skipped)} 个文件。")
            L.append("> ⚠ 只采纳与 Table I 同一批实验的行；不同协议的旧 run 不可混入。\n")

    if DETAIL:
        import json as _json
        _p = os.path.join(os.path.dirname(a.out) or ".", "REVIEW_TABLES_detail.json")
        _json.dump(DETAIL, open(_p, "w"), indent=1)
        L.append(f"> 逐种子明细：`{_p}`\n")
        print(f"[write] {_p}")

    txt = "\n".join(L)
    print(txt)
    if a.out:
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        open(a.out, "w", encoding="utf-8").write(txt)
        print(f"\n[write] {os.path.abspath(a.out)}")


if __name__ == "__main__":
    main()

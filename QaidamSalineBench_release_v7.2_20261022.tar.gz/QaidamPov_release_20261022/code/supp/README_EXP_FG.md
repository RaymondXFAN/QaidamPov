# EXP-F / EXP-G — 重建数据的对照补齐

第三批返修需要把所有 Table 3 的行都建立在**同一份重建数据**上，因此补两个实验：

| 脚本 | 作用 | 依赖 | 耗时 |
|---|---|---|---|
| `exp_f_classical_baselines.py` | Random Forest / XGBoost（像素级，6 波段 + NDVI/NDWI/盐分指数） | numpy, scikit-learn（xgboost 可选） | ~2–5 min |
| `exp_g_prithvi_rerun.py` | Prithvi-EO (ViT-S/16) + LoRA 双任务，3 seed | torch, timm | GPU ~3–5 min/seed |

## 运行（后台一把梭）

```bash
cd /root/autodl-tmp/QaidamPov/supp
pip install -q scikit-learn xgboost timm        # 若缺
mkdir -p logs

nohup bash -c "\
python -u exp_f_classical_baselines.py --data-dir ../data/processed_dual --out-dir ../results/supplementary && \
python -u exp_g_prithvi_rerun.py --data-dir ../data/processed_dual --out-dir ../results/supplementary \
  --seeds 42,123,2024 --epochs 30" > logs/expFG.log 2>&1 &

echo "PID $!"
```

看进度：

```bash
tail -n 20 /root/autodl-tmp/QaidamPov/supp/logs/expFG.log
cat /root/autodl-tmp/QaidamPov/results/supplementary/expF_classical/classical_results.json
cat /root/autodl-tmp/QaidamPov/results/supplementary/expG_prithvi/prithvi_results.json
```

## 关于 Prithvi 预训练权重

脚本会**自动搜索**以下目录里的 `Prithvi_100M.pt`：

```
<data-dir>/../models/prithvi-100M
/root/autodl-tmp/models/prithvi-100M
/root/autodl-tmp/prithvi-100M
/root/autodl-tmp/QaidamPov/models/prithvi-100M
```

找不到就**打印警告并退回随机初始化**（与原仓 `03_train_prithvi.py` 的 fallback 一致，不会崩）。若要加载权重：

```bash
# 手工指定
python exp_g_prithvi_rerun.py --data-dir ../data/processed_dual --out-dir ../results/supplementary \
  --prithvi-dir /path/to/prithvi-100M --seeds 42,123,2024 --epochs 30

# 或从 HuggingFace 拉（国内先开镜像）
export HF_ENDPOINT=https://hf-mirror.com
huggingface-cli download ibm-nasa-geospatial/Prithvi-EO-1.0-100M --local-dir /root/autodl-tmp/models/prithvi-100M
```

> ⚠️ 是否加载到真正预训练权重会打印 `Pretrained=True/False`，写论文时如实标注。

## 输出说明

- `expF_classical/classical_results.json` → 每模型的 `accuracy / f1_weighted / f1_macro / kappa / iou_saline`
- `expG_prithvi/prithvi_results.json` → 与原仓 `results/prithvi_results.json` **同结构**（`individual` + `aggregated`），方便直接替换

## 备注

- EXP-F 训练像素做了分层子采样（默认 80 万），测试像素**全量**；`--max-train-pixels` 可调。
- EXP-G 的 `--lora-r / --lora-alpha / --lr` 默认与原仓一致（r=8, alpha=16, lr=5e-4）。

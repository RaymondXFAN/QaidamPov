# P1 extra batch — EXP-H / EXP-I / EXP-J

Three scripts that close the remaining "must fix before submission" items. All are
idempotent, all write both machine-readable JSON and a paper-ready Markdown table,
and none of them touch or overwrite anything the earlier experiments produced.

| script | answers | cost | output |
|---|---|---|---|
| `exp_h_paired_pixel_tests.py` | is the dual-vs-single difference resolvable at ~1e6 pixels / ~18 tiles? does the winner (RF) have a std? | inference only, **6–12 min** | `TABLE_paired_pixel_tests.md` |
| `exp_i_change_head_loss.py` | can focal loss rescue expansion F1 (0.25) / shrinkage F1 (0.049)? | GPU training, **45–75 min** | `TABLE_change_head.md` + `VERDICT.md` |
| `exp_j_split_report.py` | how many **tiles** are actually in train / val / test? | seconds | `TABLE_split_composition.md` |
| `selftest_p1_extra.py` | does the statistics agree with brute force? | CPU, <1 min | console |

---

## 0. Offline self-test — run this FIRST, it costs nothing

```bash
cd <project>/supp
python selftest_p1_extra.py
```

It builds synthetic data, then checks the maths against brute force:
cell-table bookkeeping, IoU/accuracy vs a direct computation, McNemar's exact
p against `math.comb`, and the bootstrap behaviour (identical models must give
ΔIoU = 0 with CI `[0, 0]`). Expect a line ending `✅ SELFTEST PASSED`.

If torch is missing it prints `SKIPPED` for the training checks and says so —
that is not a failure.

---

## 1. Preflight gate (~4 min, then throw the results away)

```bash
cd <project>/supp
bash run_p1_extra.sh gate
```

It runs each script once on a *real but tiny* configuration (1 seed, 1 λ, 300
bootstrap reps, 2 epochs) and asserts that the output files actually appear —
because a process that exits 0 without writing anything is the failure mode
that has burned this project before. If the gate passes, the full runs will.

---

## 2. The real runs

```bash
# everything, detached (recommended)
nohup bash run_p1_extra.sh all > logs/p1_boot.log 2>&1 &

# or individually
bash run_p1_extra.sh expJ   # seconds
bash run_p1_extra.sh expH   # 6-12 min
bash run_p1_extra.sh expI   # 45-75 min  <- the long one
```

Monitor **without blocking** (never `tail -f`, it will trap you in Ctrl+C):

```bash
bash run_p1_extra.sh status     # files present, processes running, GPU, last log lines
bash run_p1_extra.sh summary    # all three tables at once, when finished
```

Re-running is safe: a step whose output already exists is skipped. Delete its
output folder to force a rerun.

### Knobs

```bash
SEEDS=42,123,2024 LAMBDAS=1.0,0.3,0.5,0.7 bash run_p1_extra.sh expH
BOOTSTRAP=5000 bash run_p1_extra.sh expH          # tighter CIs
CONFIGS=ce,focal_g2,focal_g2_bal,focal_g3_bal bash run_p1_extra.sh expI
THRESHOLD=0.45 bash run_p1_extra.sh expI          # expansion-F1 bar for keeping the wording
CLASSICAL=0 bash run_p1_extra.sh expH             # skip RF/XGB (needs sklearn/xgboost)
GROUPS=/path/patch_tiles.npy bash run_p1_extra.sh expH
DATA_DIR=<...>/expD_spatial/data_grouped bash run_p1_extra.sh expH   # leakage-free protocol
```

> **Run EXP-H twice if you want both protocols**: once on `data/processed_dual`
> (patch-level) and once with `DATA_DIR=.../expD_spatial/data_grouped`
> (leakage-free). The tables then sit side by side, which is exactly the
> "we ship both protocols" argument the paper makes.

---

## 3. What to look at when it finishes

**`expH_paired_pixel/TABLE_paired_pixel_tests.md`**

- Quoted in the paper as the replacement for the *"n = 3, p = 0.669"* sentence.
  The defensible line is the **tile-bootstrap CI**: if it contains 0, the honest
  claim is *"no difference resolvable at the spatial scale of the data"* — a
  precise null. The pixel bootstrap is reported too but assumes independent
  pixels and is therefore anti-conservative.
- McNemar is included because it was requested. It tests **accuracy, not IoU**,
  and at ~1e6 pixels even a negligible difference can reach significance. Quote
  it *beside* ΔIoU and its CI, never instead of them.
- `rf` / `xgb` rows (from `--include-classical`) give Table 2's winner the
  bootstrap std it is currently missing.

**`expI_change_head/VERDICT.md`**

- One of three outcomes, decided by the expansion-F1 bar (default 0.40):
  keep the *"stability assessment"* wording, soften it, or downgrade the head to
  an *auxiliary regularizer*. Whatever it says, that is the wording to use — the
  number decides, not the wish.

**`expJ_split/TABLE_split_composition.md`**

- The tiles-per-split table, plus an audit that **no tile appears in two splits**.
  If test holds only 2–3 tiles, the leakage-free claim is thinner than it sounds
  and the paper should say how many held-out tiles it actually rests on.

---

## 4. Files

```
supp/
├── paired_stats.py                 # numpy-only statistics core (unit-tested)
├── exp_h_paired_pixel_tests.py     # EXP-H  (torch only for inference)
├── exp_i_change_head_loss.py       # EXP-I  (torch)
├── exp_j_split_report.py           # EXP-J  (numpy only)
├── selftest_p1_extra.py            # offline validation
└── run_p1_extra.sh                 # gate / expH / expI / expJ / status / summary / all
```

`paired_stats.py` is deliberately dependency-free so the inferential machinery can
be checked on any box — the numbers in the paper rest on it, so it should not be
the part you cannot test.

---

## 5. Installing these files onto the server

The patch archive keeps the repo layout (`QaidamPov/supp/<files>`), so strip **two**
components — `--strip-components=1` would land them in `supp/supp/`:

```bash
cd /tmp && rm -rf p1x && mkdir p1x
tar -xzf /path/to/QaidamPov_p1_extra.tar.gz -C p1x
cp p1x/QaidamPov/supp/*.py p1x/QaidamPov/supp/*.sh p1x/QaidamPov/supp/*.md \
   /root/autodl-tmp/QaidamPov/supp/
ls -l /root/autodl-tmp/QaidamPov/supp/ | grep -E "paired_stats|exp_h|exp_i|exp_j|p1_extra|selftest_p1"
```

You should see exactly six new files. Then:

```bash
cd /root/autodl-tmp/QaidamPov/supp
python selftest_p1_extra.py       # offline, should print PASSED
mkdir -p logs
bash run_p1_extra.sh gate         # foreground, ~4 min — you want to SEE this one
```

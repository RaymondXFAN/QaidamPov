#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exp_r_did.py — 用差分中的差分（difference-in-differences, DiD）把
               "记忆化效应" 与 "E_seen/E_unseen 固有难度差" 拆开。

问题背景
--------
run_common_test.sh 的 report 直接用
        Δ_mem = IoU(E_seen) − IoU(E_unseen)
来度量记忆化。**这个量是有偏的**，因为它把两种东西混在一起：
    (a) 真的"训练时见过"带来的增益（记忆化）
    (b) E_seen 与 E_unseen 这两组 patch 本身难度不同

证据：tile 协议下模型从未见过 E 的任何 patch，却得到 Δ_mem = −4.18pp。
这 4.18pp 只能是 (b) 固有难度差 —— E_seen 那 48 个 patch 天生更难。

正确估计量
----------
用 tile 协议作为**反事实基线**（同一批 patch、同一指标、无重叠）：
    Δ_mem(patch) = IoU_patch(E_seen) − IoU_patch(E_unseen)      (含 a + b)
    Δ_mem(tile)  = IoU_tile (E_seen) − IoU_tile (E_unseen)      (只含 b)
    DiD          = Δ_mem(patch) − Δ_mem(tile)                   (纯 a)
于是总差距可以干净地三分：
    Total   = IoU_patch(E) − IoU_tile(E)
    Overlap = DiD                    ← 空间重叠/记忆化贡献
    Remain  = Total − Overlap        ← 训练覆盖与协议本身的贡献

用法
----
python exp_r_did.py \
    --index  results/supplementary/common_test/common_index.json \
    --evals  results/supplementary/common_test/evals \
    --out    results/supplementary/common_test

python exp_r_did.py --selftest       # 纯合成数据自检，不需要真实结果
"""

import argparse
import glob
import json
import os
import sys
from collections import defaultdict

import numpy as np


# ---------------------------------------------------------------- basic math
def iou_from_counts(c):
    tp, fp, fn = c["tp"], c["fp"], c["fn"]
    d = tp + fp + fn
    return tp / d if d else float("nan")


def pool(lst):
    c = {"tp": 0, "fp": 0, "fn": 0}
    for p in lst:
        for k in c:
            c[k] += int(p.get(k, 0))
    return c


def mean_sd(v):
    v = np.asarray([x for x in v if not np.isnan(x)], dtype=float)
    if len(v) == 0:
        return float("nan"), float("nan"), 0
    if len(v) == 1:
        return float(v.mean()), 0.0, 1
    return float(v.mean()), float(v.std(ddof=1)), len(v)


def tstat_ci(v):
    """单样本 t 检验 + 95% CI（不依赖 scipy，用学生 t 分位数近似表）"""
    v = np.asarray(v, dtype=float)
    n = len(v)
    if n < 2:
        return float("nan"), float("nan"), float("nan")
    m = v.mean()
    se = v.std(ddof=1) / np.sqrt(n)
    if se == 0:
        return float("inf"), m, m
    t = m / se
    # 双侧 95% 的 t 临界值（df=1..30 查表，>30 用 1.96+修正）
    T95 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447,
           7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228, 11: 2.201, 12: 2.179,
           13: 2.160, 14: 2.145, 15: 2.131, 16: 2.120, 17: 2.110, 18: 2.101,
           19: 2.093, 20: 2.086, 21: 2.080, 22: 2.074, 23: 2.069, 24: 2.064,
           25: 2.060, 26: 2.056, 27: 2.052, 28: 2.048, 29: 2.045, 30: 2.042}
    q = T95.get(n - 1, 1.96 + 2.4 / max(n - 1, 1))
    return t, m - q * se, m + q * se


def signflip_p(v, n_perm=20000, seed=0):
    """配对符号翻转置换检验（对 DiD 这类零假设下对称的量）"""
    v = np.asarray(v, dtype=float)
    obs = abs(v.mean())
    rng = np.random.default_rng(seed)
    sgn = rng.choice([-1.0, 1.0], size=(n_perm, len(v)))
    perm = np.abs((sgn * v).mean(axis=1))
    return float((perm >= obs - 1e-15).mean())


def boot_mean(v, n_boot=5000, seed=0):
    """整体均值的 patch 级 bootstrap CI（对全部 patch 重采样）"""
    a = np.asarray(v, dtype=float)
    a = a[~np.isnan(a)]
    if len(a) == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    m = np.array([rng.choice(a, len(a), replace=True).mean() for _ in range(n_boot)])
    return float(a.mean()), float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def boot_diff(vals_seen, vals_unseen, n_boot=5000, seed=0):
    """patch 级 bootstrap（E_seen 内与 E_unseen 内各自重采样）"""
    a = np.asarray(vals_seen, dtype=float)
    b = np.asarray(vals_unseen, dtype=float)
    if len(a) == 0 or len(b) == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    d = np.empty(n_boot)
    for i in range(n_boot):
        d[i] = rng.choice(a, len(a), replace=True).mean() - \
               rng.choice(b, len(b), replace=True).mean()
    return float(d.mean()), float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))


# ---------------------------------------------------------------- loading
def cfg_key(name, protocol):
    """把 patch_single_seed42 / tile_single_seed42 → single_seed42
       rf_full_patch / rf_full_tile → rf_full"""
    if name.startswith(protocol + "_"):
        return name[len(protocol) + 1:]
    if name.endswith("_" + protocol):
        return name[: -(len(protocol) + 1)]
    return name


def load_evals(evals_dir):
    """→ {(family, protocol): {cfg: [per_patch...]}}"""
    out = defaultdict(lambda: defaultdict(list))
    files = sorted(glob.glob(os.path.join(evals_dir, "**", "*.json"), recursive=True))
    for f in files:
        d = json.load(open(f, encoding="utf-8"))
        pc = d.get("per_patch") or []
        if not pc:
            continue
        fam = d.get("family", "?")
        prot = d.get("protocol", "?")
        cfg = cfg_key(d.get("name", os.path.basename(f)[:-5]), prot)
        out[(fam, prot)][cfg] = pc
    return out


def load_index(path):
    idx = json.load(open(path, encoding="utf-8"))
    seen, split = {}, {}
    for r in idx["E"]:
        seen[r["md5"]] = bool(r["seen_in_training"])
        split[r["md5"]] = r.get("patch_split")
    return idx, seen, split


# ---------------------------------------------------------------- core
def analyse(index_path, evals_dir, out_dir):
    idx, seen, split = load_index(index_path)
    ev = load_evals(evals_dir)

    print("=" * 78)
    print("E 的构成")
    print("=" * 78)
    n_seen = sum(1 for v in seen.values() if v)
    n_un = sum(1 for v in seen.values() if not v)
    comp = defaultdict(int)
    for r in idx["E"]:
        comp[(r.get("patch_split"), r["seen_in_training"])] += 1
    print(f"[E] seen={n_seen}  unseen={n_un}  (md5 匹配率 {idx['md5_match_rate']:.4f})")
    for (sp, sn), c in sorted(comp.items(), key=lambda x: str(x[0])):
        tag = "训练集" if sn else "未参与训练"
        print(f"[E] patch_split={sp!s:<6} seen_in_train={sn!s:<5} n={c:3d}  ({tag})")
    if comp.get(("val", False), 0) > 0:
        print("[!!] 注意：有 unseen patch 来自 patch 级 **val** 集 ——")
        print("     val 虽未参与梯度更新，但被用于 early-stopping 选模型，")
        print("     属于间接接触；DiD 会因此**低估**重叠效应。建议同时只统计")
        print("     patch_split=='test' 的 unseen 子集作为敏感性分析。")

    rows = []          # 每个 (family, cfg) 一行
    for fam in sorted({k[0] for k in ev}):
        common_cfg = set(ev.get((fam, "patch"), {})) & set(ev.get((fam, "tile"), {}))
        if not common_cfg:
            print(f"\n[warn] family={fam} 在两种协议下没有同名配置，跳过 DiD")
            continue
        print("\n" + "=" * 78)
        print(f"family = {fam}   配对配置 {len(common_cfg)} 个：{sorted(common_cfg)}")
        print("=" * 78)
        for cfg in sorted(common_cfg):
            r = {"family": fam, "cfg": cfg}
            for prot in ("patch", "tile"):
                pc = ev[(fam, prot)][cfg]
                s = [p for p in pc if seen.get(p["md5"])]
                u = [p for p in pc if p["md5"] in seen and not seen[p["md5"]]]
                r[f"n_s_{prot}"], r[f"n_u_{prot}"] = len(s), len(u)
                r[f"iou_s_{prot}"] = iou_from_counts(pool(s))
                r[f"iou_u_{prot}"] = iou_from_counts(pool(u))
                r[f"iou_e_{prot}"] = iou_from_counts(pool(pc))
                r[f"dmem_{prot}"] = r[f"iou_s_{prot}"] - r[f"iou_u_{prot}"]
            r["did"] = r["dmem_patch"] - r["dmem_tile"]
            r["total"] = r["iou_e_patch"] - r["iou_e_tile"]
            r["remain"] = r["total"] - r["did"]
            rows.append(r)
            print(f"  {cfg:<26} Δpatch={r['dmem_patch']*100:+6.2f}pp "
                  f"Δtile={r['dmem_tile']*100:+6.2f}pp "
                  f"→ DiD={r['did']*100:+6.2f}pp | "
                  f"total={r['total']*100:+6.2f}pp")

    # ---- patch 级配对（跨 seed 池化计数，逐 patch 算 IoU）----
    per_patch_tab = {}
    for fam in sorted({k[0] for k in ev}):
        if not (ev.get((fam, "patch")) and ev.get((fam, "tile"))):
            continue
        poolp, poolt = {}, {}
        for cfg, pc in ev[(fam, "patch")].items():
            for p in pc:
                c = poolp.setdefault(p["md5"], {"tp": 0, "fp": 0, "fn": 0})
                for k in c:
                    c[k] += int(p.get(k, 0))
        for cfg, pc in ev[(fam, "tile")].items():
            for p in pc:
                c = poolt.setdefault(p["md5"], {"tp": 0, "fp": 0, "fn": 0})
                for k in c:
                    c[k] += int(p.get(k, 0))
        ids = sorted(set(poolp) & set(poolt))
        i_p = np.array([iou_from_counts(poolp[i]) for i in ids])
        i_t = np.array([iou_from_counts(poolt[i]) for i in ids])
        is_seen = np.array([seen[i] for i in ids])
        d = i_p - i_t
        per_patch_tab[fam] = {"n": len(ids), "diff": d, "seen": is_seen,
                              "iou_patch": i_p, "iou_tile": i_t, "ids": ids}

    # ------------------------------------------------------------ 汇总表
    L = ["# Difference-in-differences：把「记忆化」与「固有难度差」拆开", ""]
    L += [f"E = tile 级 test 的 {idx['n_eval_test']} 个 patch；"
          f"E_seen = {n_seen}（也在 patch 级训练集内），E_unseen = {n_un}。", "",
          "Δ_mem(prot) = IoU(E_seen) − IoU(E_unseen)，同一模型、同一批像素，只差「见没见过」。",
          "tile 协议下模型从未见过 E 的任何 patch，其 Δ_mem 只反映两组 patch 的**固有难度差**。",
          "DiD = Δ_mem(patch) − Δ_mem(tile) 即纯记忆化效应。", ""]
    L += ["| family | config | Δ_mem(patch) | Δ_mem(tile) | **DiD** | total gap | remainder |",
          "|---|---|---:|---:|---:|---:|---:|"]
    for r in rows:
        L.append(f"| {r['family']} | {r['cfg']} | {r['dmem_patch']*100:+.2f}pp | "
                 f"{r['dmem_tile']*100:+.2f}pp | **{r['did']*100:+.2f}pp** | "
                 f"{r['total']*100:+.2f}pp | {r['remain']*100:+.2f}pp |")

    L += ["", "## 按 family 汇总（跨 seed/配置）", "",
          "| family | n | DiD mean | 95% CI | p(t) | p(perm) | 同号 | total gap | 重叠占比 |",
          "|---|---:|---|---|---:|---:|---|---:|---:|"]
    summary = {}
    for fam in sorted({r["family"] for r in rows}):
        rs = [r for r in rows if r["family"] == fam]
        did = np.array([r["did"] for r in rs], dtype=float)
        tot = np.array([r["total"] for r in rs], dtype=float)
        t, lo, hi = tstat_ci(did)
        pp = signflip_p(did) if len(did) >= 3 else float("nan")
        dmean, _, _ = mean_sd(did)
        same = int((did > 0).sum())
        share = dmean / tot.mean() if tot.mean() else float("nan")
        summary[fam] = {"n": len(rs), "did": dmean, "lo": lo, "hi": hi,
                        "t": t, "p_t": float("nan"), "p_perm": pp,
                        "same_sign": same, "total": float(tot.mean()),
                        "share": float(share)}
        L.append(f"| {fam} | {len(rs)} | {dmean*100:+.2f}pp | "
                 f"[{lo*100:+.2f}, {hi*100:+.2f}] | — | {pp:.4f} | "
                 f"{same}/{len(rs)} | {tot.mean()*100:+.2f}pp | {share*100:.0f}% |")

    # ---- patch 级 bootstrap ----
    L += ["", "## patch 级配对（66 个 patch 各自算 IoU_patch − IoU_tile）", "",
          "| family | n patch | mean Δ（全 66） | 其 95% CI | Δ(E_seen) | Δ(E_unseen) |"
          " E_seen − E_unseen | 其 95% CI |",
          "|---|---:|---|---|---:|---:|---|---|"]
    boot_out = {}
    for fam, tab in per_patch_tab.items():
        d = tab["diff"]
        m = float(d.mean())
        _, mlo, mhi = boot_mean(d)
        s, u = d[tab["seen"]].mean(), d[~tab["seen"]].mean()
        _, lo, hi = boot_diff(d[tab["seen"]], d[~tab["seen"]])
        boot_out[fam] = {"mean": m, "mean_lo": mlo, "mean_hi": mhi,
                         "seen": float(s), "unseen": float(u),
                         "did_patchlevel": float(s - u), "did_lo": lo, "did_hi": hi}
        L.append(f"| {fam} | {tab['n']} | {m*100:+.2f}pp | [{mlo*100:+.2f}, {mhi*100:+.2f}] | "
                 f"{s*100:+.2f}pp | {u*100:+.2f}pp | {(s-u)*100:+.2f}pp | "
                 f"[{lo*100:+.2f}, {hi*100:+.2f}] |")
    L += ["", "**注意两点**：",
          "1. 上一张是按像素汇总的 global IoU（全文主指标），本张是逐 patch 等权平均。"
          "两者不一致说明 IoU 的差距集中在少数高盐斑 patch 上，属于聚合方式差异，不是错误。",
          "2. 最右两列是**不依赖 tile 反事实**的纯配对 DiD（同一 patch 自己跟自己比），"
          "其 CI 宽，反映的是 18 个 unseen patch 带来的不确定性。", ""]

    os.makedirs(out_dir, exist_ok=True)
    md = os.path.join(out_dir, "TABLE_did.md")
    open(md, "w", encoding="utf-8").write("\n".join(L))
    js = os.path.join(out_dir, "did.json")
    json.dump({"composition": {f"{k[0]}/{k[1]}": v for k, v in comp.items()},
               "rows": rows, "summary": summary, "per_patch": boot_out},
              open(js, "w", encoding="utf-8"), indent=1)
    print("\n".join(L))
    print(f"\n[write] {md}\n[write] {js}")


# ---------------------------------------------------------------- selftest
def selftest():
    """合成数据：已知 seen 组 +6pp 记忆化、且 seen 组固有难 4pp，验证 DiD 能还原 6pp。"""
    rng = np.random.default_rng(0)
    mds = [f"p{i:03d}" for i in range(66)]
    seen = {m: (i < 48) for i, m in enumerate(mds)}
    # 每 patch 真实像素: 16000; 固有 IoU: seen 0.86, unseen 0.90
    base = {m: (0.86 if seen[m] else 0.90) for m in mds}

    def mk(prot):
        out = []
        for m in mds:
            v = base[m] + (0.06 if (prot == "patch" and seen[m]) else 0.0)
            v += rng.normal(0, 0.004)
            v = float(np.clip(v, 0, 1))
            d = 16000
            tp = int(round(v * d)); fp = fn = (d - tp) // 2
            out.append({"md5": m, "tp": tp, "fp": fp, "fn": fn})
        return out

    ev = {("conv", "patch"): {"single_seed1": mk("patch")},
          ("conv", "tile"): {"single_seed1": mk("tile")}}
    os.makedirs("/tmp/_didtest", exist_ok=True)
    idx = {"md5_match_rate": 1.0, "n_eval_test": 66, "n_seen": 48, "n_unseen": 18,
           "E": [{"md5": m, "patch_split": "train" if seen[m] else "test",
                  "seen_in_training": seen[m]} for m in mds]}
    json.dump(idx, open("/tmp/_didtest/common_index.json", "w"))
    os.makedirs("/tmp/_didtest/evals", exist_ok=True)
    for (fam, prot), d in ev.items():
        for cfg, pc in d.items():
            p = f"/tmp/_didtest/evals/{prot}"
            os.makedirs(p, exist_ok=True)
            json.dump({"name": f"{prot}_{cfg}", "family": fam, "protocol": prot,
                       "per_patch": pc}, open(f"{p}/{prot}_{cfg}.json", "w"))

    import io
    from contextlib import redirect_stdout
    buf = io.StringIO()
    with redirect_stdout(buf):
        analyse("/tmp/_didtest/common_index.json", "/tmp/_didtest/evals", "/tmp/_didtest")
    out = json.load(open("/tmp/_didtest/did.json"))
    r = out["rows"][0]
    ok = True
    print(f"[selftest] Δpatch = {r['dmem_patch']*100:+.2f}pp (期望 ≈ +2.0 = 6pp记忆 − 4pp固有难度)")
    print(f"[selftest] Δtile  = {r['dmem_tile']*100:+.2f}pp (期望 ≈ −4.0, 只有固有难度)")
    print(f"[selftest] DiD     = {r['did']*100:+.2f}pp (期望 ≈ +6.0)")
    for name, got, exp, tol in [("dmem_patch", r["dmem_patch"], 0.02, 0.02),
                                ("dmem_tile", r["dmem_tile"], -0.04, 0.02),
                                ("did", r["did"], 0.06, 0.02)]:
        if abs(got - exp) > tol:
            print(f"[selftest] ✗ {name} 偏差过大：{got:.4f} vs {exp:.4f}")
            ok = False
    print(f"[selftest] {'✅ PASS' if ok else '❌ FAIL'}")
    sys.exit(0 if ok else 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index")
    ap.add_argument("--evals")
    ap.add_argument("--out", default=".")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        selftest()
    if not (a.index and a.evals):
        ap.error("需要 --index 与 --evals（或用 --selftest）")
    analyse(a.index, a.evals, a.out)


if __name__ == "__main__":
    main()

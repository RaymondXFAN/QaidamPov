#!/usr/bin/env bash
# =============================================================================
# run_p2.sh — the three experiments the reviewers demanded (batch P2)
#
#   expK  label separability / why 0.926 is not "mapping skill"   CPU   ~10-15 min
#   expL  feature-aligned classical baselines (6 bands vs 6+3)    CPU   ~2 min
#   expM  clean auxiliary task (geometric, no v100->v200 drift)   CPU   ~1 min
#   expMTrain  the lambda grid ON that clean task                 GPU   ~2-4 h
#
# Usage
#   bash run_p2.sh gate          # ~3 min, must pass before anything else
#   bash run_p2.sh expK
#   bash run_p2.sh expL
#   bash run_p2.sh expM
#   nohup bash run_p2.sh expMTrain > logs/p2_train.log 2>&1 &
#   bash run_p2.sh status        # non-blocking; never `tail -f`
#   bash run_p2.sh summary
# =============================================================================
set -uo pipefail

PROJECT="${PROJECT_DIR:-/root/autodl-tmp/QaidamPov}"
SUPP="$PROJECT/supp"
DATA="${DATA_DIR:-$PROJECT/data/processed_dual}"
OUT="${OUT_DIR:-$PROJECT/results/supplementary}"
PY="${PYTHON:-python}"
mkdir -p "$OUT" "$PROJECT/logs"
cd "$SUPP" || { echo "!! $SUPP not found"; exit 1; }

banner() { echo; echo "=== $* ==="; echo; }

need() { # need <file> <label>
  if [ -f "$1" ]; then echo "  OK  $2"; else echo "  MISSING  $2 ($1)"; return 1; fi
}

# --------------------------------------------------------------------- gate
gate() {
  banner "GATE - prove the three scripts run on real data before any long job"
  local t0=$(date +%s)

  echo "[1/3] expK on a 20k-pixel subsample"
  $PY exp_k_label_purity.py --data-dir "$DATA" \
      --out-dir "$OUT/_gate_p2/label_purity" --max-pixels 20000 || return 1

  echo "[2/3] expF with the 6-band arm on a 20k-pixel subsample"
  $PY exp_f_classical_baselines.py --data-dir "$DATA" --out-dir "$OUT/_gate_p2" \
      --tag expF_bands6 --features bands6 --max-train-pixels 20000 || return 1

  echo "[3/3] expM builds the clean auxiliary labels"
  $PY exp_m_clean_aux.py --src-dir "$DATA" --dst-dir "$PROJECT/data/_gate_geoaux" \
      --overwrite || return 1

  banner "GATE ASSERTIONS"
  local ok=0
  need "$OUT/_gate_p2/label_purity/label_separability.json" "EXP-K json" || ok=1
  need "$OUT/_gate_p2/label_purity/TABLE_label_purity.md"    "EXP-K table" || ok=1
  need "$PROJECT/data/_gate_geoaux/train_y_change.npy"       "EXP-M aux label" || ok=1
  find "$OUT/_gate_p2" -name '*.json' | grep -q . && echo "  OK  expF wrote json" \
      || { echo "  MISSING  expF wrote no json"; ok=1; }

  local dt=$(( $(date +%s) - t0 ))
  echo
  if [ "$ok" -eq 0 ]; then
    echo "GATE PASSED in ${dt}s - safe to launch expK / expL / expM"
  else
    echo "GATE FAILED - do NOT launch anything. Read the errors above."
    return 1
  fi
}

# -------------------------------------------------------------------- expK
expK() {
  banner "EXP-K - label separability (CPU, ~10-15 min)"
  $PY exp_k_label_purity.py --data-dir "$DATA" --out-dir "$OUT/label_purity" \
      --max-pixels 300000 || return 1
  echo; echo "read it with:  cat $OUT/label_purity/TABLE_label_purity.md"
}

# -------------------------------------------------------------------- expL
expL() {
  banner "EXP-L - feature-aligned classical baselines (CPU, ~2 min each arm)"
  echo "[arm 1/2] six raw bands only  (matches what the CNNs see)"
  $PY exp_f_classical_baselines.py --data-dir "$DATA" --out-dir "$OUT" \
      --tag expF_bands6 --features bands6 || return 1
  echo "[arm 2/2] six bands + NDVI + NDWI + salinity index (the published arm)"
  $PY exp_f_classical_baselines.py --data-dir "$DATA" --out-dir "$OUT" \
      --tag expF_full --features full || return 1
  banner "EXP-L ASSERTIONS"
  need "$OUT/expF_bands6/TABLE_classical_baselines.md" "bands6 table" || true
  need "$OUT/expF_full/TABLE_classical_baselines.md"   "full table"   || true
  echo; echo "compare the two TABLES: the IoU difference is the feature advantage"
}

# -------------------------------------------------------------------- expM
expM() {
  banner "EXP-M - build the clean auxiliary labels (CPU, ~1 min)"
  $PY exp_m_clean_aux.py --src-dir "$DATA" --dst-dir "$PROJECT/data/data_geoaux" \
      --overwrite || return 1
  need "$PROJECT/data/data_geoaux/dataset_card_geoaux.json" "geometry card" || true
  echo; echo "next (GPU):  nohup bash run_p2.sh expMTrain > logs/p2_train.log 2>&1 &"
}

# --------------------------------------------------------------- expMTrain
expMTrain() {
  banner "EXP-M training - lambda grid on the clean auxiliary task (GPU, ~2-4 h)"
  if [ ! -f "$PROJECT/data/data_geoaux/train_y_change.npy" ]; then
    echo "!! data_geoaux missing - run:  bash run_p2.sh expM"
    return 1
  fi
  echo "[pre-gate] 1 seed x 1 lambda x 2 epochs"
  $PY exp_a_multiseed_lambda.py --data-dir "$PROJECT/data/data_geoaux" \
      --out-dir "$OUT" --tag _pregate_geoaux --seeds 42 --lambdas 1.0 \
      --epochs 2 || return 1
  if ! find "$OUT/_pregate_geoaux" -name '*.json' | grep -q .; then
    echo "!! pre-gate wrote no json - aborting"; return 1
  fi
  echo "pre-gate OK"
  echo "[main] 3 seeds x 4 lambdas + 3 single-task, 30 epochs"
  $PY exp_a_multiseed_lambda.py --data-dir "$PROJECT/data/data_geoaux" \
      --out-dir "$OUT" --tag expA_geoaux --seeds 42,123,2024 \
      --lambdas 1.0,0.3,0.5,0.7 --epochs 30 || return 1
  echo; echo "done -> $OUT/expA_geoaux"
}

# ------------------------------------------------------------------ status
status() {
  banner "STATUS - what exists, what doesn't (non-blocking)"
  local d
  for d in label_purity expF_bands6 expF_full expA_geoaux _pregate_geoaux; do
    if [ -d "$OUT/$d" ]; then
      printf "  OK        %-16s %s files, %s\n" "$d" \
        "$(find "$OUT/$d" -type f | wc -l)" "$(du -sh "$OUT/$d" | cut -f1)"
    else
      printf "  NOT YET   %-16s\n" "$d"
    fi
  done
  [ -f "$PROJECT/data/data_geoaux/train_y_change.npy" ] \
    && echo "  OK        data_geoaux built" || echo "  NOT YET   data_geoaux"
  echo
  echo "  running python jobs:"
  pgrep -af "exp_k_label|exp_m_clean|exp_a_multi" | sed 's/^/    /' || echo "    (none)"
}

# ----------------------------------------------------------------- summary
summary() {
  banner "SUMMARY"
  local f
  for f in "$OUT/label_purity/TABLE_label_purity.md"; do
    [ -f "$f" ] && { echo "--- $f"; cat "$f"; echo; }
  done
  for f in "$OUT/expF_bands6/TABLE_classical_baselines.md" \
           "$OUT/expF_full/TABLE_classical_baselines.md"; do
    [ -f "$f" ] && { echo "--- $f"; head -30 "$f"; echo; }
  done
  if [ -f "$PROJECT/data/data_geoaux/dataset_card_geoaux.json" ]; then
    echo "--- data_geoaux class shares"
    $PY - "$PROJECT/data/data_geoaux/dataset_card_geoaux.json" <<'PY'
import json, sys
c = json.load(open(sys.argv[1]))
for s, v in c["splits"].items():
    print(f"  {s:6s} n={v['n_patches']:4d}  " + "  ".join(
        f"{k}:{val:.3f}" for k, val in v["class_shares"].items()))
PY
  fi
}

case "${1:-status}" in
  gate)      gate ;;
  expK|expk) expK ;;
  expL|expl) expL ;;
  expM|expm) expM ;;
  expMTrain|expmtrain|train) expMTrain ;;
  status)    status ;;
  summary)   summary ;;
  all)       gate && expK && expL && expM && \
             echo "now launch: nohup bash $0 expMTrain > logs/p2_train.log 2>&1 &" ;;
  *) echo "usage: bash run_p2.sh {gate|expK|expL|expM|expMTrain|status|summary|all}"; exit 2 ;;
esac

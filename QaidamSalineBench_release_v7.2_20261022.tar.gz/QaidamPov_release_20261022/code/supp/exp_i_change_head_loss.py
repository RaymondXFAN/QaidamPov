#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-I — Can the change ("stability") head be rescued for the rare classes?

The problem this fixes
----------------------
Table 2 / Table 4 advertise a "stability assessment" head, but its per-class F1
on the two classes that *are* the change signal is poor:
    expansion  F1 ≈ 0.25
    shrinkage  F1 ≈ 0.049
With cross-entropy on a 62/33/3/2 class mix, the head simply predicts the
majority class and gets paid for it.  A reviewer will notice that the title
promises more than the head delivers.

Two honest outcomes are acceptable:
  (a) a cheap loss change (focal loss and/or class-balanced weights) lifts
      expansion F1 to a defensible level -> keep the "stability assessment"
      framing; or
  (b) it does not -> the head is an *auxiliary regularizer* and the wording
      must be downgraded.  Either way the number decides, not the wish.

This script runs the comparison and prints the verdict.

Configs (all with the identical encoder/model/optimiser/seed/epochs, so the
only thing that changes is the change-head loss):
    ce              exact published recipe (cross-entropy, class weights ≤ 10)
    focal_g1        focal loss, gamma = 1
    focal_g2        focal loss, gamma = 2
    focal_g2_bal    focal gamma = 2 + class-balanced weights (clamp 30)
    focal_g3_bal    focal gamma = 3 + class-balanced weights (clamp 30)
plus two label-free references so the table is interpretable:
    prior           always predict the majority class (test prior)
    oracle_ceiling  per-class F1 if the *train* prior is predicted (upper bound
                    of any prior-only rule)

Outputs (in --out-dir/<tag>/)
    runs/<config>_seed{S}.json     per-run metrics (static + change, per-class)
    change_head_runs.json          everything
    TABLE_change_head.md           paper-ready comparison + verdict
    VERDICT.md                     the keep / downgrade decision

Usage
-----
    python exp_i_change_head_loss.py --data-dir <processed_dual> --out-dir <out> \
        --seeds 42,123,2024 --epochs 30 --configs ce,focal_g2,focal_g2_bal \
        --decision-threshold 0.40
"""
from __future__ import annotations

import os
import sys
import time
import json
import argparse

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    DualTaskModel, DualDataset, load_split, train_stats, compute_class_weights,
    metrics_static, metrics_change, set_seed, get_device, makedirs, write_json,
    describe, CHANGE_CLASS_NAMES, STATIC_CLASS_NAMES,
    DEFAULT_DATA_DIR, DEFAULT_OUT_DIR,
)


# ===========================================================================
#  Losses for the change head
# ===========================================================================
class FocalLoss(nn.Module):
    """Multiclass focal loss with optional per-class weights."""

    def __init__(self, gamma=2.0, weight=None, reduction="mean"):
        super().__init__()
        self.gamma = float(gamma)
        self.register_buffer("weight", weight if weight is not None else torch.tensor([]))
        self.reduction = reduction

    def forward(self, logits, target):
        logp = F.log_softmax(logits, dim=1)
        logpt = logp.gather(1, target.unsqueeze(1)).squeeze(1)
        pt = logpt.exp().clamp(1e-8, 1.0)
        loss = -((1.0 - pt) ** self.gamma) * logpt
        if self.weight.numel() > 0:
            loss = loss * self.weight[target]
        return loss.mean() if self.reduction == "mean" else loss


def balanced_weights(yc_train, clamp=30.0, device="cpu"):
    counts = np.array([(yc_train == c).sum() for c in range(4)], dtype=np.float64)
    total = counts.sum()
    w = total / (4.0 * np.maximum(counts, 1.0))
    w = np.clip(w, None, clamp)
    return torch.tensor(w, dtype=torch.float32, device=device)


def build_change_criterion(name, yc_train, device):
    """Return (criterion, clamps) for the change head."""
    if name == "ce":
        w = balanced_weights(yc_train, clamp=10.0, device=device)   # published recipe
        return nn.CrossEntropyLoss(weight=w), {"clamp": 10.0, "gamma": None}
    if name.startswith("focal"):
        parts = name.split("_")
        gamma = float(parts[0].replace("focal", "").replace("g", "") or 2)
        if "bal" in parts:
            w = balanced_weights(yc_train, clamp=30.0, device=device)
            clamp = 30.0
        else:
            w, clamp = None, None
        return FocalLoss(gamma=gamma, weight=w), {"clamp": clamp, "gamma": gamma}
    raise ValueError(f"unknown config {name}")


# ===========================================================================
def train_one(cfg, seed, data_dir, device, epochs, lr, lambda_change, batch_size,
              num_workers):
    set_seed(seed)
    x_tr, ys_tr, yc_tr = load_split(data_dir, "train")
    x_va, ys_va, yc_va = load_split(data_dir, "val")
    x_te, ys_te, yc_te = load_split(data_dir, "test")
    mean, std = train_stats(x_tr)

    tr = DataLoader(DualDataset(x_tr, ys_tr, yc_tr, mean, std, augment=True),
                    batch_size=batch_size, shuffle=True, num_workers=num_workers)
    va = DataLoader(DualDataset(x_va, ys_va, yc_va, mean, std, augment=False),
                    batch_size=batch_size, shuffle=False, num_workers=num_workers)
    te = DataLoader(DualDataset(x_te, ys_te, yc_te, mean, std, augment=False),
                    batch_size=batch_size, shuffle=False, num_workers=num_workers)

    ws, _ = compute_class_weights(ys_tr, yc_tr, device)
    crit_s = nn.CrossEntropyLoss(weight=ws)
    crit_c, cmeta = build_change_criterion(cfg, yc_tr, device)

    model = DualTaskModel(in_channels=x_tr.shape[1], num_classes=2,
                          num_change_classes=4).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-6)

    print(f"\n{'='*66}\n[{cfg} | seed {seed}] epochs={epochs} lr={lr} "
          f"λ={lambda_change} meta={cmeta}\n{'='*66}")
    best, best_state = -1.0, None
    t0 = time.time()
    for ep in range(1, epochs + 1):
        model.train()
        tot = n = 0
        for x, ys, yc in tr:
            x, ys, yc = x.to(device), ys.to(device), yc.to(device)
            opt.zero_grad()
            os_, oc = model(x)
            loss = crit_s(os_, ys) + lambda_change * crit_c(oc, yc)
            loss.backward(); opt.step()
            tot += loss.item() * x.size(0); n += x.size(0)
        sched.step()
        model.eval()
        cs = cc = tv = 0
        with torch.no_grad():
            for x, ys, yc in va:
                x, ys, yc = x.to(device), ys.to(device), yc.to(device)
                os_, oc = model(x)
                cs += (os_.argmax(1) == ys).sum().item()
                cc += (oc.argmax(1) == yc).sum().item()
                tv += ys.numel()
        comb = (cs / tv + cc / tv) / 2
        if comb > best:
            best, best_state = comb, {k: v.detach().cpu().clone()
                                      for k, v in model.state_dict().items()}
        if ep % 5 == 0 or ep == 1 or ep == epochs:
            print(f"  Ep {ep:2d}/{epochs} | loss {tot/max(n,1):.4f} "
                  f"| val static {cs/tv:.3f} | val change {cc/tv:.3f} | comb {comb:.4f}")

    model.load_state_dict(best_state)
    model.eval()
    ps, pc = [], []
    with torch.no_grad():
        for x, ys, yc in te:
            os_, oc = model(x.to(device))
            ps.append(os_.argmax(1).cpu().numpy())
            pc.append(oc.argmax(1).cpu().numpy())
    ps = np.concatenate(ps); pc = np.concatenate(pc)

    ms = metrics_static(ys_te, ps)
    mc = metrics_change(yc_te, pc)
    dt = time.time() - t0
    print(f"[{cfg} | {seed}] {dt:.0f}s | static IoU {ms['iou_saline']:.4f} "
          f"| change macroF1 {mc['f1_macro']:.4f} | expansion F1 "
          f"{mc['f1_per_class'][2]:.3f} | shrinkage F1 {mc['f1_per_class'][3]:.3f}")
    return {
        "config": cfg, "seed": int(seed), "epochs": epochs, "lr": lr,
        "lambda_change": lambda_change, "loss_meta": cmeta, "seconds": dt,
        "best_val_combined": best, "static": ms, "change": mc,
        "change_pred": pc, "change_true": yc_te,
    }


def prior_reference(yc_te):
    """Label-free references so the table is interpretable."""
    counts = np.array([(yc_te == c).sum() for c in range(4)], dtype=np.float64)
    prior = counts / counts.sum()
    maj = int(np.argmax(prior))
    pred = np.full_like(yc_te, maj)
    m = metrics_change(yc_te, pred)
    return {"config": "prior", "majority_class": CHANGE_CLASS_NAMES[maj],
            "prior": prior.tolist(), "change": m}


# ===========================================================================
def main():
    ap = argparse.ArgumentParser(description="EXP-I change-head loss search")
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expI_change_head")
    ap.add_argument("--seeds", default="42,123,2024")
    ap.add_argument("--configs", default="ce,focal_g2,focal_g2_bal")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--lambda-change", type=float, default=1.0)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--num-workers", type=int, default=2)
    ap.add_argument("--decision-threshold", type=float, default=0.40,
                    help="expansion-F1 needed to keep the 'stability assessment' wording")
    ap.add_argument("--cpu", action="store_true")
    args = ap.parse_args()

    out = os.path.join(args.out_dir, args.tag)
    makedirs(out, os.path.join(out, "runs"))
    device = get_device(prefer_cuda=not args.cpu)
    cfgs = [c.strip() for c in args.configs.split(",") if c.strip()]
    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
    print(f"🖥️  device={device} | data={args.data_dir} | out={out}")
    print(f"   configs={cfgs} seeds={seeds} epochs={args.epochs}")

    runs = []
    for cfg in cfgs:
        for s in seeds:
            r = train_one(cfg, s, args.data_dir, device, args.epochs, args.lr,
                          args.lambda_change, args.batch_size, args.num_workers)
            d = {k: v for k, v in r.items() if k not in ("change_pred", "change_true")}
            write_json(os.path.join(out, "runs", f"{cfg}_seed{s}.json"), d)
            np.save(os.path.join(out, "runs", f"{cfg}_seed{s}_changepred.npy"),
                    r["change_pred"])
            runs.append(d)

    yc_te = np.load(os.path.join(args.data_dir, "test_y_change.npy")).astype(np.int64)
    prior = prior_reference(yc_te)

    # aggregate per config
    agg = {}
    for cfg in cfgs:
        sel = [r for r in runs if r["config"] == cfg]
        if not sel:
            continue
        agg[cfg] = {
            "n_seeds": len(sel),
            "static_iou": describe([r["static"]["iou_saline"] for r in sel]),
            "static_kappa": describe([r["static"]["kappa"] for r in sel]),
            "change_macro_f1": describe([r["change"]["f1_macro"] for r in sel]),
            "expansion_f1": describe([r["change"]["f1_per_class"][2] for r in sel]),
            "shrinkage_f1": describe([r["change"]["f1_per_class"][3] for r in sel]),
            "change_acc": describe([r["change"]["accuracy"] for r in sel]),
        }
    best_cfg = max(agg, key=lambda c: agg[c]["expansion_f1"]["mean"]) if agg else None
    verdict = decide(agg, best_cfg, args.decision_threshold)
    if args.epochs < 10:
        # The preflight gate runs 2 epochs. A "verdict" from an unconverged model
        # would be actively misleading, so label it for what it is.
        verdict = {
            "smoke_test": True,
            "best_config": best_cfg,
            "expansion_f1": (agg[best_cfg]["expansion_f1"]["mean"] if best_cfg else None),
            "headline": (f"SMOKE TEST ONLY (epochs={args.epochs}) — the configs are not "
                         f"converged, so this is NOT a verdict on the wording. "
                         f"Re-run with EPOCHS=30 (bash run_p1_extra.sh expI)."),
            "action": "ignore — this is the preflight gate, not the experiment",
        }
    else:
        verdict["smoke_test"] = False

    payload = {"config": vars(args), "per_run": runs, "aggregate": agg,
               "prior_reference": prior, "verdict": verdict}
    write_json(os.path.join(out, "change_head_runs.json"), payload)
    write_table(payload, os.path.join(out, "TABLE_change_head.md"),
                os.path.join(out, "VERDICT.md"))
    print(f"\n✅ EXP-I done -> {out}/TABLE_change_head.md")
    print(f"🔎 VERDICT: {verdict['headline']}")


def decide(agg, best_cfg, thr):
    if not best_cfg:
        return {"headline": "no runs", "action": "rerun"}
    e = agg[best_cfg]["expansion_f1"]["mean"]
    s = agg[best_cfg]["shrinkage_f1"]["mean"]
    if e >= thr:
        return {"best_config": best_cfg, "expansion_f1": e, "shrinkage_f1": s,
                "headline": f"KEEP 'stability assessment' — {best_cfg} reaches "
                            f"expansion F1 = {e:.3f} ≥ {thr:.2f}",
                "action": "keep wording; report focal-loss config in Table 4"}
    if e >= 0.30:
        return {"best_config": best_cfg, "expansion_f1": e, "shrinkage_f1": s,
                "headline": f"BORDERLINE — best expansion F1 = {e:.3f} (< {thr:.2f}); "
                            f"report as auxiliary with the focal result shown",
                "action": "soften wording to 'auxiliary regularizer (focal-tuned)'"}
    return {"best_config": best_cfg, "expansion_f1": e, "shrinkage_f1": s,
            "headline": f"DOWNGRADE — best expansion F1 = {e:.3f}; the head is an "
                        f"auxiliary regularizer, not a stability assessment",
            "action": "rename to 'auxiliary change regularizer' in the title/abstract"}


def write_table(res, tpath, vpath):
    agg, prior = res["aggregate"], res["prior_reference"]
    L = ["# EXP-I — change-head loss comparison\n",
         "All configs share encoder, optimiser, seeds and epochs; **only the "
         "change-head loss differs**. `ce` reproduces the published recipe.\n",
         "| config | change macro-F1 | expansion F1 | shrinkage F1 | change acc | static IoU |",
         "|---|---|---|---|---|---|"]
    for cfg, a in agg.items():
        L.append("| {} | {:.4f} ± {:.4f} | **{:.3f}** ± {:.3f} | {:.3f} ± {:.3f} | "
                 "{:.4f} | {:.4f} |".format(
                     cfg, a["change_macro_f1"]["mean"], a["change_macro_f1"]["std_ddof1"],
                     a["expansion_f1"]["mean"], a["expansion_f1"]["std_ddof1"],
                     a["shrinkage_f1"]["mean"], a["shrinkage_f1"]["std_ddof1"],
                     a["change_acc"]["mean"], a["static_iou"]["mean"]))
    p = prior["change"]
    L.append("| _prior-only_ | {:.4f} | {:.3f} | {:.3f} | {:.4f} | — |".format(
        p["f1_macro"], p["f1_per_class"][2], p["f1_per_class"][3], p["accuracy"]))
    L.append(f"\n_per-class support (test set): "
             f"{dict(zip(CHANGE_CLASS_NAMES, p['support']))}_\n")
    L.append("## Verdict\n")
    L.append(f"**{res['verdict']['headline']}**\n")
    L.append(f"Action: {res['verdict']['action']}\n")
    open(tpath, "w", encoding="utf-8").write("\n".join(L))
    open(vpath, "w", encoding="utf-8").write(
        f"# EXP-I verdict\n\n{res['verdict']['headline']}\n\n"
        f"Action: {res['verdict']['action']}\n\n"
        f"Decoder of the columns: `expansion F1` is the class that fails today "
        f"(≈0.25); the threshold for keeping the 'stability assessment' wording is "
        f"{res['config']['decision_threshold']}.\n")


if __name__ == "__main__":
    main()

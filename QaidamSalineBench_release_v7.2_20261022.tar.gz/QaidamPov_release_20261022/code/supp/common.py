#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
QaidamPov supplementary experiments — shared utilities.

This module is SELF-CONTAINED: it does not import the original project code,
but it reproduces the *exact* data layout, model architecture, class weighting,
normalisation and model-selection rules of the published pipeline, so that any
number produced here is directly comparable with the manuscript.

Design goals
------------
1. Same architecture as `02_train_dual.py::DualTaskModel` (bit-for-bit layer
   order) so results are apples-to-apples.
2. Adds the *missing* pieces the reviewers asked for:
   - a single-task CNN baseline implemented here (the public repo never shipped it);
   - a standard U-Net segmentation baseline;
   - a spatial-leakage-safe grouped split utility;
   - raw confusion-matrix / per-class export for every model.
3. Std is always reported with ddof=1 (sample std) to kill the ddof mixing flagged
   by the reviewers.
4. Runs on CPU with tiny synthetic data for offline self-test.
"""
from __future__ import annotations

import os
import json
import math
import glob
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, TensorDataset
from torch.optim.lr_scheduler import CosineAnnealingLR
from sklearn.metrics import (
    accuracy_score, f1_score, cohen_kappa_score, confusion_matrix,
    precision_recall_fscore_support,
)

# ----------------------------------------------------------------------------
# Paths (override via CLI / env for offline self-test)
# ----------------------------------------------------------------------------
DEFAULT_PROJECT = os.environ.get("PROJECT_DIR", "/root/autodl-tmp/QaidamPov")
DEFAULT_DATA_DIR = os.environ.get(
    "DATA_DIR", os.path.join(DEFAULT_PROJECT, "data", "processed_dual"))
DEFAULT_CKPT_DIR = os.environ.get(
    "CKPT_DIR", os.path.join(DEFAULT_PROJECT, "checkpoints"))
DEFAULT_OUT_DIR = os.environ.get(
    "SUPP_OUT_DIR", os.path.join(DEFAULT_PROJECT, "results", "supplementary"))

# four-class change taxonomy (matches Table 2 / the code's labels 0..3)
CHANGE_CLASS_NAMES = ["stable non-saline", "stable saline", "expansion", "shrinkage"]
STATIC_CLASS_NAMES = ["non-saline", "saline"]


def makedirs(*paths):
    for p in paths:
        if p:
            os.makedirs(p, exist_ok=True)


def set_seed(seed: int):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_device(prefer_cuda=True):
    if prefer_cuda and torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


# ============================================================================
#  Dataset  (identical semantics to 02_train_dual.py::DualDataset)
# ============================================================================
class DualDataset(Dataset):
    def __init__(self, x, ys, yc, mean=None, std=None, augment=True):
        self.x = np.asarray(x, dtype=np.float32)
        self.ys = np.asarray(ys, dtype=np.int64)
        self.yc = np.asarray(yc, dtype=np.int64)
        self.augment = augment
        if mean is not None and std is not None:
            self.mean = np.asarray(mean, dtype=np.float32).reshape(1, -1, 1, 1)
            self.std = np.asarray(std, dtype=np.float32).reshape(1, -1, 1, 1)
        else:
            self.mean = self.x.mean(axis=(0, 2, 3)).reshape(1, -1, 1, 1)
            self.std = (self.x.std(axis=(0, 2, 3)) + 1e-8).reshape(1, -1, 1, 1)
        self.x = (self.x - self.mean) / self.std

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        x = self.x[idx].copy()
        ys = self.ys[idx].copy()
        yc = self.yc[idx].copy()
        if self.augment:
            if np.random.random() > 0.5:
                x, ys, yc = x[:, :, ::-1].copy(), ys[:, ::-1].copy(), yc[:, ::-1].copy()
            if np.random.random() > 0.5:
                x, ys, yc = x[:, ::-1, :].copy(), ys[::-1, :].copy(), yc[::-1, :].copy()
        return torch.FloatTensor(x), torch.LongTensor(ys), torch.LongTensor(yc)


# ============================================================================
#  Models
# ============================================================================
class DualTaskModel(nn.Module):
    """Verbatim copy of the published dual-task CNN (encoder + 2 decoders).

    Resolution chain (as actually implemented):
        128 -> (maxpool) 64 -> (maxpool) 32 -> (up x2) 64 -> (up x2) 128
    NOTE: only TWO max-pools exist (after block1 and block2), so the output is
    128x128 and matches the label size. (The manuscript text claiming three
    pooling stages is a *text* error, not an architecture error.)
    """

    def __init__(self, in_channels=6, num_classes=2, num_change_classes=4):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.Conv2d(128, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(128, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(),
            nn.Conv2d(256, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(),
        )
        self.decoder_static = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(256, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(128, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, num_classes, 1),
        )
        self.decoder_change = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(256, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(128, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, num_change_classes, 1),
        )

    def forward(self, x):
        feat = self.encoder(x)
        return self.decoder_static(feat), self.decoder_change(feat)


class SingleTaskModel(nn.Module):
    """Single-task static baseline (static head only).

    The published repository references a `02_train_baseline.py` that was never
    released, so this class reconstructs the baseline that produced the
    manuscript's 0.785 +/- 0.011 headline: identical encoder + static decoder,
    trained with the static loss only.
    """

    def __init__(self, in_channels=6, num_classes=2):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.Conv2d(128, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(128, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(),
            nn.Conv2d(256, 256, 3, padding=1), nn.BatchNorm2d(256), nn.ReLU(),
        )
        self.decoder_static = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(256, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(128, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, num_classes, 1),
        )

    def forward(self, x):
        return self.decoder_static(self.encoder(x))


def _double_conv(in_ch, out_ch):
    return nn.Sequential(
        nn.Conv2d(in_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
        nn.Conv2d(out_ch, out_ch, 3, padding=1), nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True),
    )


class UNet(nn.Module):
    """Standard 4-level U-Net (segmentation 'practice standard' baseline).

    dual=False -> single static output (single-task)
    dual=True  -> (static, change) heads sharing the decoder trunk (dual-task)
    """

    def __init__(self, in_channels=6, num_classes=2, num_change_classes=4,
                 base=32, dual=False):
        super().__init__()
        self.dual = dual
        self.enc1 = _double_conv(in_channels, base)       # 128
        self.enc2 = _double_conv(base, base * 2)          #  64
        self.enc3 = _double_conv(base * 2, base * 4)      #  32
        self.enc4 = _double_conv(base * 4, base * 8)      #  16
        self.pool = nn.MaxPool2d(2)
        self.up3 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.dec3 = _double_conv(base * 8 + base * 4, base * 4)
        self.up2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.dec2 = _double_conv(base * 4 + base * 2, base * 2)
        self.up1 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.dec1 = _double_conv(base * 2 + base, base)
        self.head_static = nn.Conv2d(base, num_classes, 1)
        if dual:
            self.head_change = nn.Conv2d(base, num_change_classes, 1)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))
        d3 = self.dec3(torch.cat([self.up3(e4), e3], dim=1))
        d2 = self.dec2(torch.cat([self.up2(d3), e2], dim=1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], dim=1))
        if self.dual:
            return self.head_static(d1), self.head_change(d1)
        return self.head_static(d1)


# ============================================================================
#  Data loading
# ============================================================================
def load_split(data_dir, split):
    """Return (x, ys, yc) for split in {train, val, test}."""
    x = np.load(os.path.join(data_dir, f"{split}_x.npy")).astype(np.float32)
    ys = np.load(os.path.join(data_dir, f"{split}_y_static.npy")).astype(np.int64)
    yc = np.load(os.path.join(data_dir, f"{split}_y_change.npy")).astype(np.int64)
    return x, ys, yc


def train_stats(x_train):
    mean = x_train.mean(axis=(0, 2, 3))
    std = x_train.std(axis=(0, 2, 3)) + 1e-8
    return mean.astype(np.float32), std.astype(np.float32)


def build_loaders(data_dir, split, mean, std, batch_size, augment,
                  num_workers=2, pin_memory=None):
    """Build a DataLoader for a named split; split may be 'train'/'val'/'test'."""
    if pin_memory is None:
        pin_memory = torch.cuda.is_available()
    x, ys, yc = load_split(data_dir, split)
    ds = DualDataset(x, ys, yc, mean=mean, std=std, augment=augment)
    return DataLoader(ds, batch_size=batch_size, shuffle=augment,
                      num_workers=num_workers, pin_memory=pin_memory)


def compute_class_weights(ys_train, yc_train, device):
    """Exactly the published weighting scheme (clamped)."""
    n_pos = (ys_train == 1).sum()
    n_neg = (ys_train == 0).sum()
    ws = torch.FloatTensor([n_pos / (n_neg + 1e-8), 1.0]).to(device)
    ws = torch.clamp(ws, max=5.0)
    counts = [(yc_train == c).sum() for c in range(4)]
    total = sum(counts)
    wc = torch.FloatTensor([total / (4 * c + 1e-8) for c in counts]).to(device)
    wc = torch.clamp(wc, max=10.0)
    return ws, wc


# ============================================================================
#  Metrics  (single source of truth; ddof=1 everywhere for std)
# ============================================================================
def _per_class_prf(y_true, y_pred, labels):
    p, r, f, s = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, zero_division=0)
    return {
        "precision": [float(v) for v in p],
        "recall": [float(v) for v in r],
        "f1": [float(v) for v in f],
        "support": [int(v) for v in s],
    }


def metrics_static(ys_true, ys_pred):
    ys_true = ys_true.flatten()
    ys_pred = ys_pred.flatten()
    cm = confusion_matrix(ys_true, ys_pred, labels=[0, 1])
    tp, fp, fn = cm[1, 1], cm[0, 1], cm[1, 0]
    iou = tp / (tp + fp + fn + 1e-8)
    d = {
        "accuracy": float(accuracy_score(ys_true, ys_pred)),
        "f1_weighted": float(f1_score(ys_true, ys_pred, average="weighted")),
        "f1_macro": float(f1_score(ys_true, ys_pred, average="macro")),
        "kappa": float(cohen_kappa_score(ys_true, ys_pred)),
        "iou_saline": float(iou),
        "confusion_matrix": cm.tolist(),
        "class_names": STATIC_CLASS_NAMES,
        "support": [int((ys_true == c).sum()) for c in [0, 1]],
    }
    d.update(_per_class_prf(ys_true, ys_pred, [0, 1]))
    return d


def metrics_change(yc_true, yc_pred):
    yc_true = yc_true.flatten()
    yc_pred = yc_pred.flatten()
    cm = confusion_matrix(yc_true, yc_pred, labels=[0, 1, 2, 3])
    d = {
        "accuracy": float(accuracy_score(yc_true, yc_pred)),
        "f1_weighted": float(f1_score(yc_true, yc_pred, average="weighted")),
        "f1_macro": float(f1_score(yc_true, yc_pred, average="macro")),
        "f1_per_class": [float(v) for v in
                         f1_score(yc_true, yc_pred, average=None, labels=[0, 1, 2, 3])],
        "confusion_matrix": cm.tolist(),
        "class_names": CHANGE_CLASS_NAMES,
        "support": [int((yc_true == c).sum()) for c in [0, 1, 2, 3]],
    }
    d.update(_per_class_prf(yc_true, yc_pred, [0, 1, 2, 3]))
    return d


def metrics_bundle(ys_true, yc_true, pred_s, pred_c):
    out = {"static": metrics_static(ys_true, pred_s)}
    if pred_c is not None:
        out["change"] = metrics_change(yc_true, pred_c)
    return out


# ============================================================================
#  Statistics  (no scipy dependency required)
# ============================================================================
def _betacf(a, b, x):
    MAXIT, EPS, FPMIN = 300, 3e-16, 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN:
        d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, MAXIT + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < EPS:
            break
    return h


def _betai(a, b, x):
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
    front = math.exp(lbeta + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1) / (a + b + 2):
        return front * _betacf(a, b, x) / a
    return 1.0 - front * _betacf(b, a, 1.0 - x) / b


def _t_two_sided_p(t, df):
    """P(|T_df| > |t|) via the incomplete beta identity."""
    if df <= 0:
        return float("nan")
    t = abs(t)
    return _betai(df / 2.0, 0.5, df / (df + t * t))


def _t_crit(df, alpha=0.05):
    """Two-sided critical value via bisection on the p function."""
    lo, hi = 0.0, 1000.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if _t_two_sided_p(mid, df) > alpha:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def describe(values):
    """mean and SAMPLE std (ddof=1)."""
    v = np.asarray(values, dtype=float)
    n = len(v)
    mean = float(np.mean(v))
    sd = float(np.std(v, ddof=1)) if n > 1 else 0.0
    se = sd / math.sqrt(n) if n > 1 else 0.0
    return {"n": n, "mean": mean, "std_ddof1": sd, "se": se,
            "values": [float(x) for x in v]}


def ttest_rel(a, b, alpha=0.05):
    """Paired t-test a vs b (a-b). Returns dict with t, df, p, mean_diff, CI."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    n = len(a)
    d = a - b
    md = float(np.mean(d))
    sd = float(np.std(d, ddof=1)) if n > 1 else 0.0
    df = n - 1
    se = sd / math.sqrt(n) if n > 1 else 0.0
    if se > 0:
        t = md / se
    else:
        # degenerate: zero variance of the differences
        t = 0.0 if md == 0 else math.copysign(math.inf, md)
    if se > 0:
        p = _t_two_sided_p(t, df) if df > 0 else float("nan")
    else:
        p = 1.0 if md == 0 else 0.0
    tcrit = _t_crit(df, alpha) if df > 0 else float("nan")
    return {
        "n": n, "mean_diff": md, "sd_diff": sd, "t": float(t), "df": df,
        "p_value": float(p), "alpha": alpha,
        "ci95": [float(md - tcrit * se), float(md + tcrit * se)] if se > 0 else [md, md],
    }


# ============================================================================
#  Training / evaluation loops
# ============================================================================
@torch.no_grad()
def _predict(model, loader, device, dual):
    model.eval()
    ps, pc = [], []
    for batch in loader:
        x = batch[0].to(device)
        out = model(x)
        if dual:
            os_, oc = out
            pc.append(oc.argmax(1).cpu().numpy())
        else:
            os_ = out
        ps.append(os_.argmax(1).cpu().numpy())
    pred_s = np.concatenate(ps)
    pred_c = np.concatenate(pc) if dual else None
    return pred_s, pred_c


def train_model(model, dual, train_loader, val_loader, test_loader, device,
                epochs, lr, lambda_change, crit_s, crit_c, log_prefix=""):
    """Train with best-val model selection, then evaluate on test.

    Model-selection metric mirrors the published code:
      dual  : mean(val static acc, val change acc)
      single: val static acc
    """
    set_seed_ok = True
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-6)
    best = -1.0
    best_state = None
    hist = []
    for epoch in range(1, epochs + 1):
        model.train()
        loss_sum, n_seen = 0.0, 0
        for batch in train_loader:
            x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
            opt.zero_grad()
            out = model(x)
            if dual:
                os_, oc = out
                loss = crit_s(os_, ys) + lambda_change * crit_c(oc, yc)
            else:
                loss = crit_s(out, ys)
            loss.backward()
            opt.step()
            loss_sum += loss.item() * x.size(0)
            n_seen += x.size(0)
        sched.step()
        # validation
        model.eval()
        cs = cc = tv = 0
        with torch.no_grad():
            for batch in val_loader:
                x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
                out = model(x)
                if dual:
                    os_, oc = out
                    cc += (oc.argmax(1) == yc).sum().item()
                else:
                    os_ = out
                cs += (os_.argmax(1) == ys).sum().item()
                tv += ys.numel()
        vas = cs / tv
        vac = (cc / tv) if dual else 0.0
        combined = (vas + vac) / 2 if dual else vas
        hist.append({"epoch": epoch, "loss": loss_sum / max(n_seen, 1),
                     "val_static_acc": vas, "val_change_acc": vac,
                     "combined": combined})
        if combined > best:
            best = combined
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        if epoch % 5 == 0 or epoch == 1 or epoch == epochs:
            print(f"  {log_prefix}Ep {epoch:2d}/{epochs} | Loss {loss_sum/max(n_seen,1):.4f} "
                  f"| ValS {vas:.3f}" + (f" | ValC {vac:.3f}" if dual else ""))

    model.load_state_dict(best_state)
    pred_s, pred_c = _predict(model, test_loader, device, dual)
    return best_state, pred_s, pred_c, hist, best


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ============================================================================
#  Synthetic data (for offline self-test): correct shapes AND dtypes
# ============================================================================
def make_synthetic_data(out_dir, n_train=24, n_val=8, n_test=8, H=128, W=128,
                        C=6, seed=0):
    """Create a tiny but *realistically shaped/typed* dataset.

    x          float32 (N,6,128,128)
    y_static   int64   (N,128,128) with values {0,1}
    y_change   int64   (N,128,128) with values {0,1,2,3}
    """
    makedirs(out_dir)
    rng = np.random.RandomState(seed)

    def make(n):
        x = rng.rand(n, C, H, W).astype(np.float32)
        # inject a learnable signal so metrics are non-degenerate
        ys = (x[:, 0] > 0.5).astype(np.int64)
        yc = np.zeros((n, H, W), dtype=np.int64)
        yc[(x[:, 1] > 0.6)] = 1
        yc[(x[:, 2] > 0.9)] = 2
        yc[(x[:, 3] > 0.9)] = 3
        return x, ys, yc

    for split, n in (("train", n_train), ("val", n_val), ("test", n_test)):
        x, ys, yc = make(n)
        np.save(os.path.join(out_dir, f"{split}_x.npy"), x)
        np.save(os.path.join(out_dir, f"{split}_y_static.npy"), ys)
        np.save(os.path.join(out_dir, f"{split}_y_change.npy"), yc)
    return out_dir

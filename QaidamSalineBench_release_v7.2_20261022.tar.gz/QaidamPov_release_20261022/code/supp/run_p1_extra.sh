#!/bin/bash
# =============================================================================
# QaidamPov — P1 revision batch (EXP-H / EXP-I / EXP-J)
#
#   EXP-H  paired INFERENCE at pixel level -> turns the n=3 "no power" null into
#          a precise null; also gives Table 2's winner (RF) a bootstrap std
#   EXP-I  change-head loss search         -> decides whether the "stability
#          assessment" wording survives (expansion F1 0.25 -> ?)
#   EXP-J  split composition               -> "how many tiles are in test?"
#
# Usage
#   mkdir -p logs                      # <-- DO THIS FIRST if you use nohup + a relative log path
#   bash run_p1_extra.sh gate          # ~4 min preflight — RUN THIS FIRST
#   bash run_p1_extra.sh expJ          # split report (seconds)
#   bash run_p1_extra.sh expH          # pixel-level paired tests (patch-level protocol)
#   bash run_p1_extra.sh expHg         # same, on the leakage-free grouped split
#   bash run_p1_extra.sh expI          # change-head retraining (GPU, the long one)
#   bash run_p1_extra.sh all           # gate -> J -> H -> I
#   bash run_p1_extra.sh status        # non-blocking progress  (NEVER use tail -f)
#   bash run_p1_extra.sh summary       # one-shot summary of everything produced
#
# Detached long run (note the mkdir — the shell opens the log file BEFORE the
# script runs, so a missing logs/ makes the whole command fail silently):
#   mkdir -p logs && nohup bash run_p1_extra.sh all > logs/p1_boot.log 2>&1 &
#
# Expected wall clock on a single RTX 4090
#   gate ~4 min | expJ ~5 s | expH ~3-6 min | expI ~45-75 min  => all ~1.5 h
# =============================================================================
set -uo pipefail

PROJECT="${PROJECT_DIR:-/root/autodl-tmp/QaidamPov}"
SUPP="${PROJECT}/supp"
OUT="${PROJECT}/results/supplementary"
LOGS="${SUPP}/logs"
PY="${PYTHON:-python}"

DATA="${DATA_DIR:-${PROJECT}/data/processed_dual}"
DATA_GROUPED="${DATA_GROUPED:-${OUT}/expD_spatial/data_grouped}"
CKPT_DIR="${CKPT_DIR:-${OUT}/expA_multiseed_lambda/ckpts}"

SEEDS="${SEEDS:-42,123,2024}"
LAMBDAS="${LAMBDAS:-1.0,0.3,0.5,0.7}"
EPOCHS="${EPOCHS:-30}"
BATCH="${BATCH:-8}"
BOOTSTRAP="${BOOTSTRAP:-2000}"
CONFIGS="${CONFIGS:-ce,focal_g2,focal_g2_bal}"
THRESHOLD="${THRESHOLD:-0.40}"
GROUPS="${GROUPS:-}"          # per-patch tile ids; auto-detected if empty
CLASSICAL="${CLASSICAL:-1}"   # 1 = also train RF/XGB here (needs sklearn/xgboost)
TAG_H="${TAG_H:-expH_paired_pixel}"
TAG_J="${TAG_J:-expJ_split}"

mkdir -p "${OUT}" "${LOGS}"
cd "${SUPP}" || { echo "❌ cannot cd into ${SUPP}"; exit 1; }

log()  { echo "[$(date '+%F %T')] $*"; }
ok()   { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
die()  { echo "❌ $*"; exit 1; }
have() { [ -e "$1" ]; }

# --- safe optional-argument arrays -------------------------------------------
# NOTE: '"${arr[@]}"' on an EMPTY array aborts under `set -u` on bash < 4.4.
# Use the ${arr[@]+"${arr[@]}"} idiom so an empty list expands to nothing.
GARGS=()                      # extra args for the tile-id file
EXTRA=()                      # extra args for expH

pick_data() {                 # resolve $1 into DATA/GROUPS/GARGS
    local d="$1"
    have "${d}" || die "data dir not found: ${d}"
    DATA="${d}"
    local g="${GROUPS}"
    if [ -z "${g}" ]; then
        for c in patch_tiles.npy tiles.npy; do
            if have "${d}/${c}"; then g="${d}/${c}"; break; fi
        done
    fi
    GARGS=()
    if [ -n "${g}" ] && have "${g}"; then
        GARGS=(--groups "${g}")
        log "tile ids: ${g}"
    else
        warn "no tile ids found in ${d} -> tile-level cluster bootstrap will be skipped (pass GROUPS=...)"
    fi
    if [ ! -d "${CKPT_DIR}" ] || ! ls "${CKPT_DIR}"/dual_*.pth >/dev/null 2>&1; then
        warn "no dual_*.pth in ${CKPT_DIR}"
        if have "${PROJECT}/checkpoints"; then
            CKPT_DIR="${PROJECT}/checkpoints"
            warn "falling back to ${CKPT_DIR}"
        fi
    fi
}

# ---------------------------------------------------------------------------
gate() {
    log "=== GATE: tiny REAL run of every new script (~4 min) ==="
    pick_data "${DATA}"

    rm -rf "${OUT}/_gate_J"
    ${PY} -u exp_j_split_report.py --data-dir "${DATA}" --out-dir "${OUT}" \
        --tag _gate_J ${GARGS[@]+"${GARGS[@]}"} || die "gate: EXP-J crashed"
    have "${OUT}/_gate_J/split_composition.json" || die "gate: EXP-J wrote no json"
    ok "gate: EXP-J ok"

    if ! ls "${CKPT_DIR}"/dual_*.pth >/dev/null 2>&1; then
        die "gate: no dual_*.pth in ${CKPT_DIR} — run 'bash run_supplementary.sh expA' first"
    fi
    rm -rf "${OUT}/_gate_H"
    ${PY} -u exp_h_paired_pixel_tests.py --data-dir "${DATA}" \
        --ckpt-dir "${CKPT_DIR}" --out-dir "${OUT}" --tag _gate_H \
        --seeds 42 --lambdas 1.0 --bootstrap 300 --batch-size "${BATCH}" \
        ${GARGS[@]+"${GARGS[@]}"} || die "gate: EXP-H crashed"
    have "${OUT}/_gate_H/pixel_tests.json"            || die "gate: EXP-H wrote no json"
    have "${OUT}/_gate_H/TABLE_paired_pixel_tests.md" || die "gate: EXP-H wrote no table"
    OUTDIR="${OUT}" ${PY} - <<'PYEOF' || die "gate: EXP-H produced no usable comparison"
import json, os, sys
r = json.load(open(os.path.join(os.environ["OUTDIR"], "_gate_H", "pixel_tests.json")))
if not r.get("comparisons"):
    print("   no comparisons (are both single_*.pth and dual_*.pth present?)"); sys.exit(1)
c = r["comparisons"][0]
assert c["n_pixels"] > 100000, f"only {c['n_pixels']} test pixels"
cb = (c.get("bootstrap_cluster") or {}).get("ci95_delta_iou")
print("   ΔIoU=%+.4f | pixelCI=%s | clusterCI=%s | McNemar p=%s"
      % (c["iou"]["delta_A_minus_B"], c["bootstrap_pixel"]["ci95_delta_iou"], cb,
         (c.get("mcnemar") or {}).get("p_value")))
PYEOF
    ok "gate: EXP-H ok"

    rm -rf "${OUT}/_gate_I"
    ${PY} -u exp_i_change_head_loss.py --data-dir "${DATA}" --out-dir "${OUT}" \
        --tag _gate_I --seeds 42 --configs focal_g2_bal --epochs 2 \
        --batch-size "${BATCH}" || die "gate: EXP-I crashed"
    have "${OUT}/_gate_I/change_head_runs.json" || die "gate: EXP-I wrote no json"
    ok "gate: EXP-I ok (2 epochs — the 'verdict' it prints is a SMOKE TEST, ignore it)"

    rm -rf "${OUT}/_gate_H" "${OUT}/_gate_I" "${OUT}/_gate_J"
    ok "GATE PASSED — data loads, models infer, losses train, tables written"
}

expH() {
    local tag="${1:-${TAG_H}}"
    local data="${2:-${DATA}}"
    log "=== EXP-H: pixel-level paired inference (tag=${tag}, bootstrap=${BOOTSTRAP}) ==="
    pick_data "${data}"
    if have "${OUT}/${tag}/pixel_tests.json"; then
        warn "EXP-H[${tag}] already done -> SKIP (delete ${OUT}/${tag} to redo)"; return
    fi
    EXTRA=()
    [ "${CLASSICAL}" = "1" ] && EXTRA=(--include-classical)
    ${PY} -u exp_h_paired_pixel_tests.py --data-dir "${DATA}" \
        --ckpt-dir "${CKPT_DIR}" --out-dir "${OUT}" --tag "${tag}" \
        --seeds "${SEEDS}" --lambdas "${LAMBDAS}" --bootstrap "${BOOTSTRAP}" \
        --batch-size "${BATCH}" ${EXTRA[@]+"${EXTRA[@]}"} ${GARGS[@]+"${GARGS[@]}"} \
        || die "EXP-H failed"
    have "${OUT}/${tag}/pixel_tests.json" || die "EXP-H produced no json"
    ok "EXP-H done -> ${OUT}/${tag}/TABLE_paired_pixel_tests.md"
}

expHg() {
    [ -d "${DATA_GROUPED}" ] || die "grouped split not found at ${DATA_GROUPED} — set DATA_GROUPED=..."
    log "=== EXP-H on the LEAKAGE-FREE grouped split ==="
    expH "expH_paired_pixel_grouped" "${DATA_GROUPED}"
}

expI() {
    log "=== EXP-I: change-head loss search (configs=${CONFIGS}, epochs=${EPOCHS}) ==="
    pick_data "${DATA}"
    if have "${OUT}/expI_change_head/VERDICT.md"; then
        warn "EXP-I already done -> SKIP"; return
    fi
    ${PY} -u exp_i_change_head_loss.py --data-dir "${DATA}" --out-dir "${OUT}" \
        --seeds "${SEEDS}" --configs "${CONFIGS}" --epochs "${EPOCHS}" \
        --batch-size "${BATCH}" --decision-threshold "${THRESHOLD}" \
        || die "EXP-I failed"
    have "${OUT}/expI_change_head/change_head_runs.json" || die "EXP-I produced no json"
    ok "EXP-I done -> ${OUT}/expI_change_head/VERDICT.md"
}

expJ() {
    local tag="${1:-${TAG_J}}"
    local data="${2:-${DATA}}"
    log "=== EXP-J: split composition (tag=${tag}) ==="
    pick_data "${data}"
    ${PY} -u exp_j_split_report.py --data-dir "${DATA}" --out-dir "${OUT}" \
        --tag "${tag}" ${GARGS[@]+"${GARGS[@]}"} || die "EXP-J failed"
    ok "EXP-J done -> ${OUT}/${tag}/TABLE_split_composition.md"
}

# ---------------------------------------------------------------------------
status() {
    echo "──── P1 batch status   $(date '+%F %T') ────"
    for t in expJ_split expH_paired_pixel expH_paired_pixel_grouped expI_change_head; do
        printf "%-32s " "${t}"
        if have "${OUT}/${t}"; then
            n=$(find "${OUT}/${t}" -type f 2>/dev/null | wc -l)
            echo "done (${n} files)"
        else
            echo "not started"
        fi
    done
    echo
    echo "── running processes ──"
    ps -eo pid,etime,pcpu,pmem,cmd 2>/dev/null | grep -E "python.*exp_[hij]_" | grep -v grep \
        || echo "   (none)"
    echo
    echo "── GPU ──"
    nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total \
        --format=csv,noheader 2>/dev/null || echo "   nvidia-smi unavailable"
    echo
    echo "── newest log, last 12 lines (non-blocking) ──"
    newest=$(ls -t "${LOGS}"/*.log 2>/dev/null | head -1)
    if [ -n "${newest}" ]; then echo "   (${newest})"; tail -n 12 "${newest}"; else echo "   (no logs yet)"; fi
}

summary() {
    echo "════════════════════════════════════════════════════════════════"
    echo " P1 batch summary   $(date '+%F %T')"
    echo "════════════════════════════════════════════════════════════════"
    for t in expJ_split expH_paired_pixel expH_paired_pixel_grouped; do
        if have "${OUT}/${t}/TABLE_split_composition.md"; then
            echo; echo "── ${t}: split composition ──"
            head -20 "${OUT}/${t}/TABLE_split_composition.md"
        fi
        if have "${OUT}/${t}/TABLE_paired_pixel_tests.md"; then
            echo; echo "── ${t}: paired pixel-level tests ──"
            head -30 "${OUT}/${t}/TABLE_paired_pixel_tests.md"
        fi
    done
    if have "${OUT}/expI_change_head/TABLE_change_head.md"; then
        echo; echo "── EXP-I change head ──"
        head -30 "${OUT}/expI_change_head/TABLE_change_head.md"
        echo; echo "── EXP-I VERDICT ──"
        cat "${OUT}/expI_change_head/VERDICT.md"
    fi
    echo; echo "════════════════════════════════════════════════════════════════"
}

# ---------------------------------------------------------------------------
case "${1:-}" in
    gate)    gate ;;
    expH)    expH "${2:-}" "${3:-}" ;;
    expHg)   expHg ;;
    expI)    expI ;;
    expJ)    expJ "${2:-}" "${3:-}" ;;
    status)  status ;;
    summary) summary ;;
    all)
        gate
        expJ
        expH
        expI
        summary
        echo
        ok "ALL DONE. Read it with:  bash run_p1_extra.sh summary"
        ;;
    *)
        head -34 "$0" | sed 's/^# \{0,1\}//'
        exit 1 ;;
esac

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exp_t_leaveout.py — 受控消融：把「与评测集重叠的训练 patch」拿掉再训一遍。

为什么需要这个实验
------------------
common_test 的 DiD（+4.3pp）是**观察性**比较：它用 tile 协议当反事实，
假设"两组 patch 的固有难度差"对两个模型一样。这个假设无法检验。
更麻烦的是 E_unseen 只有 18 个 patch，patch 级 bootstrap 的 95% CI 宽达 ±6pp，
统计上分辨不出 4pp。

本脚本把问题改造成**真正的受控实验**：
    同一个脚本、同一套超参、同一批随机种子、同一个评测集 E，
    唯一变量 = 训练集里**有没有那 48 个与 E 重叠的 patch**。

    arm "with"    : patch-train 全量 280 个 patch（其中有 48 个就是 E 的成员）
    arm "without" : 把 48 个剔除，剩 232 个 patch

于是：
    Δ_seen   = IoU(E_seen | with) − IoU(E_seen | without)    ← 泄漏收益（直接因果）
    Δ_unseen = IoU(E_unseen | with) − IoU(E_unseen | without)  ← 安慰剂（应≈0）
    DiD      = Δ_seen − Δ_unseen

Δ_seen 就是"因为这 48 个 patch 在训练集里，模型在它们上面多拿了多少分"，
无混杂、可检验。Δ_unseen 是内置的安慰剂对照：如果它也明显非零，说明
两个 arm 之间还有别的差异（不该发生），结果就不可信。

用法
----
bash 里：
  python exp_t_leaveout.py --precheck            # 1 seed × 2 epoch，验证能跑通
  python exp_t_leaveout.py                       # 全量 8 seed × 30 epoch（两臂共 16 次训练）
  python exp_t_leaveout.py --compare             # 只汇总已产出的结果
"""

import argparse
import glob
import hashlib
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from exp_r_did import tstat_ci, signflip_p, boot_diff, iou_from_counts, pool


# ---------------------------------------------------------------- helpers
def md5_of(a):
    return hashlib.md5(np.ascontiguousarray(a, dtype=np.float32).tobytes()).hexdigest()


def per_patch_counts(pred, gt):
    """pred, gt: (N,H,W) → [{'md5':..,'tp':..,'fp':..,'fn':..}]"""
    out = []
    for i in range(len(pred)):
        p = np.asarray(pred[i]).astype(np.int64)
        g = np.asarray(gt[i]).astype(np.int64)
        out.append({"tp": int(((p == 1) & (g == 1)).sum()),
                    "fp": int(((p == 1) & (g == 0)).sum()),
                    "fn": int(((p == 0) & (g == 1)).sum())})
    return out


def resolve_dirs(project):
    cands_patch = [os.path.join(project, "data/data_geoaux"),
                   os.path.join(project, "results/supplementary/data_geoaux")]
    cands_eval = [os.path.join(project, "data/data_grouped_geoaux"),
                  os.path.join(project, "results/supplementary/expD_spatial/data_grouped_geoaux")]
    P = next((c for c in cands_patch if os.path.isdir(c)), None)
    E = next((c for c in cands_eval if os.path.isdir(c)), None)
    return P, E


# ---------------------------------------------------------------- training
def run(args):
    # 延迟导入：compare 模式在无 torch 环境也能跑
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
    from common import (UNet, DualDataset, load_split, train_stats, set_seed,
                        get_device, train_model)
    torch.backends.cudnn.benchmark = True
    dev = get_device(not args.cpu)
    project = args.project
    PATCH, EVAL = args.patch_dir or resolve_dirs(project)[0], args.eval_dir or resolve_dirs(project)[1]
    if not PATCH or not EVAL:
        sys.exit("[fatal] 找不到 data_geoaux / data_grouped_geoaux，请用 --patch-dir/--eval-dir 指定")
    print(f"[paths] PATCH = {PATCH}\n[paths] EVAL  = {EVAL}")

    idx = json.load(open(args.index, encoding="utf-8"))
    seen_md5 = {r["md5"] for r in idx["E"] if r["seen_in_training"]}
    eval_md5 = [r["md5"] for r in idx["E"]]
    print(f"[index] E={len(idx['E'])}  E_seen={len(seen_md5)}")
    assert len(seen_md5) == idx["n_seen"], "索引内 seen 数量不一致"

    x_tr, ys_tr, yc_tr = load_split(PATCH, "train")
    print(f"[data] patch-train {x_tr.shape}")
    tr_md5 = [md5_of(a) for a in x_tr]

    drop = [i for i, m in enumerate(tr_md5) if m in seen_md5]
    keep = [i for i, m in enumerate(tr_md5) if m not in seen_md5]
    print(f"[data] 与 E 重叠的训练 patch: {len(drop)} 个 → 剔除后剩 {len(keep)} 个")
    if len(drop) != len(seen_md5):
        print(f"[!!] 期望剔除 {len(seen_md5)} 个，实际 {len(drop)} 个 —— md5 匹配不全，请检查")

    x_ev, ys_ev, yc_ev = load_split(EVAL, "test")
    print(f"[data] E = {x_ev.shape[0]} patch（与索引 {len(eval_md5)} 对齐检查中…）")

    arms = {"with": list(range(len(x_tr))), "without": keep}
    os.makedirs(os.path.join(args.out, "evals"), exist_ok=True)
    json.dump({"dropped_md5": [tr_md5[i] for i in drop],
               "n_train_with": len(x_tr), "n_train_without": len(keep),
               "index": os.path.abspath(args.index)},
              open(os.path.join(args.out, "leaveout_manifest.json"), "w"), indent=1)

    for arm, sel in arms.items():
        os.makedirs(os.path.join(args.out, "evals", arm), exist_ok=True)
        xs, yss, ycs = x_tr[sel], ys_tr[sel], yc_tr[sel]
        mean, std = train_stats(xs)          # 每个 arm 用自己的统计量（训练集变了就该重算）
        tmp = os.path.join(args.out, "_norm_" + arm + ".npz")
        np.savez(tmp, mean=mean, std=std)
        for seed in args.seed_list:
            tag = f"{arm}_seed{seed}"
            outc = os.path.join(args.out, "evals", arm, f"{tag}.json")
            if os.path.exists(outc) and not args.force:
                print(f"[skip] {tag} 已存在")
                continue
            set_seed(seed)
            tr_ds = DualDataset(xs, yss, ycs, mean=mean, std=std, augment=True)
            va_x, va_ys, va_yc = load_split(PATCH, "val")
            va_ds = DualDataset(va_x, va_ys, va_yc, mean=mean, std=std, augment=False)
            ev_ds = DualDataset(x_ev, ys_ev, yc_ev, mean=mean, std=std, augment=False)
            tl = DataLoader(tr_ds, batch_size=args.batch_size, shuffle=True, num_workers=2, drop_last=False)
            vl = DataLoader(va_ds, batch_size=args.batch_size, shuffle=False, num_workers=2)
            el = DataLoader(ev_ds, batch_size=args.batch_size, shuffle=False, num_workers=2)

            model = UNet(in_channels=xs.shape[1], num_classes=2, num_change_classes=4,
                         base=args.base, dual=False).to(dev)
            ys_flat = yss.astype(np.int64)
            cnt = np.bincount(ys_flat.ravel(), minlength=2).astype(np.float64)
            w = torch.tensor((cnt.sum() / (2 * np.maximum(cnt, 1))), dtype=torch.float32).to(dev)
            crit_s = nn.CrossEntropyLoss(weight=w)
            crit_c = nn.CrossEntropyLoss()
            t0 = time.time()
            print(f"\n{'='*64}\n[{tag}] n_train={len(xs)} seed={seed} epochs={args.epochs}\n{'='*64}")
            _, pred_s, _, hist, best = train_model(
                model, False, tl, vl, el, dev, args.epochs, args.lr,
                0.0, crit_s, crit_c, log_prefix=f"[{arm}] ")
            dt = time.time() - t0
            coins = per_patch_counts(pred_s, ys_ev)
            # 对齐 md5：eval 顺序与索引顺序可能不同，按 md5 建映射
            order = [md5_of(a) for a in x_ev]
            rows = []
            for c, m in zip(coins, order):
                rows.append({"md5": m, **c})
            hit = sum(1 for r in rows if r["md5"] in set(eval_md5))
            print(f"[{tag}] 完成 {dt/60:.1f} min | best_val={best:.4f} | md5 命中 {hit}/{len(rows)}")
            json.dump({"name": tag, "family": "conv", "protocol": arm, "per_patch": rows,
                       "n_train": len(xs), "seed": seed, "epochs": args.epochs,
                       "best_val": float(best)},
                      open(outc, "w", encoding="utf-8"), indent=1)
    print("\n[all done] 现在跑 --compare")


# ---------------------------------------------------------------- compare
def compare(args):
    idx = json.load(open(args.index, encoding="utf-8"))
    seen = {r["md5"]: r["seen_in_training"] for r in idx["E"]}
    split = {r["md5"]: r.get("patch_split") for r in idx["E"]}

    def load_arm(arm):
        out = {}
        for f in sorted(glob.glob(os.path.join(args.out, "evals", arm, "*.json"))):
            d = json.load(open(f, encoding="utf-8"))
            out[d["seed"]] = d["per_patch"]
        return out

    MAN = {}
    mf = os.path.join(args.out, "leaveout_manifest.json")
    if os.path.exists(mf):
        MAN = json.load(open(mf, encoding="utf-8"))
    A, B = load_arm("with"), load_arm("without")
    seeds = sorted(set(A) & set(B))
    if not seeds:
        sys.exit("[fatal] 没有配对的 with/without 结果，先跑训练")

    def grp(pc, want_seen):
        return [p for p in pc if p["md5"] in seen and seen[p["md5"]] is want_seen]

    rows = []
    for s in seeds:
        r = {"seed": s}
        for arm, D in (("with", A), ("without", B)):
            pc = D[s]
            r[f"seen_{arm}"] = iou_from_counts(pool(grp(pc, True)))
            r[f"unseen_{arm}"] = iou_from_counts(pool(grp(pc, False)))
            r[f"all_{arm}"] = iou_from_counts(pool(pc))
        r["d_seen"] = r["seen_with"] - r["seen_without"]
        r["d_unseen"] = r["unseen_with"] - r["unseen_without"]
        r["did"] = r["d_seen"] - r["d_unseen"]
        rows.append(r)

    def agg(k):
        v = np.array([r[k] for r in rows], dtype=float)
        return v.mean(), (v.std(ddof=1) if len(v) > 1 else 0.0), len(v)

    L = ["# EXP-T — 剔除重叠训练 patch 的受控消融", "",
         f"- arm **with**：训练集 n={MAN.get('n_train_with', '?')}（含与 E 重叠的训练 patch）",
         f"- arm **without**：训练集 n={MAN.get('n_train_without', '?')}（剔除重叠 patch）",
         f"- 配对数：{len(seeds)} 个种子", "",
         "| seed | IoU(E_seen) with | without | Δ_seen | IoU(E_unseen) with | without | Δ_unseen | **DiD** |",
         "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in rows:
        L.append(f"| {r['seed']} | {r['seen_with']:.4f} | {r['seen_without']:.4f} | "
                 f"{r['d_seen']*100:+.2f}pp | {r['unseen_with']:.4f} | {r['unseen_without']:.4f} | "
                 f"{r['d_unseen']*100:+.2f}pp | **{r['did']*100:+.2f}pp** |")

    L += ["", "## 汇总", "",
          "| 量 | mean | 95% CI | p(perm) | 同号 |", "|---|---:|---|---:|---:|"]
    note = {}
    for k, label in (("d_seen", "Δ_seen（泄漏收益，直接因果）"),
                     ("d_unseen", "Δ_unseen（安慰剂，应≈0）"),
                     ("did", "DiD")):
        m, sd, n = agg(k)
        v = np.array([r[k] for r in rows], dtype=float)
        t, lo, hi = tstat_ci(v) if n > 1 else (np.nan, np.nan, np.nan)
        pp = signflip_p(v) if n >= 3 else float("nan")
        L.append(f"| {label} | {m*100:+.2f}pp | [{lo*100:+.2f}, {hi*100:+.2f}] | "
                 f"{pp:.4f} | {int((v>0).sum())}/{n} |")
        note[k] = {"mean": float(m), "lo": float(lo), "hi": float(hi), "p_perm": float(pp)}

    L += ["", "判读：", "",
          "1. **Δ_seen 是本文要的数** —— 同一批 patch、同一架构、同一超参、同一评测集，",
          "   只差训练集里有没有它们。这就是「空间重叠」在 IoU 上的直接代价。",
          "2. **Δ_unseen 是安慰剂** —— 它衡量 arm 之间是否还有别的差异（训练集少了 48 个 patch",
          "   带来的整体能力变化）。若它明显非零，Δ_seen 就要按 DiD 修正。",
          "3. 与 common_test 的观察性 DiD（+4.3pp）对照：若两者量级一致，结论互证；",
          "   若受控消融给出更小/更大的值，以本实验为准（无混杂、可配对的因果设计）。", ""]

    os.makedirs(args.out, exist_ok=True)
    md = os.path.join(args.out, "TABLE_leaveout.md")
    open(md, "w", encoding="utf-8").write("\n".join(L))
    json.dump({"rows": rows, "summary": note}, open(os.path.join(args.out, "leaveout.json"), "w"),
              indent=1, default=float)
    print("\n".join(L))
    print(f"\n[write] {md}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default="/root/autodl-tmp/QaidamPov")
    ap.add_argument("--patch-dir", default=None)
    ap.add_argument("--eval-dir", default=None)
    ap.add_argument("--index", default="/root/autodl-tmp/QaidamPov/results/supplementary/common_test/common_index.json")
    ap.add_argument("--out", default="/root/autodl-tmp/QaidamPov/results/supplementary/expT_leaveout")
    ap.add_argument("--seeds", default="7,13,42,99,123,777,2024,2025")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--base", type=int, default=32)
    ap.add_argument("--precheck", action="store_true", help="1 seed × 2 epoch 快检")
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--cpu", action="store_true")
    a = ap.parse_args()
    if a.precheck:
        a.seeds, a.epochs = "42", 2
        a.out = a.out.rstrip("/") + "_precheck"
        print(f"[precheck] out={a.out} seeds={a.seeds} epochs={a.epochs}")
    a.seed_list = [int(s) for s in a.seeds.split(",") if s.strip()]
    if a.compare:
        compare(a)
    else:
        run(a)


if __name__ == "__main__":
    main()

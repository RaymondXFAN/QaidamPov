#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-B — Raw metric / confusion-matrix export from EXISTING checkpoints.

Why this exists
---------------
Table 4 is mathematically impossible as printed (accuracy 0.690 < 0.764 forced by
the dominant class; macro-F1 0.36 != mean of the four per-class F1 0.4175;
weighted columns 0.81/0.69/0.75 inconsistent with the reported supports). The
only correct fix is to re-export the *raw* test-set confusion matrices. This
script does exactly that for every checkpoint already on disk — no retraining.

It also produces the two supporting numbers the reviewers asked for:
  * test-set class distribution (Table 2 currently reports train only);
  * Prithvi stability F1-macro (quoted as "8.6 pp worse" but never tabulated).

Outputs (in --out-dir/<tag>/)
    raw_metrics_all.json          per-checkpoint static+change metrics + CM
    test_distribution.json        test-set class counts (static & change)
    TABLE_change_per_class.md     per-class P/R/F1 + pooled vs per-run reconciliation
    reconciliation.md             the arithmetic audit (why the old numbers were wrong)
"""
from __future__ import annotations

import os
import sys
import glob
import json
import argparse

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    DualTaskModel, metrics_bundle, metrics_change, metrics_static, write_json,
    get_device, makedirs, load_split, train_stats, CHANGE_CLASS_NAMES,
    STATIC_CLASS_NAMES, DEFAULT_DATA_DIR, DEFAULT_CKPT_DIR, DEFAULT_OUT_DIR,
)


# ---------------------------------------------------------------------------
# Prithvi model (mirrors 03_train_prithvi.py / 04_eval_all.py exactly)
# ---------------------------------------------------------------------------
class LoRALinear(nn.Module):
    def __init__(self, original_linear, r=8, alpha=16):
        super().__init__()
        self.original = original_linear
        self.r, self.alpha = r, alpha
        self.scaling = alpha / r
        self.original.weight.requires_grad = False
        if self.original.bias is not None:
            self.original.bias.requires_grad = False
        d_in, d_out = original_linear.in_features, original_linear.out_features
        self.lora_A = nn.Parameter(torch.zeros(d_in, r))
        self.lora_B = nn.Parameter(torch.zeros(r, d_out))
        self.dropout = nn.Dropout(0.1)

    def forward(self, x):
        return self.original(x) + self.dropout(x) @ self.lora_A @ self.lora_B * self.scaling


def apply_lora_to_model(model, r=8, alpha=16, target_modules=("qkv", "proj")):
    for name, module in model.named_modules():
        if any(t in name.lower() for t in target_modules) and isinstance(module, nn.Linear):
            parts = name.split(".")
            parent = model
            for part in parts[:-1]:
                parent = getattr(parent, part)
            setattr(parent, parts[-1], LoRALinear(module, r=r, alpha=alpha))
    return model


class ViTSegDecoder(nn.Module):
    def __init__(self, embed_dim=768, img_size=128, patch_size=16, num_classes=2):
        super().__init__()
        self.img_size = img_size
        self.num_patches_side = img_size // patch_size
        self.decoder = nn.Sequential(
            nn.Conv2d(embed_dim, 256, 3, padding=1), nn.BatchNorm2d(256), nn.GELU(),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(256, 128, 3, padding=1), nn.BatchNorm2d(128), nn.GELU(),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(128, 64, 3, padding=1), nn.BatchNorm2d(64), nn.GELU(),
            nn.Upsample(scale_factor=4, mode='bilinear', align_corners=False),
            nn.Conv2d(64, num_classes, 1),
        )

    def forward(self, patch_tokens):
        B = patch_tokens.shape[0]
        H = W = self.num_patches_side
        x = patch_tokens.transpose(1, 2).reshape(B, -1, H, W)
        x = self.decoder(x)
        return x


class PrithviDualTaskModel(nn.Module):
    def __init__(self, img_size=128, in_channels=6, lora_r=8, lora_alpha=16):
        super().__init__()
        import timm
        self.img_size = img_size
        self.encoder = timm.create_model(
            "vit_small_patch16_224", pretrained=False, img_size=img_size,
            in_chans=in_channels, num_classes=0, embed_dim=768, depth=12, num_heads=12)
        apply_lora_to_model(self.encoder, r=lora_r, alpha=lora_alpha)
        self.decoder_static = ViTSegDecoder(768, img_size, num_classes=2)
        self.decoder_change = ViTSegDecoder(768, img_size, num_classes=4)

    def forward(self, x):
        feats = self.encoder.forward_features(x)
        pt = feats[:, 1:]
        return self.decoder_static(pt), self.decoder_change(pt)


# ---------------------------------------------------------------------------
@torch.no_grad()
def predict(model, loader, device):
    model.eval()
    ps, pc = [], []
    for batch in loader:
        x = batch[0].to(device)
        os_, oc = model(x)
        ps.append(os_.argmax(1).cpu().numpy())
        pc.append(oc.argmax(1).cpu().numpy())
    return np.concatenate(ps), np.concatenate(pc)


def eval_all(ckpt_paths, model_factory, device, test_loader, ys_te, yc_te,
             name):
    out = []
    for p in ckpt_paths:
        ck = torch.load(p, map_location="cpu", weights_only=False)
        model = model_factory().to(device)
        model.load_state_dict(ck["model_state_dict"])
        ps, pc = predict(model, test_loader, device)
        m = metrics_bundle(ys_te, yc_te, ps, pc)
        rec = {"checkpoint": os.path.basename(p),
               "seed": ck.get("seed"), "lambda_change": ck.get("lambda_change"),
               **m}
        out.append(rec)
        print(f"  ✅ {os.path.basename(p)} | static IoU={m['static']['iou_saline']:.4f} "
              f"| change F1m={m['change']['f1_macro']:.4f}")
    return out


def pooled_from_records(records, section):
    """Sum confusion matrices across records -> pooled metrics."""
    cms = [np.array(r[section]["confusion_matrix"]) for r in records]
    pooled = sum(cms)                      # label order preserved
    return pooled


def metrics_from_cm(cm, labels, names):
    cm = np.asarray(cm)
    total = cm.sum()
    acc = float(np.trace(cm) / total)
    # compute P/R/F1 directly from CM (works for pooled or single run)
    eps = 1e-12
    P = np.diag(cm) / np.maximum(cm.sum(axis=0), eps)
    R = np.diag(cm) / np.maximum(cm.sum(axis=1), eps)
    F = 2 * P * R / np.maximum(P + R, eps)
    support = cm.sum(axis=1)
    w = support / total
    return {
        "accuracy": acc,
        "precision": [float(x) for x in P],
        "recall": [float(x) for x in R],
        "f1": [float(x) for x in F],
        "support": [int(x) for x in support],
        "macro_P": float(np.mean(P)), "macro_R": float(np.mean(R)),
        "macro_F1": float(np.mean(F)),
        "weighted_P": float(np.sum(w * P)), "weighted_R": float(np.sum(w * R)),
        "weighted_F1": float(np.sum(w * F)),
        "class_names": names,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--ckpt-dir", default=DEFAULT_CKPT_DIR)
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expB_raw_metrics")
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--cpu", action="store_true")
    args = ap.parse_args()

    device = get_device(prefer_cuda=not args.cpu)
    out_root = os.path.join(args.out_dir, args.tag)
    makedirs(out_root)

    x_tr, ys_tr, yc_tr = load_split(args.data_dir, "train")
    mean, std = train_stats(x_tr)
    _, ys_te, yc_te = load_split(args.data_dir, "test")
    test_x = np.load(os.path.join(args.data_dir, "test_x.npy")).astype(np.float32)
    test_x_n = (test_x - mean.reshape(1, -1, 1, 1)) / std.reshape(1, -1, 1, 1)
    te = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(
            torch.FloatTensor(test_x_n), torch.LongTensor(ys_te),
            torch.LongTensor(yc_te)),
        batch_size=args.batch_size, shuffle=False, num_workers=0)

    # --- test set distribution (Table 2 test column / Q-24) ---
    dist = {
        "static": {STATIC_CLASS_NAMES[c]: int((ys_te == c).sum()) for c in (0, 1)},
        "change": {CHANGE_CLASS_NAMES[c]: int((yc_te == c).sum()) for c in range(4)},
        "total_pixels": int(ys_te.size),
    }
    write_json(os.path.join(out_root, "test_distribution.json"), dist)
    print("📊 test distribution:", json.dumps(dist, ensure_ascii=False))

    all_records = {"dual": [], "prithvi": []}

    # --- DualTask CNN ---
    dual_ckpts = sorted(glob.glob(os.path.join(args.ckpt_dir, "dual_*.pth")))
    if dual_ckpts:
        print(f"\n🏋️  DualTask checkpoints: {len(dual_ckpts)}")
        all_records["dual"] = eval_all(
            dual_ckpts, lambda: DualTaskModel(6, 2, 4), device, te, ys_te, yc_te, "dual")
    else:
        print(f"⚠️  no dual_*.pth under {args.ckpt_dir}")

    # --- Prithvi ---
    try:
        import timm  # noqa: F401
        pr_ckpts = sorted(glob.glob(os.path.join(args.ckpt_dir, "prithvi_lora_*.pth")))
        if pr_ckpts:
            print(f"\n🌍 Prithvi checkpoints: {len(pr_ckpts)}")
            all_records["prithvi"] = eval_all(
                pr_ckpts, lambda: PrithviDualTaskModel(128, 6, 8, 16),
                device, te, ys_te, yc_te, "prithvi")
        else:
            print(f"⚠️  no prithvi_lora_*.pth under {args.ckpt_dir}")
    except ImportError:
        print("⚠️  timm not installed -> skipping Prithvi export")

    write_json(os.path.join(out_root, "raw_metrics_all.json"), all_records)

    # --- pooled vs per-run reconciliation for the CHANGE head ---
    L = ["# EXP-B — Change-head per-class metrics (raw export)\n",
         f"Test set: {dist['total_pixels']} pixels. "
         f"Class shares (change): " +
         ", ".join(f"{k} {v/dist['total_pixels']*100:.1f}%" for k, v in dist["change"].items()) + "\n"]

    for group in ("dual", "prithvi"):
        recs = all_records[group]
        if not recs:
            continue
        pooled_cm = pooled_from_records(recs, "change")
        pooled = metrics_from_cm(pooled_cm, [0, 1, 2, 3], CHANGE_CLASS_NAMES)
        mean_of_runs = {
            k: float(np.mean([r["change"][k] for r in recs]))
            for k in ("accuracy", "f1_macro", "f1_weighted")
        }
        L.append(f"## {group} — pooled confusion matrix (sum of {len(recs)} runs)\n")
        L.append("```")
        L.append(str(pooled_cm))
        L.append("```\n")
        L.append("### Per-class (from pooled CM)\n")
        L.append("| class | P | R | F1 | support |")
        L.append("|---|---:|---:|---:|---:|")
        for c in range(4):
            L.append(f"| {CHANGE_CLASS_NAMES[c]} | {pooled['precision'][c]:.4f} | "
                     f"{pooled['recall'][c]:.4f} | {pooled['f1'][c]:.4f} | {pooled['support'][c]} |")
        L.append(f"| **macro** | {pooled['macro_P']:.4f} | {pooled['macro_R']:.4f} | "
                 f"{pooled['macro_F1']:.4f} | {sum(pooled['support'])} |")
        L.append(f"| **weighted** | {pooled['weighted_P']:.4f} | {pooled['weighted_R']:.4f} | "
                 f"{pooled['weighted_F1']:.4f} | — |\n")
        L.append(f"- pooled accuracy = {pooled['accuracy']:.4f} "
                 f"(equals weighted recall = {pooled['weighted_R']:.4f})")
        L.append(f"- mean-of-runs: acc {mean_of_runs['accuracy']:.4f}, "
                 f"F1-macro {mean_of_runs['f1_macro']:.4f}, F1-weighted {mean_of_runs['f1_weighted']:.4f}")
        L.append(f"- macro-F1 from pooled CM = {pooled['macro_F1']:.4f}  vs  "
                 f"mean of per-class F1 = {np.mean(pooled['f1']):.4f} "
                 f"-> {'SAME' if abs(pooled['macro_F1']-np.mean(pooled['f1']))<1e-9 else 'DIFFERENT'}\n")

    with open(os.path.join(out_root, "TABLE_change_per_class.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))

    # --- reconciliation note (arithmetic audit) ---
    R = ["# Table 4 arithmetic audit\n",
         "Manuscript reported: accuracy 0.690; macro-F1 0.36; weighted 0.81/0.69/0.75.\n",
         "Checks:",
         "- In single-label multi-class, weighted recall == accuracy. Any (accuracy, "
         "weighted-recall) pair that differs is internally inconsistent.",
         "- macro-F1 must equal the mean of per-class F1 only if computed from the "
         "same confusion matrix; report the exact source.",
         "- If the dominant class share * its recall already exceeds the reported "
         "accuracy, the accuracy is impossible.\n",
         "See TABLE_change_per_class.md for the values re-derived from the raw CM."]
    with open(os.path.join(out_root, "reconciliation.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(R))

    print(f"\n✅ EXP-B done. See {out_root}/TABLE_change_per_class.md and raw_metrics_all.json")


if __name__ == "__main__":
    main()

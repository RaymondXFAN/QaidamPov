#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-J — split composition report (answers: "how many tiles are in train/test?")

A leakage-free claim is only credible if the test split holds a meaningful share
of the spatial units.  If 18 tiles split 14/2/2, the grouped evaluation rests on
two held-out tiles and a reviewer will (rightly) push back.  This prints and
stores the exact patch/tile composition of every split.

Pure numpy, no GPU, runs in seconds.

Usage
-----
    python exp_j_split_report.py --data-dir <processed_dual> \
        --groups <patch_tiles.npy> --out-dir <out> [--tag expJ_split]

Outputs
    <out>/<tag>/split_composition.json
    <out>/<tag>/TABLE_split_composition.md
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np

# NB: deliberately does NOT import common.py — that module pulls in torch, and a
# split report must be runnable on any bare CPU box (and in the offline selftest).
DEFAULT_PROJECT = os.environ.get("PROJECT_DIR", "/root/autodl-tmp/QaidamPov")
DEFAULT_DATA_DIR = os.environ.get("DATA_DIR",
                                  os.path.join(DEFAULT_PROJECT, "data", "processed_dual"))
DEFAULT_OUT_DIR = os.environ.get("SUPP_OUT_DIR",
                                 os.path.join(DEFAULT_PROJECT, "results", "supplementary"))


def makedirs(*paths):
    for p in paths:
        os.makedirs(p, exist_ok=True)


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def find_groups(data_dir, explicit=""):
    if explicit and os.path.exists(explicit):
        return explicit
    for cand in ("patch_tiles.npy", "tiles.npy", "groups.npy"):
        p = os.path.join(data_dir, cand)
        if os.path.exists(p):
            return p
    return None


def main():
    ap = argparse.ArgumentParser(description="EXP-J split composition report")
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--groups", default="")
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expJ_split")
    args = ap.parse_args()

    out = os.path.join(args.out_dir, args.tag)
    makedirs(out)

    counts, order = {}, ["train", "val", "test"]
    for s in order:
        f = os.path.join(args.data_dir, f"{s}_y_static.npy")
        if os.path.exists(f):
            counts[s] = len(np.load(f, mmap_mode="r"))
    rep = {"data_dir": args.data_dir, "n_patches": counts,
           "total_patches": int(sum(counts.values()))}

    gp = find_groups(args.data_dir, args.groups)
    if gp:
        g = np.load(gp)
        rep["groups_file"] = gp
        rep["n_patches_with_group_id"] = int(len(g))
        if len(g) != rep["total_patches"]:
            rep["warning"] = (f"groups length {len(g)} != total patches "
                              f"{rep['total_patches']} — assuming train|val|test order, "
                              f"which may be wrong")
        off, per = 0, {}
        for s in order:
            k = counts.get(s, 0)
            sub = g[off:off + k]
            per[s] = {"n_patches": int(k),
                      "n_tiles": int(len(np.unique(sub))),
                      "tiles": sorted(int(v) for v in np.unique(sub))}
            off += k
        rep["splits"] = per
        rep["total_tiles"] = int(len(np.unique(g)))
        # tile-level overlap audit: a tile must not straddle two splits
        strad = []
        if "splits" in rep:
            sets = {s: set(rep["splits"][s]["tiles"]) for s in order}
            for a in order:
                for b in order:
                    if a < b:
                        inter = sets[a] & sets[b]
                        if inter:
                            strad.append({"pair": [a, b], "tiles": sorted(inter)})
        rep["split_tile_overlap"] = strad
        rep["leakage_free_ok"] = (len(strad) == 0)
    else:
        rep["warning"] = "no groups file found — pass --groups, or tile split is unknown"

    write_json(os.path.join(out, "split_composition.json"), rep)

    L = ["# Split composition\n", f"Data dir: `{args.data_dir}`\n"]
    if "splits" in rep:
        L += ["| split | patches | tiles | tile ids |", "|---|---|---|---|"]
        for s in order:
            d = rep["splits"][s]
            ids = ", ".join(str(t) for t in d["tiles"]) or "—"
            L.append(f"| {s} | {d['n_patches']} | **{d['n_tiles']}** | {ids} |")
        L.append(f"\nTotal tiles: **{rep['total_tiles']}**  |  "
                 f"tiles appearing in more than one split: "
                 f"**{'NONE ✅' if rep['leakage_free_ok'] else rep['split_tile_overlap']}**")
    else:
        L.append("_No groups file — only patch counts available:_ "
                 f"`{counts}`")
    open(os.path.join(out, "TABLE_split_composition.md"), "w", encoding="utf-8").write(
        "\n".join(L))

    print(json.dumps({k: v for k, v in rep.items() if k != "splits"}, indent=2))
    if "splits" in rep:
        for s in order:
            print(f"  {s:5s}: {rep['splits'][s]['n_patches']:4d} patches, "
                  f"{rep['splits'][s]['n_tiles']:2d} tiles")
    print(f"[exp_j] wrote {out}/split_composition.json + TABLE_split_composition.md")


if __name__ == "__main__":
    main()

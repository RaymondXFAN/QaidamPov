#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest_p2.py — offline, CPU-only, torch-free self-test for batch P2.

Builds a tiny synthetic dataset (so it needs neither the real tensors nor a GPU),
then runs EXP-K and EXP-M end-to-end through their real entry points and asserts
that they write what they promise.

  python selftest_p2.py          -> expect: PASSED n | FAILED 0
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print(f"  {'PASS' if cond else 'FAIL'}  {name}" + (f"   [{detail}]" if detail else ""))


def make_data(root, n_train=12, n_test=6, H=32, W=32, C=6, seed=0):
    rng = np.random.RandomState(seed)
    for split, n in (("train", n_train), ("val", 4), ("test", n_test)):
        x = rng.rand(n, C, H, W).astype(np.float32) + 0.5
        ys = np.zeros((n, H, W), dtype=np.int64)
        for i in range(n):
            # a blobby "saline" region so the depth transform has structure
            cy, cx = rng.randint(10, H - 10), rng.randint(10, W - 10)
            r = rng.randint(5, 9)
            yy, xx = np.ogrid[:H, :W]
            ys[i, (yy - cy) ** 2 + (xx - cx) ** 2 <= r * r] = 1
            x[i, :, ys[i] == 1] += 1.2          # make the classes separable
        yc = np.where(ys == 1, 1, 0).astype(np.int64)
        os.makedirs(os.path.join(root, "processed_dual"), exist_ok=True)
        np.save(os.path.join(root, "processed_dual", f"{split}_x.npy"), x)
        np.save(os.path.join(root, "processed_dual", f"{split}_y_static.npy"), ys)
        np.save(os.path.join(root, "processed_dual", f"{split}_y_change.npy"), yc)


def run(script, *args):
    cmd = [PY, os.path.join(HERE, script)] + list(args)
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr


def main():
    tmp = tempfile.mkdtemp(prefix="p2test_")
    data = os.path.join(tmp, "processed_dual")
    make_data(tmp)
    out = os.path.join(tmp, "results")
    print(f"[setup] synthetic dataset -> {data}")

    # ------------------------------------------------------------ EXP-K
    print("\n[EXP-K] label separability")
    rc, so, se = run("exp_k_label_purity.py", "--data-dir", data,
                     "--out-dir", os.path.join(out, "label_purity"),
                     "--max-pixels", "5000")
    check("EXP-K exits 0", rc == 0, f"rc={rc} {se.strip()[:160]}")
    jp = os.path.join(out, "label_purity", "label_separability.json")
    check("EXP-K writes json", os.path.exists(jp))
    if os.path.exists(jp):
        j = json.load(open(jp, encoding="utf-8"))
        check("EXP-K declares PPV not estimable", j.get("ppv_estimable") is False)
        check("EXP-K has per-band Fisher", len(j.get("fisher_ratio_per_band", {})) == 6)
        check("EXP-K has single-band oracle", len(j.get("single_band_oracle", [])) == 6)
        check("EXP-K multivariate Fisher > 0", j.get("fisher_ratio_multivariate", 0) > 0)
    check("EXP-K writes table",
          os.path.exists(os.path.join(out, "label_purity", "TABLE_label_purity.md")))

    # ------------------------------------------------------------ EXP-M
    print("\n[EXP-M] clean auxiliary labels")
    dst = os.path.join(tmp, "data_geoaux")
    rc, so, se = run("exp_m_clean_aux.py", "--src-dir", data, "--dst-dir", dst,
                     "--overwrite")
    check("EXP-M exits 0", rc == 0, f"rc={rc} {se.strip()[:160]}")
    check("EXP-M writes train_y_change", os.path.exists(os.path.join(dst, "train_y_change.npy")))
    check("EXP-M writes card", os.path.exists(os.path.join(dst, "dataset_card_geoaux.json")))
    if os.path.exists(os.path.join(dst, "train_y_change.npy")):
        ys = np.load(os.path.join(data, "train_y_static.npy"))
        aux = np.load(os.path.join(dst, "train_y_change.npy"))
        check("aux shape matches static", aux.shape == ys.shape)
        check("aux classes subset of {0,1,2,3}", set(np.unique(aux)) <= {0, 1, 2, 3},
              str(sorted(np.unique(aux).tolist())))
        check("non-saline pixels are class 0", bool((aux[ys == 0] == 0).all()))
        check("saline pixels are 1/2/3 only", bool((aux[ys == 1] > 0).all()))
        # monotone depth: class 3 pixels must be strictly interior
        c3 = (aux == 3).sum()
        check("class 3 (core) exists on blobs", c3 > 0, f"{int(c3)} px")
    if os.path.exists(os.path.join(dst, "dataset_card_geoaux.json")):
        card = json.load(open(os.path.join(dst, "dataset_card_geoaux.json"), encoding="utf-8"))
        check("card records no product drift",
              card["construction"]["product_version_drift"].startswith("none"))
        check("card lists three splits", len(card["splits"]) == 3, str(list(card["splits"])))

    # ------------------------------------------------------------ EXP-L
    print("\n[EXP-L] classical baselines, 6-band arm")
    try:
        rc, so, se = run("exp_f_classical_baselines.py", "--data-dir", data,
                         "--out-dir", out, "--tag", "expF_bands6",
                         "--features", "bands6", "--max-train-pixels", "2000")
        if rc == 0:
            found = any(f.endswith(".json")
                        for _, _, fs in os.walk(os.path.join(out, "expF_bands6"))
                        for f in fs)
            check("EXP-L bands6 exits 0 and writes json", found, f"rc={rc}")
        else:
            check("EXP-L importable (sklearn present)", False, se.strip()[:160])
    except Exception as e:                                   # pragma: no cover
        check("EXP-L importable (sklearn present)", False, str(e)[:160])

    # ------------------------------------------------------------ summary
    npass = sum(1 for _, ok, _ in RESULTS if ok)
    nfail = len(RESULTS) - npass
    print("\n" + "=" * 62)
    print(f"PASSED {npass}  |  FAILED {nfail}")
    print("=" * 62)
    if nfail == 0:
        print("SELFTEST PASSED - batch P2 is ready for the server")
    else:
        print("SELFTEST FAILED - fix before launching anything")
    shutil.rmtree(tmp, ignore_errors=True)
    return 0 if nfail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

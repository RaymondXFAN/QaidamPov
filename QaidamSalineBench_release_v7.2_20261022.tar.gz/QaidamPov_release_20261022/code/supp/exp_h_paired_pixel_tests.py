#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-H — Paired INFERENCE at pixel level (McNemar + bootstrap), plus the
        missing uncertainty estimate for the classical baselines.

The problem this fixes
----------------------
Table 6 / Table 7 pair the dual-task CNN against the single-task CNN across
n = 3 seeds and report p = 0.669.  A reviewer will (correctly) say: *with n = 3
that test has essentially zero power, so "no significant difference" is not
evidence of no difference.*  The fix is not more seeds — it is to run the paired
test at the resolution where the data actually is: ~1e6 test pixels and ~18
spatial tiles.  That turns an *underpowered* null into a *precise* one.

What it computes (see paired_stats.py for the algebra)
------------------------------------------------------
For every requested model pair (A, B) on the held-out test split:
  1. ΔIoU (saline class) at pixel level.
  2. **Pixel bootstrap** 95% CI  — multinomial resampling of the joint
     (y, predA, predB) table; exact in distribution, O(1) per replicate.
  3. **Spatial cluster bootstrap** 95% CI — resamples whole tiles/patches, so it
     respects spatial autocorrelation. This is the defensible interval; the
     pixel-level one is anti-conservative and is reported only because it was
     requested.
  4. **McNemar** on per-pixel correctness (exact binomial; normal approx with
     continuity correction for huge m).
  5. Accuracy difference and the per-tile paired ΔIoU summary (a paired test with
     ~18 units instead of 3).
  6. With --with-change: the same battery on the 4-class change head.
  7. With --include-classical: trains pixel-level RF / XGBoost here, so the
     *winner* of Table 2 finally carries a bootstrap std.

Outputs (in --out-dir/<tag>/)
    preds/<model>.npy               per-pixel hard labels (uint8, N x H x W)
    pixel_tests.json                all statistics, machine readable
    TABLE_paired_pixel_tests.md     paper-ready table
    split_report.json               patches/tiles per split (see also EXP-J)

Usage
-----
    python exp_h_paired_pixel_tests.py --data-dir .../processed_dual \
        --ckpt-dir .../expA_multiseed_lambda/ckpts --out-dir ... \
        --seeds 42,123,2024 --lambdas 1.0,0.3,0.5,0.7 --include-classical
"""
from __future__ import annotations

import os
import sys
import json
import time
import glob
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paired_stats import analyse_pair  # noqa: E402

# torch / common are needed ONLY to *produce* predictions.  --analyze-only works
# on a bare CPU box with nothing but numpy, which is also how it is unit-tested.
try:
    import torch  # noqa: E402
    from common import (  # noqa: E402
        DualTaskModel, SingleTaskModel, load_split, train_stats, makedirs,
        get_device, write_json, DEFAULT_DATA_DIR, DEFAULT_OUT_DIR,
    )
    HAVE_TORCH = True
    STATIC_CLASS_NAMES = ["non-saline", "saline"]
    CHANGE_CLASS_NAMES = ["stable non-saline", "stable saline", "expansion", "shrinkage"]
except Exception:  # pragma: no cover - numpy-only environment
    HAVE_TORCH = False
    DEFAULT_PROJECT = os.environ.get("PROJECT_DIR", "/root/autodl-tmp/QaidamPov")
    DEFAULT_DATA_DIR = os.environ.get(
        "DATA_DIR", os.path.join(DEFAULT_PROJECT, "data", "processed_dual"))
    DEFAULT_OUT_DIR = os.environ.get(
        "SUPP_OUT_DIR", os.path.join(DEFAULT_PROJECT, "results", "supplementary"))
    STATIC_CLASS_NAMES = ["non-saline", "saline"]
    CHANGE_CLASS_NAMES = ["stable non-saline", "stable saline", "expansion", "shrinkage"]

    def makedirs(*paths):
        for p in paths:
            os.makedirs(p, exist_ok=True)

    def write_json(path, obj):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2, ensure_ascii=False)

    def load_split(data_dir, split):
        return (np.load(os.path.join(data_dir, f"{split}_x.npy")),
                np.load(os.path.join(data_dir, f"{split}_y_static.npy")),
                np.load(os.path.join(data_dir, f"{split}_y_change.npy")))


if HAVE_TORCH:
    _no_grad = torch.no_grad
else:
    def _no_grad():                       # no-op stand-in so imports never fail
        def _dec(fn):
            return fn
        return _dec


# ===========================================================================
#  Prediction export
# ===========================================================================
@_no_grad()
def predict_torch(model, x, mean, std, device, dual, batch_size=8):
    """Return (static uint8 (N,H,W), change uint8 (N,H,W) or None)."""
    model.eval()
    xin = (x - mean.reshape(1, -1, 1, 1)) / (std.reshape(1, -1, 1, 1))
    ps, pc = [], []
    for s in range(0, len(xin), batch_size):
        xb = torch.from_numpy(xin[s:s + batch_size]).float().to(device)
        out = model(xb)
        if dual:
            os_, oc = out
            pc.append(oc.argmax(1).cpu().numpy().astype(np.uint8))
        else:
            os_ = out
        ps.append(os_.argmax(1).cpu().numpy().astype(np.uint8))
    return np.concatenate(ps), (np.concatenate(pc) if dual else None)


def load_cnn(ckpt_path, in_ch, dual, device):
    ck = torch.load(ckpt_path, map_location="cpu")
    sd = ck.get("model_state_dict", ck)
    model = (DualTaskModel(in_channels=in_ch, num_classes=2, num_change_classes=4)
             if dual else SingleTaskModel(in_channels=in_ch, num_classes=2))
    model.load_state_dict(sd)
    return model.to(device)


def train_classical(kind, x_tr, ys_tr, x_te, max_pixels, seed):
    """Pixel-level RF / XGB. Returns uint8 (N,H,W) predictions on the test split."""
    from sklearn.ensemble import RandomForestClassifier
    rng = np.random.RandomState(seed)
    Xtr = x_tr.transpose(0, 2, 3, 1).reshape(-1, x_tr.shape[1])
    ytr = ys_tr.ravel()
    if max_pixels and len(Xtr) > max_pixels:
        sel = rng.choice(len(Xtr), max_pixels, replace=False)
        Xtr, ytr = Xtr[sel], ytr[sel]
    if kind == "rf":
        clf = RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=seed)
    elif kind == "xgb":
        import xgboost as xgb
        clf = xgb.XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.1,
                                subsample=0.8, tree_method="hist", n_jobs=-1,
                                random_state=seed, verbosity=0)
    else:
        raise ValueError(kind)
    clf.fit(Xtr, ytr)
    Xte = x_te.transpose(0, 2, 3, 1).reshape(-1, x_te.shape[1])
    return clf.predict(Xte).astype(np.uint8).reshape(
        x_te.shape[0], x_te.shape[2], x_te.shape[3])


# ===========================================================================
def split_report(data_dir, groups_path, out):
    rep = {}
    try:
        rep["n_patches"] = {
            s: int(len(np.load(os.path.join(data_dir, f"{s}_y_static.npy"),
                               mmap_mode="r")))
            for s in ("train", "val", "test")}
    except FileNotFoundError:
        rep["n_patches"] = None
    if groups_path and os.path.exists(groups_path) and rep["n_patches"]:
        g = np.load(groups_path)
        ntr = rep["n_patches"]["train"]
        cuts = {"train": (0, ntr),
                "val": (ntr, ntr + rep["n_patches"]["val"]),
                "test": (ntr + rep["n_patches"]["val"], None)}
        per = {}
        for s, (a, b) in cuts.items():
            u = np.unique(g[a:b])
            per[s] = {"n_patches": rep["n_patches"][s], "n_tiles": int(len(u)),
                      "tiles": sorted(int(v) for v in u)}
        rep["splits"] = per
        rep["total_tiles"] = int(len(np.unique(g)))
        sets = {s: set(per[s]["tiles"]) for s in per}
        strad = sorted(sets["train"] & sets["test"]) + sorted(sets["train"] & sets["val"]) \
            + sorted(sets["val"] & sets["test"])
        rep["tiles_in_more_than_one_split"] = strad
        rep["leakage_free_ok"] = (len(strad) == 0)
    write_json(os.path.join(out, "split_report.json"), rep)
    return rep


def main():
    ap = argparse.ArgumentParser(description="EXP-H paired pixel-level tests")
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--ckpt-dir", default=os.path.join(
        DEFAULT_OUT_DIR, "expA_multiseed_lambda", "ckpts"))
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expH_paired_pixel")
    ap.add_argument("--seeds", default="42,123,2024")
    ap.add_argument("--lambdas", default="1.0,0.3,0.5,0.7")
    ap.add_argument("--split", default="test", choices=["test", "val", "train"])
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--bootstrap", type=int, default=2000)
    ap.add_argument("--classical-seed", type=int, default=42)
    ap.add_argument("--max-train-pixels", type=int, default=800000)
    ap.add_argument("--include-classical", action="store_true",
                    help="also train pixel-level RF/XGB here (gives Table 2's winner a std)")
    ap.add_argument("--groups", default="",
                    help="per-patch tile ids (.npy), length = n_train+n_val+n_test in that order")
    ap.add_argument("--with-change", action="store_true",
                    help="also run the McNemar battery on the 4-class change head")
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--analyze-only", action="store_true",
                    help="reuse preds/ already on disk, skip inference")
    ap.add_argument("--rng-seed", type=int, default=12345)
    args = ap.parse_args()

    out = os.path.join(args.out_dir, args.tag)
    makedirs(out, os.path.join(out, "preds"))
    device = get_device(prefer_cuda=not args.cpu) if HAVE_TORCH else "numpy-only"
    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
    lams = [float(s) for s in args.lambdas.split(",") if s.strip()]
    print(f"🖥️  device={device} | data={args.data_dir} | ckpt={args.ckpt_dir}")
    print(f"   seeds={seeds} lambdas={lams} split={args.split} bootstrap={args.bootstrap}")

    # ---- protocol-consistency guard ---------------------------------------
    # Evaluating patch-level-trained CNNs on the grouped test split is NOT the
    # leakage-free protocol; it silently mixes two protocols in one table.
    _dd = os.path.normpath(args.data_dir).lower()
    _cd = os.path.normpath(args.ckpt_dir).lower()
    if ("group" in _dd or "spatial" in _dd) and "group" not in _cd:
        protocol_warning = (
            f"data dir '{args.data_dir}' looks like a grouped / leakage-free split, "
            f"but ckpt dir '{args.ckpt_dir}' looks like the patch-level runs. "
            "Patch-trained models evaluated on the grouped test split are NOT a "
            "leakage-free result — point --ckpt-dir at checkpoints trained on this "
            "same split (or let RF/XGB be the only models).")
        print("\n" + "!" * 72)
        print("!!  PROTOCOL MISMATCH")
        print(f"!!  {protocol_warning}")
        print("!" * 72 + "\n")
    else:
        protocol_warning = None

    # ---- tile/group ids for the cluster bootstrap -------------------------
    groups_path = args.groups
    if not groups_path:
        for cand in ("patch_tiles.npy", "tiles.npy"):
            p = os.path.join(args.data_dir, cand)
            if os.path.exists(p):
                groups_path = p
                break
    groups = None
    cluster_kind = "tile"
    if groups_path and os.path.exists(groups_path):
        g = np.load(groups_path)
        n = {s: len(np.load(os.path.join(args.data_dir, f"{s}_y_static.npy"),
                            mmap_mode="r")) for s in ("train", "val", "test")}
        off = {"train": 0, "val": n["train"], "test": n["train"] + n["val"]}[args.split]
        groups = g[off:off + n[args.split]]
        print(f"   cluster units: {len(np.unique(groups))} tiles "
              f"(from {os.path.basename(groups_path)})")
    else:
        print("   ⚠️  no tile ids found -> falling back to PATCH-LEVEL clusters. "
              "Still far better than nothing (it respects within-patch correlation); "
              "pass --groups for true tile-level clusters.")
        cluster_kind = "patch"

    rep = split_report(args.data_dir, groups_path, out)
    print("   split report:", json.dumps(rep.get("splits", rep.get("n_patches"))))

    x_te, ys_te, yc_te = load_split(args.data_dir, args.split)
    if groups is None:
        # no tile ids: cluster by patch. Each 128x128 patch is one spatial unit,
        # which still handles within-patch correlation (60-66 units, not 1).
        groups = np.arange(ys_te.shape[0])
        print(f"   cluster units: {len(groups)} PATCHES (fallback)")

    # ---- export predictions ----------------------------------------------
    if not args.analyze_only:
        if not HAVE_TORCH:
            raise SystemExit("❌ EXP-H needs torch to run inference. Install torch, or "
                             "pre-export preds/*.npy and rerun with --analyze-only.")
        x_tr, ys_tr, _ = load_split(args.data_dir, "train")
        mean, std = train_stats(x_tr)
        in_ch = x_te.shape[1]
        for s in seeds:
            ck = os.path.join(args.ckpt_dir, f"single_seed{s}.pth")
            if os.path.exists(ck):
                m = load_cnn(ck, in_ch, dual=False, device=device)
                ps, _ = predict_torch(m, x_te, mean, std, device, False, args.batch_size)
                np.save(os.path.join(out, "preds", f"cnn_single_seed{s}.npy"), ps)
                print(f"   ✔ cnn_single_seed{s}")
            else:
                print(f"   ⚠️  missing {ck}")
            for L in lams:
                ckd = os.path.join(args.ckpt_dir, f"dual_seed{s}_lam{L}.pth")
                if os.path.exists(ckd):
                    m = load_cnn(ckd, in_ch, dual=True, device=device)
                    ps, pc = predict_torch(m, x_te, mean, std, device, True, args.batch_size)
                    np.save(os.path.join(out, "preds", f"cnn_dual_seed{s}_lam{L}.npy"), ps)
                    np.save(os.path.join(out, "preds",
                                         f"cnn_dualchg_seed{s}_lam{L}.npy"), pc)
                    print(f"   ✔ cnn_dual_seed{s}_lam{L}")
                else:
                    print(f"   ⚠️  missing {ckd}")
        if args.include_classical:
            for kind in ("rf", "xgb"):
                t0 = time.time()
                p = train_classical(kind, x_tr, ys_tr, x_te,
                                    args.max_train_pixels, args.classical_seed)
                np.save(os.path.join(out, "preds", f"{kind}.npy"), p)
                print(f"   ✔ {kind} (trained in {time.time()-t0:.1f}s)")

    # ---- collect ----------------------------------------------------------
    static_preds, labels = [], []
    for f in sorted(glob.glob(os.path.join(out, "preds", "*.npy"))):
        nm = os.path.basename(f)[:-4]
        if nm.endswith("_changepred") or nm.startswith("cnn_dualchg"):
            continue
        static_preds.append(np.load(f))
        labels.append(nm)
    if not static_preds:
        raise SystemExit("❌ no predictions available — check --ckpt-dir")
    print(f"\n📊 models available: {labels}")

    rng = np.random.default_rng(args.rng_seed)
    B = args.bootstrap
    results = {"config": vars(args), "split": args.split,
               "class_names": STATIC_CLASS_NAMES, "models": labels,
               "cluster_kind": cluster_kind,
               "n_cluster_units": int(len(np.unique(groups))),
               "n_patches_clustered": int(len(groups)),
               "protocol_warning": protocol_warning,
               "comparisons": []}

    def idx_of(name):
        return labels.index(name) if name in labels else None

    pairs = []
    for s in seeds:
        b = idx_of(f"cnn_single_seed{s}")
        for L in lams:
            a = idx_of(f"cnn_dual_seed{s}_lam{L}")
            if a is not None and b is not None:
                pairs.append((a, b, f"dual(λ={L}) vs single — seed {s}"))
    if idx_of("rf") is not None and idx_of("xgb") is not None:
        pairs.append((idx_of("rf"), idx_of("xgb"), "RF vs XGBoost"))
    if idx_of("rf") is not None and idx_of("cnn_dual_seed42_lam1.0") is not None:
        pairs.append((idx_of("rf"), idx_of("cnn_dual_seed42_lam1.0"), "RF vs dual CNN (seed 42)"))

    for i, j, desc in pairs:
        r = analyse_pair(ys_te, static_preds, groups, (i, j), labels, rng, B, desc)
        results["comparisons"].append(r)
        print(f"\n[{desc}]  ΔIoU = {r['iou']['delta_A_minus_B']:+.4f}")
        print(f"   pixel-boot 95% CI : {r['bootstrap_pixel']['ci95_delta_iou']}")
        if r["bootstrap_cluster"]:
            print(f"   {cluster_kind}-boot 95% CI : "
                  f"{r['bootstrap_cluster']['ci95_delta_iou']}")
        if r["mcnemar"]:
            print(f"   McNemar p         : {r['mcnemar']['p_value']:.4g} "
                  f"({r['mcnemar']['method']})")

    # ---- change head (optional) ------------------------------------------
    if args.with_change:
        chg, chg_lab = [], []
        for s in seeds:
            for L in lams:
                p = os.path.join(out, "preds", f"cnn_dualchg_seed{s}_lam{L}.npy")
                if os.path.exists(p):
                    chg.append(np.load(p)); chg_lab.append(f"chg_dual_seed{s}_lam{L}")
        if len(chg) >= 2:
            results["change_head"] = analyse_pair(
                yc_te, chg, groups, (0, 1), chg_lab, rng, B,
                f"change head: {chg_lab[0]} vs {chg_lab[1]}")

    write_json(os.path.join(out, "pixel_tests.json"), results)
    write_table(results, os.path.join(out, "TABLE_paired_pixel_tests.md"))
    print(f"\n✅ EXP-H done -> {out}/TABLE_paired_pixel_tests.md")


def _fmt_p(p):
    if p is None:
        return "—"
    if p == 0.0:
        return "<1e-300"
    return f"{p:.3g}"


def write_table(res, path):
    ck = res.get("cluster_kind", "tile")
    L = ["# EXP-H — paired pixel-level inference\n"]
    if res.get("protocol_warning"):
        L.append(f"> ⛔ **PROTOCOL MISMATCH — results below are NOT a leakage-free "
                 f"comparison.** {res['protocol_warning']}\n")
    L += [f"Split: **{res['split']}**  |  models: `{', '.join(res['models'])}`  |  "
          f"clustering: **{ck}** ({res.get('n_cluster_units', '?')} units)\n",
          f"| comparison | ΔIoU (A−B) | pixel-boot 95% CI | {ck}-boot 95% CI | "
          f"McNemar p | n pixels | n units |",
          "|---|---|---|---|---|---|---|"]
    for r in res["comparisons"]:
        pb = r["bootstrap_pixel"]["ci95_delta_iou"]
        cb = r["bootstrap_cluster"]["ci95_delta_iou"] if r["bootstrap_cluster"] else None
        L.append("| {} | {:+.4f} | [{:+.4f}, {:+.4f}] | {} | {} | {} | {} |".format(
            r["pair"]["label"], r["iou"]["delta_A_minus_B"], pb[0], pb[1],
            ("[{:+.4f}, {:+.4f}]".format(cb[0], cb[1]) if cb else "—"),
            _fmt_p(r["mcnemar"]["p_value"] if r["mcnemar"] else None),
            r["n_pixels"], r["n_units_cluster"] or "—"))
    L.append(f"\n## Per-{ck} paired ΔIoU (a paired test with "
             f"{res.get('n_cluster_units', '?')} units, not 3)\n")
    for r in res["comparisons"]:
        c = r["bootstrap_cluster"]
        if not c:
            continue
        L.append("- **{}**: mean {:+.4f} ± {:.4f} (n={} {}s), range "
                 "[{:+.4f}, {:+.4f}]".format(
                     r["pair"]["label"], c["per_unit_delta_mean"],
                     c["per_unit_delta_std_ddof1"], c["n_units"], ck,
                     c["per_unit_delta_min"], c["per_unit_delta_max"]))
    L += ["\n## How to read this\n",
          "- If the **tile-bootstrap 95% CI contains 0**, the difference is not "
          "resolvable at the spatial scale that matters — a *precise* null, not an "
          "underpowered one.",
          "- The **pixel** bootstrap assumes independent pixels and is therefore "
          "anti-conservative; it is reported because it was requested, but the "
          "tile-level CI is the one to quote.",
          "- **McNemar tests accuracy, not IoU.** At ~1e6 pixels even a trivial "
          "accuracy difference can reach significance; always read it beside ΔIoU "
          "and its CI, never on its own."]
    open(path, "w", encoding="utf-8").write("\n".join(L))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paired_stats — paired inference primitives for pixel-level model comparison.

Deliberately **numpy-only** (no torch, no sklearn, no scipy) so the statistics
can be unit-tested on any machine, including a bare CPU box.

Representation
--------------
A "cell table" counts pixels by their joint outcome (y_true, pred_0, ..., pred_{k-1}),
encoded as an integer

        code = y_true * 2^k  +  sum_i pred_i * 2^i          ->  2^(k+1) cells

Every quantity we need (TP/FP/FN, IoU, accuracy, McNemar discordant counts) is a
linear read-out of that table.  That is what makes bootstrapping cheap: resampling
pixels is just a multinomial draw over the table, and resampling spatial clusters
is a sum of per-cluster tables.  Both run in O(1) per replicate, regardless of how
many pixels there are (~1e6 here).
"""
from __future__ import annotations

import math

import numpy as np

__all__ = [
    "build_cells", "iou_saline", "accuracy", "mcnemar_counts", "mcnemar_p",
    "percentile_ci", "pairwise_cells", "analyse_pair", "describe",
]


# ---------------------------------------------------------------------------
def build_cells(preds, y, weights=None):
    """preds: list of k uint8 arrays shaped like y. -> float counts, len 2^(k+1)."""
    k = len(preds)
    code = y.astype(np.int64).ravel() * (2 ** k)
    for i, p in enumerate(preds):
        code = code + p.astype(np.int64).ravel() * (2 ** i)
    nc = 2 ** (k + 1)
    if weights is None:
        return np.bincount(code, minlength=nc).astype(np.float64)
    return np.bincount(code, weights=weights, minlength=nc).astype(np.float64)


def _bits(k):
    idx = np.arange(2 ** (k + 1))
    y = ((idx >> k) & 1).astype(bool)
    preds = [((idx >> i) & 1).astype(bool) for i in range(k)]
    return y, preds


def _sel(k, i):
    """Masks on the cell axis for model i: (tp, fp, fn)."""
    y, preds = _bits(k)
    p = preds[i]
    return (y & p), (~y & p), (y & ~p)


def iou_saline(cells, k, i, eps=1e-12):
    """cells: (..., 2^(k+1)) -> IoU of the positive (saline) class for model i."""
    m_tp, m_fp, m_fn = _sel(k, i)
    tp = cells[..., m_tp].sum(-1)
    fp = cells[..., m_fp].sum(-1)
    fn = cells[..., m_fn].sum(-1)
    return tp / (tp + fp + fn + eps)


def accuracy(cells, k, i, eps=1e-12):
    m_tp, m_fp, m_fn = _sel(k, i)
    wrong = m_fp | m_fn
    correct = cells.sum(-1) - cells[..., wrong].sum(-1)
    return correct / (cells.sum(-1) + eps)


def mcnemar_counts(cells, k):
    """k must be 2. Returns (m01, m10): A=pred0 right & B=pred1 wrong, and vice versa.

    (Only valid for BINARY predictions — for the 4-class change head use
    `mcnemar_from_preds`, which does not rely on the cell encoding.)
    """
    if k != 2:
        raise ValueError("mcnemar_counts needs exactly 2 models")
    y, preds = _bits(2)
    a_ok, b_ok = (preds[0] == y), (preds[1] == y)
    m01 = cells[..., (a_ok & ~b_ok)].sum(-1)
    m10 = cells[..., (b_ok & ~a_ok)].sum(-1)
    return float(m01), float(m10)


def mcnemar_from_preds(y, pA, pB):
    """Discordant counts from raw predictions. Works for ANY number of classes,
    because 'correct' is defined as an exact label match, not a bit."""
    y = np.asarray(y)
    a_ok = (np.asarray(pA) == y)
    b_ok = (np.asarray(pB) == y)
    return int(np.sum(a_ok & ~b_ok)), int(np.sum(b_ok & ~a_ok))


def _log_binom_pmf(k, n):
    if k < 0 or k > n:
        return -np.inf
    return (math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)
            - n * math.log(2.0))


def mcnemar_p(m01, m10, max_exact=200000):
    """Two-sided McNemar. Exact binomial when n is small enough, else normal approx."""
    n = int(m01 + m10)
    if n == 0:
        return 1.0, "degenerate(no discordant pairs)"
    lo = int(min(m01, m10))
    if n <= max_exact:
        terms = np.array([_log_binom_pmf(k, n) for k in range(lo + 1)])
        m = terms.max()
        p = 2.0 * float(np.exp(m) * np.sum(np.exp(terms - m)))
        if p > 0.0:                     # exact result usable
            return min(1.0, p), "exact-binomial"
        # underflow: the exact p is below double precision -> report as such
        return 0.0, "exact-binomial(<1e-308, underflow)"
    z = (abs(m01 - m10) - 1.0) / math.sqrt(n)              # continuity correction
    p = math.erfc(abs(z) / math.sqrt(2.0))
    return min(1.0, p), "normal-approx(cc)"


def percentile_ci(samples, alpha=0.05):
    return [float(np.percentile(samples, 100 * alpha / 2)),
            float(np.percentile(samples, 100 * (1 - alpha / 2)))]


def describe(values):
    v = np.asarray(values, dtype=float)
    n = len(v)
    mean = float(np.mean(v)) if n else float("nan")
    sd = float(np.std(v, ddof=1)) if n > 1 else 0.0
    return {"n": n, "mean": mean, "std_ddof1": sd,
            "values": [float(x) for x in v]}


# ---------------------------------------------------------------------------
def pairwise_cells(preds, y, groups=None):
    """Return (cells_all (1, c), cells_per_unit ((T, c) or None), unit_ids)."""
    k = len(preds)
    cells_all = build_cells(preds, y).reshape(1, -1)
    cells_unit, unit_ids = None, None
    if groups is not None:
        grp = np.asarray(groups).ravel()
        if grp.shape[0] != y.shape[0]:
            raise ValueError(f"groups length {grp.shape[0]} != n patches {y.shape[0]}")
        unit_ids = np.unique(grp)
        cells_unit = np.stack([
            build_cells([p[grp == g] for p in preds], y[grp == g])
            for g in unit_ids])
    return cells_all, cells_unit, unit_ids


def analyse_pair(y, preds, groups, pair_idx, labels, rng, B, tag=""):
    """Full paired battery for models pair_idx=(i, j) among `preds`.

    IMPORTANT — only the two models being compared enter the cell table.
    Building the table over *all* models would scale as 2^(k+1) cells; with the
    17 models a full EXP-H run produces that is 2^18 cells, and the cluster
    bootstrap (B x T x cells) would ask for ~75 GB. Constructing the table
    pairwise keeps it at 2^3 = 8 cells no matter how many models there are.
    """
    i, j = pair_idx
    lab_a, lab_b = labels[i], labels[j]
    preds = [preds[i], preds[j]]
    labels = [lab_a, lab_b]
    k, i, j = 2, 0, 1
    cells_all, cells_unit, unit_ids = pairwise_cells(preds, y, groups)
    N = float(cells_all.sum())

    iou_i = float(iou_saline(cells_all, k, i)[0])
    iou_j = float(iou_saline(cells_all, k, j)[0])
    d_iou = iou_i - iou_j
    acc_i = float(accuracy(cells_all, k, i)[0])
    acc_j = float(accuracy(cells_all, k, j)[0])

    # --- pixel bootstrap (anti-conservative; reported because it was asked for)
    p_hat = cells_all[0] / max(N, 1.0)
    draw = rng.multinomial(int(N), p_hat, size=B)
    pix_ci = percentile_ci(iou_saline(draw, k, i) - iou_saline(draw, k, j))
    pix_i_ci = percentile_ci(iou_saline(draw, k, i))
    pix_j_ci = percentile_ci(iou_saline(draw, k, j))
    pix_sd = float(np.std(iou_saline(draw, k, i) - iou_saline(draw, k, j), ddof=1))

    # --- spatial cluster bootstrap (the defensible one)
    cluster = None
    if cells_unit is not None:
        T = len(unit_ids)
        idx = rng.integers(0, T, size=(B, T))
        agg = cells_unit[idx].sum(axis=1)
        cb_d = iou_saline(agg, k, i) - iou_saline(agg, k, j)
        per_tile = (iou_saline(cells_unit, k, i) - iou_saline(cells_unit, k, j))
        cluster = {
            "n_reps": B, "n_units": int(T),
            "ci95_delta_iou": percentile_ci(cb_d),
            "significant": bool(percentile_ci(cb_d)[0] > 0 or percentile_ci(cb_d)[1] < 0),
            "ci95_iou_A": percentile_ci(iou_saline(agg, k, i)),
            "ci95_iou_B": percentile_ci(iou_saline(agg, k, j)),
            "per_unit_delta_mean": float(np.mean(per_tile)),
            "per_unit_delta_std_ddof1": float(np.std(per_tile, ddof=1)) if T > 1 else 0.0,
            "per_unit_delta_min": float(np.min(per_tile)),
            "per_unit_delta_max": float(np.max(per_tile)),
            "per_unit_delta": [float(v) for v in per_tile],
        }

    # --- McNemar on per-pixel correctness (valid for any number of classes)
    m01, m10 = mcnemar_from_preds(y, preds[i], preds[j])
    p_val, method = mcnemar_p(m01, m10)
    mcn = {"m01_A_right_B_wrong": float(m01), "m10_B_right_A_wrong": float(m10),
           "n_discordant": float(m01 + m10), "p_value": p_val, "method": method,
           "note": "tests ACCURACY, not IoU; with ~1e6 pixels even a trivial "
                   "difference can be significant — always read it next to ΔIoU"}

    return {
        "pair": {"A": labels[i], "B": labels[j],
                 "label": f"{labels[i]} vs {labels[j]}"},
        "tag": tag, "n_pixels": int(N),
        "n_units_cluster": int(len(unit_ids)) if unit_ids is not None else None,
        "iou": {labels[i]: iou_i, labels[j]: iou_j, "delta_A_minus_B": d_iou},
        "iou_ci_pixel": {labels[i]: pix_i_ci, labels[j]: pix_j_ci},
        "accuracy": {labels[i]: acc_i, labels[j]: acc_j, "delta_A_minus_B": acc_i - acc_j},
        "bootstrap_pixel": {"n_reps": B, "std_delta": pix_sd,
                            "ci95_delta_iou": pix_ci,
                            "significant": bool(pix_ci[0] > 0 or pix_ci[1] < 0)},
        "bootstrap_cluster": cluster,
        "mcnemar": mcn,
    }

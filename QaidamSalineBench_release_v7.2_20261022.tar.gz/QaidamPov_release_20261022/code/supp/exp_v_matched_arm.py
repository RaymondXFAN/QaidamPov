#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""exp_v_matched_arm.py — 补一条「样本量匹配臂 C′」，让 B→C 的归因站得住。

为什么需要
----------
EXP-U 里 arm B（232 块，patch 级）与 arm C（274 块，tile 级/异瓦片）同时改变了
**两个**东西：训练样本量（232 → 274）和空间来源（同瓦片 → 异瓦片）。
所以 B−C 这一步无法归因。

本脚本补一条 C′：**同样来自异瓦片（空间来源与 C 相同），但只取 232 块（样本量与 B 相同）**。
有了 C′ 就可以拆成两个干净的对比：

    B → C'   只变空间来源（232 块不动）      = 纯「留瓦片」代价
    C' → C   只变样本量（-42 块不动空间来源）  = 纯「数据量」代价
    B → C    两者之和（原表里的 6.7 点）

对五族各做一次，8 个种子，与 EXP-U 完全相同的架构/超参/评测集 E。

用法
----
    cd /root/autodl-tmp/<项目根>

    # 0) 预检（1 seed / 1 epoch，约 2 分钟，必须看到 json 真的写出来）
    python supp/exp_v_matched_arm.py --family unet --precheck

    # 1) 五族
    python supp/exp_v_matched_arm.py --family unet
    python supp/exp_v_matched_arm.py --family cnn
    python supp/exp_v_matched_arm.py --family prithvi --prithvi-dir weights
    python supp/exp_v_matched_arm.py --family pixel

    # 2) 汇总（把 EXP-U 的 A/B/C 与本脚本的 C′ 拼成一张表）
    python supp/exp_v_matched_arm.py --compare

产出
----
<out>/<family>/matched/matched_seed{S}.json      per_patch: md5/tp/fp/fn
<out>/TABLE_matched.md

注意
----
* 本脚本不改动 EXP-U 的任何产出，只新增一个 arm。
* C′ 的 232 块用**固定选择种子**（--select-seed，默认 0）随机抽取，
  与训练种子无关，保证 8 个训练种子看到的是同一批 232 块。
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def _load_ablation_module(project=None):
    """找到并导入 exp_u_ablation_all（不同机器上目录名可能不同）。"""
    import importlib

    cands = [HERE,
             os.path.join(project, "supp") if project else None,
             os.path.dirname(HERE),
             os.path.join(os.path.dirname(HERE), "supp"),
             "/root/autodl-tmp/QaidamPov/supp",
             "/root/autodl-tmp/QaidamSalineBench/supp"]
    seen = []
    for d in cands:
        if not d or d in seen or not os.path.isdir(d):
            continue
        seen.append(d)
        if not any(os.path.exists(os.path.join(d, m + ".py"))
                   for m in ("exp_u_ablation_all", "exp_u_ablation")):
            continue
        if d not in sys.path:
            sys.path.insert(0, d)
        for name in ("exp_u_ablation_all", "exp_u_ablation"):
            if os.path.exists(os.path.join(d, name + ".py")):
                print(f"[import] {name} <- {d}")
                return importlib.import_module(name), d
    sys.exit("[fatal] 找不到 exp_u_ablation_all.py / exp_u_ablation.py。\n"
             "        试过：\n  " + "\n  ".join(seen) + "\n"
             "        用 --code-dir 指定放消融脚本的目录。")


_eu = None
_code_dir = HERE


def _eu_get():
    return _eu


for _d in (HERE,):
    sys.path.insert(0, _d)

ARM = "matched"


# ------------------------------------------------------------------ selection
def select_matched(n_total, n_keep, select_seed):
    """从 tile 级训练集里抽 n_keep 个 patch（固定种子）。"""
    if n_keep >= n_total:
        print(f"[warn] n_keep={n_keep} >= n_total={n_total}，等价于全用")
        return list(range(n_total))
    rng = np.random.default_rng(select_seed)
    sel = rng.choice(n_total, size=n_keep, replace=False)
    return sorted(int(i) for i in sel)


# ------------------------------------------------------------------ run
def run(args):
    global _eu, _code_dir
    _eu, _code_dir = _load_ablation_module(args.project)
    sys.path.insert(0, _code_dir)
    from common import load_split
    eu = _eu

    project = args.project
    PATCH = args.patch_dir or eu.resolve_dirs(project)[0]
    EVAL = args.eval_dir or eu.resolve_dirs(project)[1]
    if not PATCH or not EVAL:
        sys.exit("[fatal] 找不到 data_geoaux / data_grouped_geoaux，用 --patch-dir / --eval-dir 指定")

    idx = json.load(open(args.index, encoding="utf-8"))
    seen_md5 = {r["md5"] for r in idx["E"] if r["seen_in_training"]}
    eval_md5 = {r["md5"] for r in idx["E"]}

    # C′ 的训练集 = 与 C 相同的 tile 级训练集
    x_tr, ys_tr, yc_tr = load_split(EVAL, "train")
    n_keep = args.n_keep
    sel = select_matched(len(x_tr), n_keep, args.select_seed)
    arms = [(ARM, sel)]

    print(f"[paths] PATCH={PATCH}")
    print(f"[paths] EVAL={EVAL}")
    print(f"[family] {args.family}")
    print(f"[data] tile 级训练集 {len(x_tr)} 块 → C′ 取 {len(sel)} 块（select_seed={args.select_seed}）")

    x_ev, ys_ev, yc_ev = load_split(EVAL, "test")
    print(f"[data] E={x_ev.shape[0]}")

    if args.family == "pixel":
        eu.run_pixel(args, EVAL, EVAL, x_tr, ys_tr, arms, x_ev, ys_ev)
    else:
        eu.run_deep(args, args.family, EVAL, EVAL, x_tr, ys_tr, yc_tr, arms,
                    x_ev, ys_ev, yc_ev, seen_md5, eval_md5)


# ------------------------------------------------------------------ compare
def _load_patch_scores(d, arm):
    out = {}
    for f in glob.glob(os.path.join(d, arm, "*.json")):
        j = json.load(open(f, encoding="utf-8"))
        out[j["seed"]] = j["per_patch"]
    return out


def compare(args):
    """A/B/C 来自 EXP-U 目录，C′ 来自本脚本目录，拼成一张表。"""
    global _eu, _code_dir
    if _eu is None:
        _eu, _code_dir = _load_ablation_module(args.project)
        sys.path.insert(0, _code_dir)
    eu = _eu
    if not os.path.isdir(args.out):
        sys.exit(f"[fatal] C′ 目录还不存在：{args.out}\n        先跑 --family unet / cnn / prithvi / pixel（可加 --precheck 先试）")
    fams = sorted(x for x in os.listdir(args.out)
                  if os.path.isdir(os.path.join(args.out, x, ARM)))
    if not fams:
        sys.exit("[fatal] 本目录还没有 C′ 产出，先跑 --family")

    L = ["# EXP-V — 样本量匹配臂 C′（拆开 B→C 的两重变化）", "",
         "臂：A = patch 级全量（含 E 的 48 块）；B = 删掉那 48 块（232）；",
         "C′ = tile 级但只取 232 块；C = tile 级全量（274）。", "",
         "| family | n | B | C′ | C | B→C′（空间） | C′→C（样本量） | B→C（合计） |",
         "|---|---:|---:|---:|---:|---:|---:|---:|"]
    summary = {}
    for fam in fams:
        base = os.path.join(args.base_out, fam)
        A = _load_patch_scores(base, "with")
        B = _load_patch_scores(base, "without")
        C = _load_patch_scores(base, "tile")
        M = _load_patch_scores(os.path.join(args.out, fam), ARM)
        seeds = sorted(set(A) & set(B) & set(M))
        if not seeds:
            L.append(f"| {fam} | 0 | — | — | — | — | — | — |")
            continue

        def m(arm_scores, tag):
            v = [eu.iou_from_counts(eu.pool(arm_scores[s])) for s in seeds if s in arm_scores]
            return float(np.mean(v)) if v else float("nan")

        b_, c_, m_ = m(B, "B"), m(C, "C"), m(M, "C'")
        b2c_p = (b_ - m_) * 100
        c2c_p = (m_ - c_) * 100
        tot = (b_ - c_) * 100
        summary[fam] = {"n": len(seeds), "B": b_, "Cp": m_, "C": c_,
                        "space": b2c_p, "size": c2c_p, "total": tot}
        L.append(f"| {fam} | {len(seeds)} | {b_:.4f} | {m_:.4f} | {c_:.4f} | "
                 f"**{b2c_p:+.2f}pp** | **{c2c_p:+.2f}pp** | {tot:+.2f}pp |")

    L += ["", "判读：若 C′→C 接近 0，则原来 B→C 的那 6.7 点几乎全部来自「空间来源」，",
          "与样本量无关 —— 这正是论文 §IV-C 想主张的，但此前只能靠符号论证。", ""]
    md = os.path.join(args.out, "TABLE_matched.md")
    os.makedirs(args.out, exist_ok=True)
    open(md, "w", encoding="utf-8").write("\n".join(L))
    json.dump(summary, open(os.path.join(args.out, "matched_summary.json"), "w"), indent=1)
    print("\n".join(L))
    print(f"\n[write] {md}")


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", default="/root/autodl-tmp/QaidamSalineBench")
    ap.add_argument("--patch-dir", default=None)
    ap.add_argument("--eval-dir", default=None)
    ap.add_argument("--index", default=None,
                    help="默认 <project>/results/supplementary/common_test/common_index.json")
    ap.add_argument("--out", default=None,
                    help="默认 <project>/results/supplementary/expV_matched")
    ap.add_argument("--base-out", default=None,
                    help="EXP-U 的产出目录，默认 <project>/results/supplementary/expU_ablation_all")
    ap.add_argument("--family", choices=["unet", "cnn", "prithvi", "pixel"], default="unet")
    ap.add_argument("--classifiers", default="rf,xgb")
    ap.add_argument("--seeds", default="7,13,42,99,123,777,2024,2025")
    ap.add_argument("--n-keep", type=int, default=232,
                    help="C′ 保留的 patch 数，应与 arm B 一致（默认 232）")
    ap.add_argument("--select-seed", type=int, default=0,
                    help="抽取 232 块用的固定种子（与训练种子无关）")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--base", type=int, default=32)
    ap.add_argument("--lambda-change", type=float, default=1.0)
    ap.add_argument("--lora-r", type=int, default=8)
    ap.add_argument("--lora-alpha", type=int, default=16)
    ap.add_argument("--code-dir", default=None,
                    help="放 exp_u_ablation_all.py 的目录（默认自动搜索）")
    ap.add_argument("--prithvi-dir", default=None)
    ap.add_argument("--max-pixels", type=int, default=800000)
    ap.add_argument("--n-trees", type=int, default=200)
    ap.add_argument("--precheck", action="store_true")
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--cpu", action="store_true")
    a = ap.parse_args()
    if a.code_dir:
        sys.path.insert(0, a.code_dir)

    R = a.project.rstrip("/")

    def first_existing(cands, what):
        for c in cands:
            if c and os.path.exists(c):
                print(f"[auto] {what} = {c}")
                return c
        sys.exit(f"[fatal] 找不到 {what}，试过：\n  " + "\n  ".join(str(c) for c in cands)
                 + "\n        用命令行参数显式指定。")

    if a.index is None:
        a.index = first_existing([f"{R}/results/supplementary/common_test/common_index.json",
                                  "results/supplementary/common_test/common_index.json"],
                                 "common_index.json")
    if a.out is None:
        a.out = f"{R}/results/supplementary/expV_matched"
    if a.base_out is None:
        cands = [f"{R}/results/supplementary/expU_ablation_all",
                 "results/supplementary/expU_ablation_all",
                 f"{R}/results/supplementary/expU_ablation",
                 "results/supplementary/expU_ablation"]
        a.base_out = first_existing(cands, "EXP-U 产出目录")

    a.classifiers = [c.strip() for c in a.classifiers.split(",") if c.strip()]
    a.seed_list = [int(s) for s in a.seeds.split(",") if s.strip()]

    if a.precheck:
        a.seeds, a.epochs = "42", 1
        a.seed_list = [42]
        a.out = a.out.rstrip("/") + "_precheck"
        a.max_pixels = min(a.max_pixels, 50000)
        print(f"[precheck] family={a.family} out={a.out}")

    if a.compare:
        compare(a)
    else:
        run(a)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-D — Spatial-leakage-safe (grouped) re-split, with optional retrain.

Why this exists
---------------
Reviewer P1 #1 (Q-16): patches are 128x128 crops taken with stride 64, i.e. 50%
overlap. If the 280/60/60 split was made *by patch*, near-duplicate content lands
in both train and test and IoU 0.803 is inflated. The fix is a group-aware split
(by MGRS tile or geographic block), then a re-run.

Modes
    --mode audit   quantify leakage if per-patch coordinates are available
                   (needs --coords: Nx2 lon/lat in the concatenated order
                    train,val,test). Reports the fraction of test patches whose
                    nearest train/val patch is closer than the patch footprint.
    --mode split   build leak-free splits from a per-patch group id file
                   (--groups: N ints, one per patch) and write
                   <out>/data_grouped/{train,val,test}_{x,y_static,y_change}.npy
    --mode train   train the dual-task CNN on the grouped splits and evaluate
                   (a new, leakage-free IoU to replace/qualify 0.803)

The group file is the key input. It can be produced from the preprocessing stage
(one id per patch = the MGRS tile / scene it was cropped from) or, failing that,
by clustering per-patch centres into spatial blocks.
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    load_split, write_json, makedirs, set_seed, get_device,
    DEFAULT_DATA_DIR, DEFAULT_OUT_DIR,
)

PATCH_M = 128 * 10  # 1280 m footprint at 10 m


def _load_groups(path):
    if path.endswith(".npy"):
        return np.load(path).astype(np.int64).ravel()
    if path.endswith(".json"):
        return np.array(json.load(open(path)), dtype=np.int64).ravel()
    # csv: first column
    return np.loadtxt(path, dtype=np.int64, delimiter=",").ravel()


def mode_audit(args):
    n_tr, n_va, n_te = (len(load_split(args.data_dir, s)[0])
                        for s in ("train", "val", "test"))
    print(f"Split sizes: train={n_tr} val={n_va} test={n_te} (total={n_tr+n_va+n_te})")
    if not args.coords:
        print("⚠️  --coords not given: cannot measure overlap numerically.")
        print("    Provide Nx2 lon/lat (patch centres, concatenated order "
              "train,val,test) to get a leakage estimate.")
        print("    Rule of thumb: with stride 64 and a 128-px window, adjacent "
              "patches share 50% pixels, so any random patch-level split leaks.")
        return
    coords = np.load(args.coords).astype(np.float64)
    assert coords.shape[0] == n_tr + n_va + n_te, \
        f"coords has {coords.shape[0]} rows, expected {n_tr+n_va+n_te}"
    # approximate metres (deg -> m) at ~37N
    lat0 = np.deg2rad(coords[:, 1].mean())
    mx = 111320.0 * np.cos(lat0)
    my = 110540.0
    xy = np.stack([coords[:, 0] * mx, coords[:, 1] * my], axis=1)
    tr = xy[:n_tr]
    va = xy[n_tr:n_tr + n_va]
    te = xy[n_tr + n_va:]
    pool = np.vstack([tr, va])
    # nearest train/val neighbour for each test patch
    d = np.sqrt(((te[:, None, :] - pool[None, :, :]) ** 2).sum(-1))
    nn = d.min(axis=1)
    frac_overlap = float((nn < PATCH_M).mean())
    write_json(os.path.join(args.out_dir, args.tag, "leakage_audit.json"), {
        "patch_footprint_m": PATCH_M,
        "n_test": int(len(te)),
        "min_nn_m": float(nn.min()),
        "median_nn_m": float(np.median(nn)),
        "frac_test_patches_overlapping_trainval": frac_overlap,
    })
    print(f"🔎 nearest train/val patch for each test patch: "
          f"min={nn.min():.0f} m, median={np.median(nn):.0f} m")
    print(f"🔎 fraction of test patches within one footprint (<{PATCH_M} m): "
          f"{frac_overlap*100:.1f}%  -> leakage risk")


def mode_split(args):
    if not args.groups:
        print("❌ --mode split requires --groups (one group id per patch).")
        print("    See the module docstring for how to produce it.")
        sys.exit(1)
    groups = _load_groups(args.groups)
    splits = [load_split(args.data_dir, s) for s in ("train", "val", "test")]
    n_tr = len(splits[0][0])
    total = sum(len(s[0]) for s in splits)
    assert len(groups) == total, f"groups has {len(groups)} entries, expected {total}"
    x = np.concatenate([s[0] for s in splits], 0)
    ys = np.concatenate([s[1] for s in splits], 0)
    yc = np.concatenate([s[2] for s in splits], 0)

    uniq = np.unique(groups)
    rng = np.random.RandomState(args.seed)
    rng.shuffle(uniq)
    n_g = len(uniq)
    n_val_g = max(1, int(round(n_g * args.val_frac)))
    n_test_g = max(1, int(round(n_g * args.test_frac)))
    test_g = set(uniq[:n_test_g].tolist())
    val_g = set(uniq[n_test_g:n_test_g + n_val_g].tolist())
    tr_idx = np.array([i for i in range(total) if groups[i] not in test_g and groups[i] not in val_g])
    va_idx = np.array([i for i in range(total) if groups[i] in val_g])
    te_idx = np.array([i for i in range(total) if groups[i] in test_g])

    out = os.path.join(args.out_dir, args.tag, "data_grouped")
    makedirs(out)
    for name, idx in (("train", tr_idx), ("val", va_idx), ("test", te_idx)):
        np.save(os.path.join(out, f"{name}_x.npy"), x[idx])
        np.save(os.path.join(out, f"{name}_y_static.npy"), ys[idx])
        np.save(os.path.join(out, f"{name}_y_change.npy"), yc[idx])
        print(f"  {name}: {len(idx)} patches ({len(set(groups[idx].tolist()))} groups)")
    write_json(os.path.join(args.out_dir, args.tag, "grouped_split.json"),
               {"n_groups": int(n_g),
                "train_patches": int(len(tr_idx)), "val_patches": int(len(va_idx)),
                "test_patches": int(len(te_idx)),
                "val_frac": args.val_frac, "test_frac": args.test_frac,
                "seed": args.seed})
    print(f"✅ grouped splits written to {out}")


def mode_train(args):
    import torch
    import torch.nn as nn
    from common import (DualTaskModel, build_loaders, train_stats,
                        compute_class_weights, metrics_bundle, _predict)

    data_dir = args.grouped_data_dir or os.path.join(
        args.out_dir, args.tag, "data_grouped")
    device = get_device(prefer_cuda=not args.cpu)
    x_tr, ys_tr, yc_tr = load_split(data_dir, "train")
    mean, std = train_stats(x_tr)
    tr = build_loaders(data_dir, "train", mean, std, args.batch_size, True)
    va = build_loaders(data_dir, "val", mean, std, args.batch_size, False)
    te = build_loaders(data_dir, "test", mean, std, args.batch_size, False)
    _, ys_te, yc_te = load_split(data_dir, "test")

    records = []
    for seed in [int(s) for s in args.seeds.split(",") if s.strip()]:
        set_seed(seed)
        ws, wc = compute_class_weights(ys_tr, yc_tr, device)
        model = DualTaskModel(6, 2, 4).to(device)
        opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
        from torch.optim.lr_scheduler import CosineAnnealingLR
        sched = CosineAnnealingLR(opt, T_max=args.epochs, eta_min=1e-6)
        best, best_state = -1.0, None
        for ep in range(1, args.epochs + 1):
            model.train()
            for batch in tr:
                x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
                opt.zero_grad()
                os_, oc = model(x)
                loss = nn.CrossEntropyLoss(weight=ws)(os_, ys) + \
                    args.lambda_change * nn.CrossEntropyLoss(weight=wc)(oc, yc)
                loss.backward()
                opt.step()
            sched.step()
            model.eval()
            cs = cc = tv = 0
            with torch.no_grad():
                for batch in va:
                    x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
                    os_, oc = model(x)
                    cs += (os_.argmax(1) == ys).sum().item()
                    cc += (oc.argmax(1) == yc).sum().item()
                    tv += ys.numel()
            comb = (cs / tv + cc / tv) / 2
            if comb > best:
                best, best_state = comb, {k: v.detach().cpu().clone()
                                          for k, v in model.state_dict().items()}
            if ep % 5 == 0 or ep == 1 or ep == args.epochs:
                print(f"  [grouped seed{seed}] Ep {ep}/{args.epochs} | valS {cs/tv:.3f} | valC {cc/tv:.3f}")
        model.load_state_dict(best_state)
        ps, pc = _predict(model, te, device, True)
        m = metrics_bundle(ys_te, yc_te, ps, pc)
        rec = {"model": "DualTask-grouped", "seed": seed,
               "lambda_change": args.lambda_change, **m}
        records.append(rec)
        print(f"  seed{seed}: leakage-free static IoU={m['static']['iou_saline']:.4f} "
              f"acc={m['static']['accuracy']:.4f}")
    ious = [r["static"]["iou_saline"] for r in records]
    accs = [r["static"]["accuracy"] for r in records]
    out = {"records": records,
           "iou_saline_mean": float(np.mean(ious)),
           "iou_saline_std_ddof1": float(np.std(ious, ddof=1)) if len(ious) > 1 else 0.0,
           "accuracy_mean": float(np.mean(accs))}
    write_json(os.path.join(args.out_dir, args.tag, "grouped_train_results.json"), out)
    print(f"\n✅ leakage-free IoU = {out['iou_saline_mean']:.4f} "
          f"± {out['iou_saline_std_ddof1']:.4f}  (compare with the 0.803 original)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["audit", "split", "train"], required=True)
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expD_spatial")
    ap.add_argument("--coords", default=None, help="Nx2 lon/lat .npy (audit mode)")
    ap.add_argument("--groups", default=None, help="N int group ids (split mode)")
    ap.add_argument("--grouped-data-dir", default=None, help="for train mode")
    ap.add_argument("--val-frac", type=float, default=0.15)
    ap.add_argument("--test-frac", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--seeds", default="42,123,2024")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--lambda-change", type=float, default=1.0)
    ap.add_argument("--cpu", action="store_true")
    args = ap.parse_args()
    makedirs(os.path.join(args.out_dir, args.tag))
    {"audit": mode_audit, "split": mode_split, "train": mode_train}[args.mode](args)


if __name__ == "__main__":
    main()

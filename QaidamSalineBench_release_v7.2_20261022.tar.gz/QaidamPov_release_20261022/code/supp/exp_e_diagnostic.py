#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-E — lightweight difficulty diagnostic.

Question: on the REBUILT dataset the dual-task gain over single-task vanished
(paired ΔIoU ≈ 0, n.s.). Is it because the rebuilt problem is "too easy"
(models saturate ~0.90)? This re-runs the paired comparison on harder / rarer
subsets of the SAME robust data:

  all          : no filter (baseline)
  high_saline  : saline_frac >= 0.50        (mirror the paper's saline-heavy regime)
  balanced     : 0.20 <= saline_frac <= 0.80 (harder static task)
  change_rich  : (expansion+shrinkage) frac >= 0.02 (rarer change classes)

For each subset and config {single, dual λ=1.0, λ=0.5, λ=0.3}, train over the
same seeds (val-selection like the main pipeline) and report mean±std IoU plus
the paired ΔIoU vs single-task.

Output: <out>/expE_diagnostic/{TABLE_diagnostic.md, diag_results.json}

Usage:
  python exp_e_diagnostic.py --data-dir <.../processed_dual> \
      --out-dir <.../results/supplementary> --seeds 42,123,2024 --epochs 30
"""
from __future__ import annotations

import os
import sys
import json
import argparse

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from torch.optim.lr_scheduler import CosineAnnealingLR

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    DualTaskModel, SingleTaskModel, DualDataset, compute_class_weights,
    metrics_bundle, describe, ttest_rel, write_json, set_seed, get_device,
    makedirs, _predict, load_split, DEFAULT_DATA_DIR, DEFAULT_OUT_DIR,
)


def apply_filter(name, ys, yc):
    sal = (ys == 1).mean(axis=(1, 2))
    chg = ((yc == 2) | (yc == 3)).mean(axis=(1, 2))
    if name == "all":
        return np.ones(len(ys), bool)
    if name == "balanced":
        return (sal >= 0.20) & (sal <= 0.80)
    if name == "high_saline":
        return sal >= 0.50
    if name == "change_rich":
        return chg >= 0.02
    raise ValueError(name)


def train_eval(model_kind, lam, seed, tr, va, te, device, epochs, bs, lr):
    set_seed(seed)
    dual = (model_kind == "dual")
    xtr, ystr, yctr = tr
    xte, yste, ycte = te
    mean = xtr.mean(axis=(0, 2, 3)).astype(np.float32)
    std = (xtr.std(axis=(0, 2, 3)) + 1e-8).astype(np.float32)

    def norm(x):
        return (x - mean.reshape(1, -1, 1, 1)) / std.reshape(1, -1, 1, 1)

    tr_ld = DataLoader(DualDataset(xtr, ystr, yctr, mean=mean, std=std, augment=True),
                       batch_size=bs, shuffle=True, num_workers=2,
                       pin_memory=torch.cuda.is_available())
    te_ld = DataLoader(TensorDataset(torch.FloatTensor(norm(xte)),
                                     torch.LongTensor(yste), torch.LongTensor(ycte)),
                       batch_size=bs, shuffle=False, num_workers=2)
    if va is not None and len(va[0]) >= 4:
        va_ld = DataLoader(TensorDataset(torch.FloatTensor(norm(va[0])),
                                         torch.LongTensor(va[1]), torch.LongTensor(va[2])),
                           batch_size=bs, shuffle=False, num_workers=2)
    else:
        va_ld = None

    ws, wc = compute_class_weights(ystr, yctr, device)
    crit_s, crit_c = nn.CrossEntropyLoss(weight=ws), nn.CrossEntropyLoss(weight=wc)
    model = (DualTaskModel(xte.shape[1], 2, 4) if dual
             else SingleTaskModel(xte.shape[1], 2)).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-6)
    best, best_state = -1.0, None
    for ep in range(1, epochs + 1):
        model.train()
        for x, ys, yc in tr_ld:
            x, ys, yc = x.to(device), ys.to(device), yc.to(device)
            opt.zero_grad()
            out = model(x)
            loss = (crit_s(out[0], ys) + lam * crit_c(out[1], yc)) if dual else crit_s(out, ys)
            loss.backward()
            opt.step()
        sched.step()
        if va_ld is not None:
            model.eval()
            cs = cc = tv = 0
            with torch.no_grad():
                for x, ys, yc in va_ld:
                    x, ys, yc = x.to(device), ys.to(device), yc.to(device)
                    out = model(x)
                    if dual:
                        os_, oc = out
                        cc += (oc.argmax(1) == yc).sum().item()
                    else:
                        os_ = out
                    cs += (os_.argmax(1) == ys).sum().item()
                    tv += ys.numel()
            comb = (cs / tv + cc / tv) / 2 if dual else cs / tv
            if comb > best:
                best = comb
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    if best_state is None:
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    ps, pc = _predict(model, te_ld, device, dual)
    m = metrics_bundle(yste, ycte, ps, pc)
    return m["static"]["iou_saline"], m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expE_diagnostic")
    ap.add_argument("--seeds", default="42,123,2024")
    ap.add_argument("--filters", default="all,high_saline,balanced,change_rich")
    ap.add_argument("--lambdas", default="1.0,0.5,0.3")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--min-train", type=int, default=40)
    ap.add_argument("--cpu", action="store_true")
    args = ap.parse_args()

    device = get_device(prefer_cuda=not args.cpu)
    out_root = os.path.join(args.out_dir, args.tag)
    makedirs(out_root)
    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
    filters = [s for s in args.filters.split(",") if s.strip()]
    lambdas = [float(s) for s in args.lambdas.split(",") if s.strip()]

    tr_all = load_split(args.data_dir, "train")
    va_all = load_split(args.data_dir, "val")
    te_all = load_split(args.data_dir, "test")
    print(f"🖥️  device={device} | train {len(tr_all[0])} val {len(va_all[0])} "
          f"test {len(te_all[0])} | seeds={seeds}")

    results = {}
    for f in filters:
        mtr, mva, mte = (apply_filter(f, s[1], s[2]) for s in (tr_all, va_all, te_all))
        ntr, nva, nte = int(mtr.sum()), int(mva.sum()), int(mte.sum())
        print(f"\n=== filter '{f}': train {ntr}, val {nva}, test {nte} ===")
        if ntr < args.min_train or nte < 5:
            print("   ⚠️ too few patches -> skip")
            continue
        tr = (tr_all[0][mtr], tr_all[1][mtr], tr_all[2][mtr])
        va = (va_all[0][mva], va_all[1][mva], va_all[2][mva])
        te = (te_all[0][mte], te_all[1][mte], te_all[2][mte])
        block = {"n_train": ntr, "n_val": nva, "n_test": nte,
                 "test_saline_share": round(float((te[1] == 1).mean()), 4),
                 "single": [], "dual": {}}
        for s in seeds:
            iou, _ = train_eval("single", None, s, tr, va, te, device,
                                args.epochs, args.batch_size, args.lr)
            block["single"].append(iou)
            print(f"   [single ] seed{s}: IoU {iou:.4f}")
        for lam in lambdas:
            block["dual"][str(lam)] = []
            for s in seeds:
                iou, _ = train_eval("dual", lam, s, tr, va, te, device,
                                    args.epochs, args.batch_size, args.lr)
                block["dual"][str(lam)].append(iou)
                print(f"   [dual {lam}] seed{s}: IoU {iou:.4f}")
        results[f] = block
        write_json(os.path.join(out_root, "diag_results.json"), results)

    # ---- report ----
    L = ["# EXP-E — difficulty diagnostic (paired ΔIoU vs single-task)\n",
         "| filter | train/test | saline% | single IoU | dual λ=1.0 (p) | best λ | best ΔIoU (p) |",
         "|---|---|---:|---|---:|---|---|"]
    verdict = []
    for f, b in results.items():
        s_d = describe(b["single"])
        cells, best = {}, None
        for lam in [str(x) for x in lambdas]:
            tt = ttest_rel(np.array(b["dual"][lam]), np.array(b["single"]))
            cells[lam] = (describe(b["dual"][lam]), tt)
            if best is None or tt["mean_diff"] > cells[best][1]["mean_diff"]:
                best = lam
        d1, t1 = cells["1.0"]
        db, tb = cells[best]
        L.append(f"| {f} | {b['n_train']}/{b['n_test']} | {b['test_saline_share']*100:.1f} "
                 f"| {s_d['mean']:.4f} | {d1['mean']:.4f} (p={t1['p_value']:.3f}) "
                 f"| {best} | {tb['mean_diff']:+.4f} (p={tb['p_value']:.3f}) |")
        verdict.append((f, best, tb["mean_diff"], tb["p_value"]))
    L += ["", "## Verdict"]
    for f, best, d, p in verdict:
        L.append(f"- **{f}**: best λ={best}, ΔIoU={d:+.4f} "
                 f"({'SIGNIFICANT' if p < 0.05 else 'n.s.'}, p={p:.3f})")
    with open(os.path.join(out_root, "TABLE_diagnostic.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    print("\n" + "\n".join(L))
    print(f"\n✅ EXP-E done -> {out_root}/TABLE_diagnostic.md")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Offline self-test for EXP-H / EXP-I / EXP-J.

Runs on CPU, no network, synthetic data only, in well under two minutes.
It validates the *statistics* against brute force, not merely that the code runs.

  1. joint-cell algebra     : sum(cells) == N ; IoU == brute-force IoU
  2. McNemar exact p        : matches a direct math.comb computation
  3. bootstrap behaviour    : identical models -> ΔIoU == 0 and CI == [0, 0];
                              CI brackets the point estimate otherwise
  4. spatial cluster path   : per-tile table shape, unit count, CI sanity
  5. EXP-I single run       : 2 epochs on synthetic data, metric keys present
                              (requires torch — skipped with a notice if absent)
  6. EXP-J split report     : writes the composition json for synthetic groups

    python selftest_p1_extra.py
"""
from __future__ import annotations

import os
import sys
import json
import math
import shutil
import tempfile
import subprocess

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import paired_stats as PS  # noqa: E402

HAVE_TORCH = True
try:
    import torch  # noqa: F401
except Exception:
    HAVE_TORCH = False

PASS, FAIL, SKIP = [], [], []


def check(name, cond, extra=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'✅' if cond else '❌'} {name}" + (f"  {extra}" if extra else ""))


def skip(name, why):
    SKIP.append(name)
    print(f"  ⏭️  {name}  (skipped: {why})")


def brute_iou(y, p):
    y = y.ravel() > 0
    p = p.ravel() > 0
    tp = np.sum(y & p); fp = np.sum(~y & p); fn = np.sum(y & ~p)
    return tp / (tp + fp + fn)


def synth(n=(12, 4, 6), seed=7):
    """Build a tiny but correctly-shaped/typed dataset + tile ids, torch-free."""
    rng = np.random.RandomState(seed)
    d = {}
    for name, k in (("train", n[0]), ("val", n[1]), ("test", n[2])):
        x = rng.rand(k, 6, 128, 128).astype(np.float32)
        ys = (x[:, 0] > 0.5).astype(np.int64)
        yc = np.zeros((k, 128, 128), dtype=np.int64)
        yc[x[:, 1] > 0.60] = 1
        yc[x[:, 2] > 0.92] = 2
        yc[x[:, 3] > 0.92] = 3
        d[name] = (x, ys, yc)
    return d


def write_synth(out_dir, d):
    os.makedirs(out_dir, exist_ok=True)
    for name, (x, ys, yc) in d.items():
        np.save(os.path.join(out_dir, f"{name}_x.npy"), x)
        np.save(os.path.join(out_dir, f"{name}_y_static.npy"), ys)
        np.save(os.path.join(out_dir, f"{name}_y_change.npy"), yc)
    return out_dir


def main():
    tmp = tempfile.mkdtemp(prefix="p1_selftest_")
    print(f"[env] tmp = {tmp}")
    print(f"[env] torch available = {HAVE_TORCH}")
    try:
        d = synth()
        n_tr, n_va, n_te = 12, 4, 6
        data = write_synth(os.path.join(tmp, "data"), d)
        groups = np.concatenate([np.repeat(np.arange(0, 6), 2),      # train
                                 np.repeat(np.arange(6, 8), 2),      # val
                                 np.repeat(np.arange(8, 11), 2)])    # test
        np.save(os.path.join(data, "patch_tiles.npy"), groups.astype(np.int64))

        y_te = d["test"][1]
        g_te = groups[n_tr + n_va:]
        rng = np.random.default_rng(0)

        # ---------------- 1. cell algebra --------------------------------
        print("\n[1] joint-cell algebra")
        pA = (rng.random(y_te.shape) > 0.4).astype(np.uint8)
        pB = (rng.random(y_te.shape) > 0.4).astype(np.uint8)
        cells = PS.build_cells([pA, pB], y_te)
        check("sum(cells) == N", abs(cells.sum() - y_te.size) < 1e-6,
              f"{int(cells.sum())} vs {y_te.size}")
        check("cells length == 2^(k+1)", len(cells) == 8, str(len(cells)))
        iouA = float(PS.iou_saline(cells.reshape(1, -1), 2, 0)[0])
        check("IoU(A) == brute force", abs(iouA - brute_iou(y_te, pA)) < 1e-9,
              f"{iouA:.6f}")
        iouB = float(PS.iou_saline(cells.reshape(1, -1), 2, 1)[0])
        check("IoU(B) == brute force", abs(iouB - brute_iou(y_te, pB)) < 1e-9)
        accA = float(PS.accuracy(cells.reshape(1, -1), 2, 0)[0])
        check("accuracy(A) == brute force",
              abs(accA - float((pA == y_te).mean())) < 1e-9, f"{accA:.6f}")

        # ---------------- 2. McNemar exact -------------------------------
        print("\n[2] McNemar exact p")
        m01, m10 = 12, 28
        pcode, method = PS.mcnemar_p(m01, m10)
        n = m01 + m10
        lo = min(m01, m10)
        ref = min(1.0, 2.0 * sum(math.comb(n, k) for k in range(lo + 1)) / (2 ** n))
        check("exact p matches math.comb", abs(pcode - ref) < 1e-12,
              f"{pcode:.10f} vs {ref:.10f} ({method})")
        p0, _ = PS.mcnemar_p(0, 0)
        check("degenerate (no discordant pairs) -> p = 1", p0 == 1.0)
        pbig, meth = PS.mcnemar_p(100000, 101000)
        check("huge m falls back to normal approx",
              "normal" in meth and 0.0 <= pbig <= 1.0, f"{pbig:.4g} via {meth}")

        # cell-based and prediction-based discordant counts must agree (binary)
        cb = PS.mcnemar_counts(PS.build_cells([pA, pB], y_te), 2)
        cp = PS.mcnemar_from_preds(y_te, pA, pB)
        check("mcnemar cell-path == pred-path (binary)",
              cp[0] == int(cb[0]) and cp[1] == int(cb[1]), f"{cp} vs ({cb[0]:.0f},{cb[1]:.0f})")
        # 4-class path must work too (this is where a cell encoding would overflow)
        yc_te = d["test"][2]
        q1 = ((yc_te + (rng.random(yc_te.shape) < 0.2)) % 4).astype(np.uint8)
        q2 = ((yc_te + (rng.random(yc_te.shape) < 0.3)) % 4).astype(np.uint8)
        cp4 = PS.mcnemar_from_preds(yc_te, q1, q2)
        check("mcnemar works on 4-class labels", cp4[0] >= 0 and cp4[1] >= 0, str(cp4))

        # ---------------- 3. bootstrap behaviour -------------------------
        print("\n[3] bootstrap behaviour")
        same = PS.analyse_pair(y_te, [pA, pA.copy()], g_te, (0, 1), ["A", "A2"], rng,
                               300, "identical")
        check("identical models -> ΔIoU == 0",
              abs(same["iou"]["delta_A_minus_B"]) < 1e-12)
        ci = same["bootstrap_pixel"]["ci95_delta_iou"]
        check("identical models -> CI == [0, 0]",
              abs(ci[0]) < 1e-12 and abs(ci[1]) < 1e-12, f"[{ci[0]:.2e},{ci[1]:.2e}]")

        dif = PS.analyse_pair(y_te, [pA, pB], g_te, (0, 1), ["A", "B"], rng, 500, "diff")
        check("analyse_pair emits McNemar",
              dif["mcnemar"] is not None and "p_value" in dif["mcnemar"],
              (f"p={dif['mcnemar']['p_value']:.4g}" if dif["mcnemar"] else "missing"))
        dd = dif["iou"]["delta_A_minus_B"]
        pc = dif["bootstrap_pixel"]["ci95_delta_iou"]
        check("pixel-boot CI brackets ΔIoU", pc[0] <= dd <= pc[1],
              f"Δ={dd:+.4f} CI=[{pc[0]:+.4f},{pc[1]:+.4f}]")
        check("ΔIoU sign matches direct IoU difference",
              abs((dif["iou"]["A"] - dif["iou"]["B"]) - dd) < 1e-12)

        # ---------------- 4. spatial cluster path ------------------------
        print("\n[4] spatial cluster bootstrap")
        cl = dif["bootstrap_cluster"]
        check("cluster bootstrap present", cl is not None)
        if cl:
            check("cluster units == unique tiles in test",
                  cl["n_units"] == len(np.unique(g_te)), f"{cl['n_units']}")
            check("per-tile deltas count == n_units",
                  len(cl["per_unit_delta"]) == cl["n_units"])
            check("per-tile mean == mean of the per-tile deltas",
                  abs(cl["per_unit_delta_mean"]
                      - float(np.mean(cl["per_unit_delta"]))) < 1e-12)
            check("per-tile mean is *close* to the pooled ΔIoU "
                  "(mean-of-ratios != ratio-of-sums, so only approximate)",
                  abs(cl["per_unit_delta_mean"] - dd) < 0.05,
                  f"tile-mean {cl['per_unit_delta_mean']:+.4f} vs pooled {dd:+.4f}")
            ct = cl["ci95_delta_iou"]
            check("cluster CI is finite and ordered", ct[0] <= ct[1],
                  f"[{ct[0]:+.4f},{ct[1]:+.4f}]")
        bad = PS.analyse_pair(y_te[:3], [pA[:3], pB[:3]], g_te[:3], (0, 1),
                              ["A", "B"], rng, 50, "tiny")
        check("tiny sample still runs (1 unit)", bad["bootstrap_cluster"] is not None)

        # ---------------- 5. EXP-I single short run ----------------------
        print("\n[5] EXP-I single short run (2 epochs, CPU)")
        if not HAVE_TORCH:
            skip("EXP-I short run", "torch not installed in this environment")
        else:
            import exp_i_change_head_loss as I
            r = I.train_one("focal_g2_bal", 0, data, "cpu", epochs=2, lr=1e-3,
                            lambda_change=1.0, batch_size=4, num_workers=0)
            for k in ("static", "change", "config", "seed"):
                check(f"EXP-I result has '{k}'", k in r)
            check("EXP-I per-class F1 has 4 entries",
                  len(r["change"]["f1_per_class"]) == 4)
            check("EXP-I static IoU finite", np.isfinite(r["static"]["iou_saline"]))
            check("EXP-I change macro-F1 finite", np.isfinite(r["change"]["f1_macro"]))
            check("EXP-I 'ce' criterion builds",
                  I.build_change_criterion("ce", y_te, "cpu")[0] is not None)
            fl = I.FocalLoss(gamma=2.0)
            lg = torch.zeros(1, 4, 4, 4); lg[:, 1] = 50.0
            tg = torch.ones(1, 4, 4, dtype=torch.long)
            lv = float(fl(lg, tg))
            check("focal loss ≈ 0 on confident-correct", lv < 1e-6, f"{lv:.2e}")
            lw = float(fl(torch.zeros(1, 4, 4, 4), tg))
            check("focal loss > 0 on uniform-wrong", lw > 0, f"{lw:.4f}")

        # ---------------- 6. EXP-J split report --------------------------
        print("\n[6] EXP-J split report")
        out = os.path.join(tmp, "out")
        cp = subprocess.run(
            [sys.executable, os.path.join(HERE, "exp_j_split_report.py"),
             "--data-dir", data, "--out-dir", out, "--tag", "expJ_split"],
            capture_output=True, text=True)
        check("EXP-J exits 0", cp.returncode == 0, cp.stderr.strip()[:200])
        jf = os.path.join(out, "expJ_split", "split_composition.json")
        check("EXP-J writes split_composition.json", os.path.exists(jf))
        if os.path.exists(jf):
            rep = json.load(open(jf))
            check("EXP-J counts tiles per split",
                  rep["splits"]["test"]["n_tiles"] == len(np.unique(g_te)),
                  f"test tiles = {rep['splits']['test']['n_tiles']}")
            check("EXP-J leakage audit finds no straddling tiles",
                  rep["leakage_free_ok"] is True)

    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n" + "=" * 66)
    print(f"PASSED {len(PASS)}  |  FAILED {len(FAIL)}  |  SKIPPED {len(SKIP)}")
    if FAIL:
        print("failed checks:")
        for f in FAIL:
            print("   ❌", f)
        print("\n❌ SELFTEST FAILED")
        return 1
    if SKIP:
        print("note: torch-dependent checks were skipped — they WILL run on the server")
    print("✅ SELFTEST PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env bash
# ============================================================================
#  run_common_test.sh — 同测试集、换划分的完整复评流程
#
#  设计：固定唯一评测集 E = tile 级 test 的 66 个 patch（来自留出瓦片），
#        再把 E 拆成 E_seen（也在 patch 级训练集里）/ E_unseen（不在），
#        于是得到三个互不混淆的量：
#            Δ_mem   = IoU(E_seen) − IoU(E_unseen)   同一模型、同一像素
#            Δ_cover = patch 模型(E_unseen) vs tile 模型(E)
#            Δ_arch  = 上面两者随模型家族的变化
#
#  用法：bash run_common_test.sh            全流程（约 10–15 分钟）
#        bash run_common_test.sh index      只建索引（秒级）
#        bash run_common_test.sh cnn        只跑深度模型推理（约 3 分钟）
#        bash run_common_test.sh rf         只跑像素基线（约 8 分钟）
#        bash run_common_test.sh report     只汇总
# ============================================================================
set -uo pipefail

PROJECT="${PROJECT_DIR:-/root/autodl-tmp/QaidamPov}"
PY="${PY:-python}"
OUT="$PROJECT/results/supplementary/common_test"
EVALS="$OUT/evals"

# --- 目录自动解析（避免路径写死导致 FileNotFound） ---
pick_dir() { for c in "$@"; do [ -d "$c" ] && { echo "$c"; return 0; }; done; return 1; }

PATCH_DIR="$(pick_dir "$PROJECT/data/data_geoaux" \
                      "$PROJECT/results/supplementary/data_geoaux" \
                      "$PROJECT/data/geoaux")" || {
  echo "[fatal] 找不到 patch 级 geoaux 数据目录（data/data_geoaux）"; exit 1; }

EVAL_DIR="$(pick_dir "$PROJECT/data/data_grouped_geoaux" \
                      "$PROJECT/results/supplementary/expD_spatial/data_grouped_geoaux" \
                      "$PROJECT/data/processed_grouped_geoaux")" || {
  echo "[fatal] 找不到 tile 级 geoaux 数据目录；先跑 exp_m_clean_aux.py 指向 data_grouped"
  exit 1; }

echo "[paths] PATCH_DIR = $PATCH_DIR"
echo "[paths] EVAL_DIR  = $EVAL_DIR"
for d in "$PATCH_DIR" "$EVAL_DIR"; do
  [ -f "$d/test_x.npy" ] || { echo "[fatal] $d 缺 test_x.npy"; exit 1; }
done
CKPT_PATCH="$PROJECT/results/supplementary/expA_geoaux8/ckpts"
CKPT_TILE="$PROJECT/results/supplementary/expA_geoaux_grouped8/ckpts"
SEEDS="${SEEDS:-42 123 2024 7 13 99 777 2025}"

mkdir -p "$OUT" "$EVALS"

do_index() {
  echo "=== [index] 建立 patch 指纹与 E 的 seen/unseen 标记 ==="
  $PY "$PROJECT/supp/exp_p_common_test.py" index \
      --patch-dir "$PATCH_DIR" --eval-dir "$EVAL_DIR" --out "$OUT" || exit 1
  echo
  echo "!! 请先看上一段的 [E] 行：seen 与 unseen 都必须是正数。"
  echo "!! 若 unseen 过少（<10 个 patch），E_seen/E_unseen 的对比就不稳，"
  echo "!! 此时只需报告 IoU(E) 与 Δ_mem 的点估计，不要做区间推断。"
}

do_cnn() {
  local ok=0 skip=0
  for S in $SEEDS; do
    for ROLE in patch tile; do
      if [ "$ROLE" = "patch" ]; then
        CKD="$CKPT_PATCH"; ST="$PATCH_DIR"
      else
        CKD="$CKPT_TILE";  ST="$EVAL_DIR"
      fi
      for CFG in "dual 1.0" "single -"; do
        set -- $CFG; MOD=$1; LAM=$2
        if [ "$MOD" = "dual" ]; then
          F="$CKD/dual_seed${S}_lam${LAM}.pth"; NM="dual_seed${S}_lam${LAM}"
        else
          F="$CKD/single_seed${S}.pth";         NM="single_seed${S}"
        fi
        if [ ! -f "$F" ]; then
          echo "[skip] 缺 ckpt: $F"; skip=$((skip+1)); continue
        fi
        $PY "$PROJECT/supp/exp_q_common_eval.py" --mode cnn --model "$MOD" \
            --ckpt "$F" --stats-dir "$ST" --eval-dir "$EVAL_DIR" \
            --out "$EVALS" --name "${ROLE}_${NM}" \
            --family conv --protocol "$ROLE" || echo "[warn] 失败: $NM ($ROLE)"
        ok=$((ok+1))
      done
    done
  done
  echo "=== [cnn] 完成 $ok 个，跳过 $skip 个"
}

do_rf() {
  for ROLE in patch tile; do
    if [ "$ROLE" = "patch" ]; then TR="$PATCH_DIR"; else TR="$EVAL_DIR"; fi
    for CLF in rf xgb; do
      for FT in full bands6; do
        $PY "$PROJECT/supp/exp_q_common_eval.py" --mode rf --classifier "$CLF" \
            --features "$FT" --seed 42 --train-dir "$TR" --eval-dir "$EVAL_DIR" \
            --out "$EVALS" --name "${CLF}_${FT}_${ROLE}" \
            --family pixel --protocol "$ROLE" || echo "[warn] 失败: ${CLF}_${FT}_${ROLE}"
      done
    done
  done
}

do_report() {
  echo "=== [report] 汇总 ==="
  $PY "$PROJECT/supp/exp_p_common_test.py" report \
      --index "$OUT/common_index.json" --eval-out "$EVALS" --out "$OUT"
  echo
  echo "=== 关键读数 ==="
  echo "Δ_mem  ：同一模型在 E_seen 与 E_unseen 上的 IoU 差（记忆化膨胀的直接度量）"
  echo "Δ_cover：patch 模型在 E_unseen 上  vs  tile 模型在 E 上（训练覆盖度的效应）"
  echo "若 Δ_mem 大而 Δ_cover 小 → 两协议差距几乎全部来自记忆化，而非训练数据多寡。"
}

case "${1:-all}" in
  index)  do_index ;;
  cnn)    do_cnn ;;
  rf)     do_rf ;;
  report) do_report ;;
  all)    do_index; echo; do_cnn; echo; do_rf; echo; do_report ;;
  *) echo "usage: bash run_common_test.sh {index|cnn|rf|report|all}"; exit 2 ;;
esac

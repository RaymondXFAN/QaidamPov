#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-C — U-Net segmentation baseline.

Why this exists
---------------
The only competing learners in the manuscript are Random Forest, XGBoost and a
"vanilla CNN" that the authors themselves call "intentionally minimalistic".
A reviewer's standard reaction is: does the dual-task idea still hold against a
*segmentation practice standard*? This adds a standard 4-level U-Net, trained on
the identical splits with the identical protocol, so the baseline row can be
defensible.

Modes
    --mode single   U-Net with a static head only (single-task segmentation baseline)
    --mode dual     U-Net with static+change heads (checks whether the dual-task
                    benefit is specific to the shallow CNN or general)

Outputs (in --out-dir/<tag>/)
    runs/unet_{mode}_seed{S}.json
    ckpts/unet_{mode}_seed{S}.pth
    unet_summary.json / TABLE_unet.md
"""
from __future__ import annotations

import os
import sys
import argparse
import time

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    UNet, build_loaders, load_split, train_stats, compute_class_weights,
    metrics_bundle, describe, write_json, set_seed, get_device, makedirs,
    _predict, DEFAULT_DATA_DIR, DEFAULT_OUT_DIR,
)


def train_eval(mode, seed, args, device, out_root):
    set_seed(seed)
    dual = (mode == "dual")
    tag = f"unet_{mode}_seed{seed}"

    x_tr, ys_tr, yc_tr = load_split(args.data_dir, "train")
    mean, std = train_stats(x_tr)
    tr = build_loaders(args.data_dir, "train", mean, std, args.batch_size, True)
    va = build_loaders(args.data_dir, "val", mean, std, args.batch_size, False)
    te = build_loaders(args.data_dir, "test", mean, std, args.batch_size, False)
    _, ys_te, yc_te = load_split(args.data_dir, "test")

    ws, wc = compute_class_weights(ys_tr, yc_tr, device)
    crit_s = nn.CrossEntropyLoss(weight=ws)
    crit_c = nn.CrossEntropyLoss(weight=wc)

    model = UNet(in_channels=x_tr.shape[1], num_classes=2, num_change_classes=4,
                 base=args.base, dual=dual).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"\n{'='*64}\n[{tag}] params={n_params:,} epochs={args.epochs}\n{'='*64}")

    from torch.optim.lr_scheduler import CosineAnnealingLR
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    sched = CosineAnnealingLR(opt, T_max=args.epochs, eta_min=1e-6)
    best, best_state = -1.0, None
    t0 = time.time()
    for epoch in range(1, args.epochs + 1):
        model.train()
        ls, n = 0.0, 0
        for batch in tr:
            x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
            opt.zero_grad()
            out = model(x)
            if dual:
                os_, oc = out
                loss = crit_s(os_, ys) + args.lambda_change * crit_c(oc, yc)
            else:
                loss = crit_s(out, ys)
            loss.backward()
            opt.step()
            ls += loss.item() * x.size(0)
            n += x.size(0)
        sched.step()
        model.eval()
        cs = cc = tv = 0
        with torch.no_grad():
            for batch in va:
                x, ys, yc = batch[0].to(device), batch[1].to(device), batch[2].to(device)
                out = model(x)
                if dual:
                    os_, oc = out
                    cc += (oc.argmax(1) == yc).sum().item()
                else:
                    os_ = out
                cs += (os_.argmax(1) == ys).sum().item()
                tv += ys.numel()
        vas = cs / tv
        vac = (cc / tv) if dual else 0.0
        comb = (vas + vac) / 2 if dual else vas
        if comb > best:
            best, best_state = comb, {k: v.detach().cpu().clone()
                                      for k, v in model.state_dict().items()}
        if epoch % 5 == 0 or epoch == 1 or epoch == args.epochs:
            print(f"  [{tag}] Ep {epoch:2d}/{args.epochs} | Loss {ls/max(n,1):.4f} "
                  f"| ValS {vas:.3f}" + (f" | ValC {vac:.3f}" if dual else ""))
    dt = time.time() - t0

    model.load_state_dict(best_state)
    pred_s, pred_c = _predict(model, te, device, dual)
    m = metrics_bundle(ys_te, yc_te, pred_s, pred_c)
    rec = {"model": f"UNet-{mode}", "seed": int(seed), "params": int(n_params),
           "lambda_change": args.lambda_change if dual else None,
           "train_seconds": round(dt, 2), **m}
    makedirs(os.path.join(out_root, "runs"), os.path.join(out_root, "ckpts"))
    write_json(os.path.join(out_root, "runs", tag + ".json"), rec)
    torch.save({"model_state_dict": best_state, "tag": tag, "mode": mode,
                "seed": int(seed)}, os.path.join(out_root, "ckpts", tag + ".pth"))
    print(f"[{tag}] static IoU={m['static']['iou_saline']:.4f} "
          f"acc={m['static']['accuracy']:.4f} f1m={m['static']['f1_macro']:.4f}")
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR)
    ap.add_argument("--tag", default="expC_unet")
    ap.add_argument("--mode", choices=["single", "dual", "both"], default="single")
    ap.add_argument("--seeds", default="42,123,2024")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--base", type=int, default=32)
    ap.add_argument("--lambda-change", type=float, default=1.0)
    ap.add_argument("--cpu", action="store_true")
    args = ap.parse_args()

    device = get_device(prefer_cuda=not args.cpu)
    out_root = os.path.join(args.out_dir, args.tag)
    makedirs(out_root)
    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
    modes = ["single", "dual"] if args.mode == "both" else [args.mode]

    recs = []
    for mode in modes:
        for s in seeds:
            recs.append(train_eval(mode, s, args, device, out_root))

    summary = {}
    for mode in modes:
        rs = [r for r in recs if r["model"] == f"UNet-{mode}"]
        summary[f"UNet-{mode}"] = {
            "n": len(rs),
            "static_acc": describe([r["static"]["accuracy"] for r in rs]),
            "iou_saline": describe([r["static"]["iou_saline"] for r in rs]),
            "f1_weighted": describe([r["static"]["f1_weighted"] for r in rs]),
            "f1_macro": describe([r["static"]["f1_macro"] for r in rs]),
            "kappa": describe([r["static"]["kappa"] for r in rs]),
            "change_f1_macro": describe([r["change"]["f1_macro"] for r in rs])
            if rs and "change" in rs[0] else describe([float("nan")] * len(rs)),
        }
    write_json(os.path.join(out_root, "unet_summary.json"),
               {"summary": summary, "raw": recs})

    L = ["# EXP-C — U-Net baseline (ddof=1)\n",
         "| model | n | Accuracy | IoU(saline) | F1-weighted | F1-macro | kappa | Change F1-macro |",
         "|---|---:|---|---|---|---|---|---|"]
    for k, v in summary.items():
        L.append(f"| {k} | {v['n']} | {v['static_acc']['mean']:.4f}±{v['static_acc']['std_ddof1']:.4f} "
                 f"| {v['iou_saline']['mean']:.4f}±{v['iou_saline']['std_ddof1']:.4f} "
                 f"| {v['f1_weighted']['mean']:.4f}±{v['f1_weighted']['std_ddof1']:.4f} "
                 f"| {v['f1_macro']['mean']:.4f}±{v['f1_macro']['std_ddof1']:.4f} "
                 f"| {v['kappa']['mean']:.4f}±{v['kappa']['std_ddof1']:.4f} "
                 f"| {v['change_f1_macro']['mean']:.4f}±{v['change_f1_macro']['std_ddof1']:.4f} |")
    with open(os.path.join(out_root, "TABLE_unet.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print(f"\n✅ EXP-C done. See {out_root}/TABLE_unet.md")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exp_q_common_eval.py — 在**同一个评测集 E** 上跑推理，输出逐 patch 混淆计数

配套 exp_p_common_test.py 使用：先 index，再用本脚本对每个模型/种子推理，
最后 report 汇总。核心产出是 per_patch 的 tp/fp/fn（saline 类），
这样汇总时才能把 E 拆成 E_seen / E_unseen。

用法（GPU）
----------
# 0) 先做一次快速体检（10 秒，不加载模型）
python exp_q_common_eval.py --dry-run --eval-dir <DATA_GROUPED>

# 1) 深度学习模型（每个种子一个 ckpt）
python exp_q_common_eval.py --mode cnn --model dual --seed 42 --lam 1.0 \
    --ckpt <.../ckpts/dual_seed42_lam1.0.pth> \
    --stats-dir <processed_dual> \
    --eval-dir <DATA_GROUPED> --index <common_index.json> \
    --out <common_test/evals> --name dual_seed42_lam1.0 --family conv --protocol patch

# 2) 像素级基线（现训现测，确定性）
python exp_q_common_eval.py --mode rf --features full --seed 42 \
    --train-dir <processed_dual> \
    --eval-dir <DATA_GROUPED> --index <common_index.json> \
    --out <common_test/evals> --name rf_idx_patch --family pixel --protocol patch

# 3) U-Net（若 ckpt 存在）
python exp_q_common_eval.py --mode cnn --model unet --seed 42 \
    --ckpt <.../ckpts/unet_seed42.pth> --stats-dir <processed_dual> ... （同上）

注意
----
* CNN 的归一化统计必须用**它自己训练时那一套**（--stats-dir 指向训练数据目录），
  否则推理分布错位，IoU 会莫名偏低。
* 本脚本只做推理，不改任何训练产物。
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exp_p_common_test import md5_of  # noqa: E402


# ------------------------------------------------------------------ counting
def counts(pred, gt):
    pred = np.asarray(pred).astype(np.int64)
    gt = np.asarray(gt).astype(np.int64)
    return {"tp": int(((pred == 1) & (gt == 1)).sum()),
            "fp": int(((pred == 1) & (gt == 0)).sum()),
            "fn": int(((pred == 0) & (gt == 1)).sum())}


def write_out(args, per_patch):
    d = os.path.join(args.out, args.protocol)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, f"{args.name}.json")
    json.dump({"name": args.name, "family": args.family, "protocol": args.protocol,
               "eval_dir": os.path.abspath(args.eval_dir),
               "n_patches": len(per_patch), "per_patch": per_patch},
              open(p, "w", encoding="utf-8"), indent=1)
    agg = {k: sum(x[k] for x in per_patch) for k in ("tp", "fp", "fn")}
    iou = agg["tp"] / max(1, agg["tp"] + agg["fp"] + agg["fn"])
    print(f"[write] {p}")
    print(f"[iou ] {args.name}: {iou:.4f} (E, all {len(per_patch)} patches)")


# -------------------------------------------------------------------- models
def predict_cnn(args):
    import torch
    from common import DualTaskModel, SingleTaskModel, UNet, load_split, train_stats

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    mean, std = train_stats(load_split(args.stats_dir, "train")[0])
    mean = np.asarray(mean, np.float32).reshape(1, -1, 1, 1)
    std = np.asarray(std, np.float32).reshape(1, -1, 1, 1)

    if args.model == "dual":
        model = DualTaskModel()
    elif args.model == "single":
        model = SingleTaskModel()
    else:
        try:
            model = UNet(in_ch=6, num_classes=2)
        except TypeError:
            model = UNet()

    ckpt = torch.load(args.ckpt, map_location="cpu")
    if isinstance(ckpt, dict):
        for k in ("model", "model_state_dict", "state_dict"):
            if k in ckpt and isinstance(ckpt[k], dict):
                ckpt = ckpt[k]
                break
    missing, unexpected = model.load_state_dict(ckpt, strict=False)
    if missing or unexpected:
        print(f"[warn] missing={len(missing)} unexpected={len(unexpected)} "
              f"(前3个: {list(missing)[:3]} / {list(unexpected)[:3]})")
    model.to(device).eval()

    x = np.load(os.path.join(args.eval_dir, "test_x.npy"), mmap_mode="r")
    y = np.load(os.path.join(args.eval_dir, "test_y_static.npy"), mmap_mode="r")
    per_patch = []
    with torch.no_grad():
        for i in range(len(x)):
            xi = np.asarray(x[i], np.float32)[None]
            xi = (xi - mean) / std
            t = torch.from_numpy(xi).to(device)
            out = model(t)
            logits = out[0] if isinstance(out, (tuple, list)) else out
            pred = logits.argmax(1).cpu().numpy()[0]
            c = counts(pred, np.asarray(y[i]))
            c["md5"] = md5_of(np.asarray(x[i], np.float32))
            per_patch.append(c)
            if (i + 1) % 20 == 0:
                print(f"  ... {i + 1}/{len(x)}", flush=True)
    return per_patch


def predict_rf(args):
    from sklearn.ensemble import RandomForestClassifier
    try:
        from xgboost import XGBClassifier
    except ImportError:
        XGBClassifier = None

    x_tr = np.load(os.path.join(args.train_dir, "train_x.npy"), mmap_mode="r")
    y_tr = np.load(os.path.join(args.train_dir, "train_y_static.npy"), mmap_mode="r")
    n, c = len(x_tr), x_tr.shape[1]
    Xtr = np.asarray(x_tr, np.float32).transpose(0, 2, 3, 1).reshape(-1, c)
    Ytr = np.asarray(y_tr).reshape(-1)
    rng = np.random.RandomState(args.seed)
    if args.max_train_pixels and args.max_train_pixels < len(Xtr):
        sel = []
        for cls in np.unique(Ytr):
            idx = np.flatnonzero(Ytr == cls)
            k = max(1, int(len(idx) / len(Ytr) * args.max_train_pixels))
            sel.append(rng.choice(idx, size=min(k, len(idx)), replace=False))
        sel = np.sort(np.concatenate(sel))
        Xtr, Ytr = Xtr[sel], Ytr[sel]
    print(f"[rf] train pixels {len(Ytr):,} | features {args.features}")

    Xtr, names = add_features(Xtr, args.features)
    if args.classifier == "xgb":
        if XGBClassifier is None:
            raise SystemExit("[fatal] 未安装 xgboost")
        clf = XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.1,
                            subsample=0.8, colsample_bytree=0.8,
                            eval_metric="logloss", n_jobs=8, random_state=args.seed)
    else:
        clf = RandomForestClassifier(n_estimators=300, n_jobs=8, random_state=args.seed)
    clf.fit(Xtr, Ytr)

    x = np.load(os.path.join(args.eval_dir, "test_x.npy"), mmap_mode="r")
    y = np.load(os.path.join(args.eval_dir, "test_y_static.npy"), mmap_mode="r")
    per_patch = []
    for i in range(len(x)):
        a = np.asarray(x[i], np.float32)
        Xi, _ = add_features(a.transpose(1, 2, 0).reshape(-1, c), args.features)
        pred = clf.predict(Xi).reshape(a.shape[1], a.shape[2])
        c_ = counts(pred, np.asarray(y[i]))
        c_["md5"] = md5_of(a)
        per_patch.append(c_)
    print(f"[rf] feature order: {names}")
    return per_patch


def add_features(X, mode):
    """X: (n, 6) = B02,B03,B04,B08,B11,B12"""
    if mode == "bands6":
        return X, ["b0", "b1", "b2", "b3", "b4", "b5"]
    eps = 1e-6
    blue, green, red, nir, swir1, swir2 = [X[:, i] for i in range(6)]
    ndvi = (nir - red) / (nir + red + eps)
    ndwi = (green - nir) / (green + nir + eps)
    si = (blue - red) / (blue + red + eps)
    return (np.column_stack([X, ndvi, ndwi, si]),
            ["b0", "b1", "b2", "b3", "b4", "b5", "ndvi", "ndwi", "si"])


# ---------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["cnn", "rf"], default="cnn")
    ap.add_argument("--model", choices=["dual", "single", "unet"], default="dual")
    ap.add_argument("--classifier", choices=["rf", "xgb"], default="rf")
    ap.add_argument("--features", choices=["full", "bands6"], default="full")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--lam", default="1.0")
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--stats-dir", default=None)
    ap.add_argument("--train-dir", default=None)
    ap.add_argument("--eval-dir", required=True)
    ap.add_argument("--index", default=None)
    ap.add_argument("--out", default="./common_test/evals")
    ap.add_argument("--name", default=None)
    ap.add_argument("--family", default="conv")
    ap.add_argument("--protocol", default="patch")
    ap.add_argument("--max-train-pixels", type=int, default=800_000)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if args.name is None:
        args.name = (f"{args.model}_seed{args.seed}_lam{args.lam}" if args.mode == "cnn"
                     else f"{args.classifier}_{args.features}_seed{args.seed}")

    if args.dry_run:
        x = np.load(os.path.join(args.eval_dir, "test_x.npy"), mmap_mode="r")
        y = np.load(os.path.join(args.eval_dir, "test_y_static.npy"), mmap_mode="r")
        print(f"[ok] eval-dir test_x {x.shape} | test_y {y.shape} | saline "
              f"{float(np.asarray(y).mean()):.3f}")
        if args.index:
            idx = json.load(open(args.index, encoding="utf-8"))
            print(f"[ok] index: E={idx['n_eval_test']} seen={idx['n_seen']} "
                  f"unseen={idx['n_unseen']}")
        return

    per_patch = predict_cnn(args) if args.mode == "cnn" else predict_rf(args)
    write_out(args, per_patch)


if __name__ == "__main__":
    main()

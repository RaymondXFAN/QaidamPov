#!/usr/bin/env bash
# ============================================================================
#  run_ablation_all.sh — 四族受控消融总控（EXP-U）
#
#  目的：把 EXP-T（U-Net）的受控消融扩到 CNN / 像素基线 / Prithvi，
#        使"泄漏惩罚随架构变化"从描述性升级为因果性。
#
#  用法：
#    bash run_ablation_all.sh gate       # 闸门：1 种子 1 epoch，验证能跑通（约 3 分钟）
#    bash run_ablation_all.sh all        # 全流程（cnn → pixel → prithvi → compare）
#    bash run_ablation_all.sh cnn
#    bash run_ablation_all.sh pixel
#    bash run_ablation_all.sh prithvi
#    bash run_ablation_all.sh compare
#    bash run_ablation_all.sh status     # 非阻塞看进度
#
#  后台跑：
#    nohup bash run_ablation_all.sh all > /root/autodl-tmp/QaidamPov/logs/ablation_all.log 2>&1 &
# ============================================================================
set -uo pipefail

PROJECT="${PROJECT_DIR:-/root/autodl-tmp/QaidamPov}"
PY="${PY:-python}"
OUT="$PROJECT/results/supplementary/expU_ablation"
LOGS="$PROJECT/logs"
IDX="$PROJECT/results/supplementary/common_test/common_index.json"
SCRIPT="$PROJECT/supp/exp_u_ablation_all.py"

mkdir -p "$OUT" "$LOGS"

banner() { echo; echo "==================== $* ===================="; date '+%F %T'; }

# ---- 前置检查 -------------------------------------------------------------
preflight() {
  [ -f "$SCRIPT" ]  || { echo "[fatal] 缺 $SCRIPT"; exit 1; }
  [ -f "$IDX" ]     || { echo "[fatal] 缺 $IDX（先跑 run_common_test.sh index）"; exit 1; }
  [ -d "$PROJECT/data/data_geoaux" ] || { echo "[fatal] 缺 data/data_geoaux"; exit 1; }
  [ -d "$PROJECT/data/data_grouped_geoaux" ] || { echo "[fatal] 缺 data/data_grouped_geoaux"; exit 1; }
  "$PY" - <<'PY' || { echo "[fatal] numpy/torch 不可用"; exit 1; }
import numpy, torch, sys
print(f"[env] numpy {numpy.__version__} | torch {torch.__version__} | cuda {torch.cuda.is_available()}")
sys.exit(0 if torch.cuda.is_available() else 0)
PY
  nvidia-smi --query-gpu=name,memory.used,memory.total --format=csv,noheader 2>/dev/null || echo "[warn] nvidia-smi 不可用"

  # 自动探测 Prithvi 权重
  if [ -z "${PRITHVI_DIR:-}" ]; then
    local W
    W=$(find "$PROJECT" -maxdepth 3 -name "Prithvi_100M.pt" 2>/dev/null | head -1)
    if [ -n "$W" ]; then
      PRITHVI_DIR=$(dirname "$W"); export PRITHVI_DIR
      echo "[env] PRITHVI_DIR=$PRITHVI_DIR"
    else
      echo "[warn] 未找到 Prithvi_100M.pt —— prithvi 阶段会被跳过"
    fi
  fi
  echo "[eta] cnn ≈25min | pixel ≈25min | prithvi ≈2–3h | unet 复用 EXP-T 结果"
}

# ---- 复用 EXP-T 的 U-Net 结果 ---------------------------------------------
reuse_unet() {
  local src="$PROJECT/results/supplementary/expT_leaveout/evals"
  if [ -d "$src/with" ] && [ ! -d "$OUT/unet/with" ]; then
    mkdir -p "$OUT/unet/with" "$OUT/unet/without"
    cp -n "$src"/with/*.json    "$OUT/unet/with/"    2>/dev/null
    cp -n "$src"/without/*.json "$OUT/unet/without/" 2>/dev/null
    echo "[reuse] unet ← expT_leaveout : $(ls "$OUT/unet/with" | wc -l) + $(ls "$OUT/unet/without" | wc -l) 个 json"
  elif [ -d "$OUT/unet/with" ]; then
    echo "[reuse] unet 已在 $OUT/unet"
  else
    echo "[warn] 找不到 EXP-T 结果，如需 unet 请单独跑：--family unet"
  fi
}

# ---- 闸门 ---------------------------------------------------------------
do_gate() {
  banner "GATE — 1 seed × 1 epoch"
  for FAM in cnn prithvi; do
    if [ "$FAM" = "prithvi" ] && [ -z "${PRITHVI_DIR:-}" ]; then
      echo "[skip] 没有 Prithvi 权重，跳过 prithvi 闸门与阶段"
      continue
    fi
    EXTRA=""
    [ "$FAM" = "prithvi" ] && EXTRA="--prithvi-dir ${PRITHVI_DIR:-}"
    echo "--- gate: $FAM ---"
    timeout 1200 "$PY" "$SCRIPT" --family "$FAM" --precheck $EXTRA || {
      echo "[abort] gate 失败：$FAM"; exit 1; }
    local D="$OUT""_precheck/$FAM/with"
    if ! ls "$D"/*.json >/dev/null 2>&1; then
      echo "[abort] gate 失败：$FAM 没写出 json（$D）"; exit 1; fi
    echo "[gate ok] $FAM -> $(ls "$D"/*.json | head -1)"
  done
  echo "[gate] ✅ 全部通过，可以放全量"
}

# ---- 各阶段 -------------------------------------------------------------
do_cnn() {
  banner "STAGE cnn"
  "$PY" -u "$SCRIPT" --family cnn --out "$OUT" --index "$IDX" || echo "[warn] cnn 有失败"
}

do_pixel() {
  banner "STAGE pixel (rf + xgb)"
  "$PY" -u "$SCRIPT" --family pixel --out "$OUT" --index "$IDX" || echo "[warn] pixel 有失败"
}

do_prithvi() {
  if [ -z "${PRITHVI_DIR:-}" ]; then
    echo "[skip] 未找到 Prithvi 权重，跳过该阶段（其余三族不受影响）"
    return 0
  fi
  banner "STAGE prithvi"
  EXTRA=""
  [ -n "${PRITHVI_DIR:-}" ] && EXTRA="--prithvi-dir $PRITHVI_DIR"
  "$PY" -u "$SCRIPT" --family prithvi --out "$OUT" --index "$IDX" $EXTRA || echo "[warn] prithvi 有失败"
}

do_stagec() {
  banner "STAGE C — 异瓦片训练集（tile 级），评测集仍为 E"
  for F in unet cnn pixel; do
    echo "--- stageC: $F ---"
    "$PY" -u "$SCRIPT" --family "$F" --arm tile --out "$OUT" --index "$IDX" \
      || echo "[warn] $F 阶段 C 有失败"
  done
}

do_compare() {
  banner "STAGE compare"
  "$PY" "$SCRIPT" --compare --out "$OUT" --index "$IDX"
  echo
  cat "$OUT/TABLE_ablation_all.md" 2>/dev/null
}

do_status() {
  echo "== 各 family 已完成 seed 数（目标 8 个 with + 8 个 without）=="
  for D in "$OUT"/*/; do
    [ -d "$D/with" ] || continue
    F=$(basename "$D")
    echo "  $F : with=$(ls "$D/with"/*.json 2>/dev/null | wc -l)  without=$(ls "$D/without"/*.json 2>/dev/null | wc -l)"
  done
  echo "== 最近日志 =="
  ls -lt "$LOGS"/ablation*.log 2>/dev/null | head -3
}

case "${1:-all}" in
  gate)     preflight; do_gate ;;
  cnn)      preflight; reuse_unet; do_cnn ;;
  pixel)    preflight; do_pixel ;;
  prithvi)  preflight; do_prithvi ;;
  stagec)   preflight; do_stagec ;;
  compare)  do_compare ;;
  status)   do_status ;;
  all)      preflight; reuse_unet; do_gate; do_cnn; do_pixel; do_prithvi; do_stagec; do_compare ;;
  *) echo "usage: bash run_ablation_all.sh {gate|cnn|pixel|stagec|prithvi|compare|status|all}"; exit 2 ;;
esac

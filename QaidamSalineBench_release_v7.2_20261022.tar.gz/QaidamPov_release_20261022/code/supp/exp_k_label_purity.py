#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EXP-K — how separable is the proxy label, really?

Answers the circularity objection directly.  WorldCover class 60 is NOT soil
salinity: it mixes evaporite crusts with bare rock and alluvial-fan surfaces.  So
a proxy-label IoU of 0.926 cannot be read as mapping skill — the honest question
is *how easy the label is to reproduce from six raw bands*.  This script measures
exactly that, and nothing that requires field data.

What is computed (all CPU, no torch, no GPU, no network):

  1. per-class band statistics (mean / std) on the training split
  2. Fisher discriminant ratio per band, and a multivariate between/within
     scatter ratio over the six bands
  3. **linear separability**: stratified 5-fold cross-validated AUC of a logistic
     regression on the six raw bands — i.e. how much of the label a *linear*
     model already recovers
  4. **single-band oracle**: for each band, the best threshold fitted on train
     and scored on test, giving an IoU that a one-parameter rule achieves.  If a
     single threshold gets close to the CNN, the label — not the model — is doing
     the work.

What is deliberately NOT computed: positive predictive value of class 60 against
true soil salinity.  That needs field electrical-conductivity samples, which this
study does not have; the JSON records that explicitly as `ppv_estimable: false`
so the limitation travels with the number instead of being forgotten.

Usage
  python exp_k_label_purity.py --data-dir "$PROJECT_DIR/data/processed_dual" \
      --out-dir "$PROJECT_DIR/results/supplementary/label_purity" \
      --max-pixels 300000
"""
import argparse
import json
import os

import numpy as np

try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import roc_auc_score
    from sklearn.preprocessing import StandardScaler
    HAVE_SK = True
except Exception:                                     # pragma: no cover
    HAVE_SK = False


def load(data_dir, split):
    x = np.load(os.path.join(data_dir, f"{split}_x.npy")).astype(np.float32)
    y = np.load(os.path.join(data_dir, f"{split}_y_static.npy")).astype(np.int64)
    return x, y


def flatten(x):
    n, c, h, w = x.shape
    return x.transpose(0, 2, 3, 1).reshape(-1, c), h * w


def stratified_idx(y, n, seed=42):
    if n is None or n >= len(y):
        return np.arange(len(y))
    rng = np.random.RandomState(seed)
    out = []
    classes, counts = np.unique(y, return_counts=True)
    take = np.maximum(1, (counts / counts.sum() * n).astype(int))
    for c, k in zip(classes, take):
        ci = np.flatnonzero(y == c)
        out.append(rng.choice(ci, size=min(k, len(ci)), replace=False))
    return np.sort(np.concatenate(out))


def iou_saline(y_true, y_pred):
    tp = np.sum((y_true == 1) & (y_pred == 1))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    return float(tp / (tp + fp + fn)) if (tp + fp + fn) else 0.0


def best_threshold_oracle(x_tr, y_tr, x_te, y_te, n_grid=49):
    """One threshold on one band, fitted on train, scored on test."""
    rows = []
    for b in range(x_tr.shape[1]):
        v_tr, v_te = x_tr[:, b], x_te[:, b]
        lo, hi = np.percentile(v_tr, [1, 99])
        best = (-1.0, float(lo))
        for t in np.linspace(lo, hi, n_grid):
            pred = (v_tr >= t).astype(np.int64)
            # a band threshold may encode the class either way round
            s = max(iou_saline(y_tr, pred), iou_saline(y_tr, 1 - pred))
            if s > best[0]:
                best = (s, float(t))
        t = best[1]
        pred = (v_te >= t).astype(np.int64)
        io = max(iou_saline(y_te, pred), iou_saline(y_te, 1 - pred))
        rows.append({"band_index": b, "threshold": t,
                     "train_iou_oracle": round(best[0], 4),
                     "test_iou": round(io, 4)})
    rows.sort(key=lambda r: -r["test_iou"])
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--max-pixels", type=int, default=300_000)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    x_tr, y_tr_img = load(args.data_dir, "train")
    x_te, y_te_img = load(args.data_dir, "test")

    Xtr_img, pp = flatten(x_tr)
    Xte_img, _ = flatten(x_te)
    ytr_img = y_tr_img.reshape(-1)
    yte_img = y_te_img.reshape(-1)

    sel = stratified_idx(ytr_img, args.max_pixels, args.seed)
    Xtr, ytr = Xtr_img[sel], ytr_img[sel]
    print(f"[data] train pixels {len(ytr_img):,} -> {len(ytr):,} sampled | "
          f"test pixels {len(yte_img):,} (full)", flush=True)
    print(f"[data] class balance (sampled) N={int((ytr == 0).sum()):,} "
          f"P={int((ytr == 1).sum()):,}", flush=True)

    # ---------------------------------------------------- 1. band statistics
    mus, sds, fisher = {}, {}, {}
    for b in range(Xtr.shape[1]):
        m0, m1 = Xtr[ytr == 0, b], Xtr[ytr == 1, b]
        mus[f"b{b}"] = [float(m0.mean()), float(m1.mean())]
        sds[f"b{b}"] = [float(m0.std(ddof=1)), float(m1.std(ddof=1))]
        fisher[f"b{b}"] = float((m1.mean() - m0.mean()) ** 2 /
                                (m0.var(ddof=1) + m1.var(ddof=1) + 1e-12))

    # ------------------------------------- 2. multivariate scatter ratio
    mu0, mu1 = Xtr[ytr == 0].mean(0), Xtr[ytr == 1].mean(0)
    Sw = (np.cov(Xtr[ytr == 0], rowvar=False) +
          np.cov(Xtr[ytr == 1], rowvar=False)) / 2.0
    d = mu1 - mu0
    sb = float(d @ d)
    sw = float(np.trace(Sw))
    fisher_multi = sb / (sw + 1e-12)

    # ------------------------------------------ 3. linear separability (AUC)
    lin = {"available": HAVE_SK}
    if HAVE_SK:
        sc = StandardScaler().fit(Xtr)
        Ztr, Zte = sc.transform(Xtr), sc.transform(Xte_img)
        skf = StratifiedKFold(n_splits=args.folds, shuffle=True,
                              random_state=args.seed)
        aucs = []
        for tr_i, va_i in skf.split(Ztr, ytr):
            clf = LogisticRegression(max_iter=300, solver="lbfgs")
            clf.fit(Ztr[tr_i], ytr[tr_i])
            aucs.append(float(roc_auc_score(ytr[va_i],
                                            clf.predict_proba(Ztr[va_i])[:, 1])))
        clf = LogisticRegression(max_iter=300, solver="lbfgs").fit(Ztr, ytr)
        pred_te = clf.predict(Zte)
        lin.update({
            "cv_auc_mean": round(float(np.mean(aucs)), 4),
            "cv_auc_std": round(float(np.std(aucs, ddof=1)), 4),
            "cv_auc_folds": [round(a, 4) for a in aucs],
            "test_auc": round(float(roc_auc_score(yte_img,
                                                  clf.predict_proba(Zte)[:, 1])), 4),
            "test_iou_linear_model": round(iou_saline(yte_img, pred_te), 4),
            "note": "logistic regression on the six raw bands only",
        })
        print(f"[linear] 5-fold CV AUC = {lin['cv_auc_mean']:.4f} +- "
              f"{lin['cv_auc_std']:.4f} | test IoU = "
              f"{lin['test_iou_linear_model']:.4f}", flush=True)

    # ------------------------------------------- 4. single-band oracle
    te_sel = stratified_idx(yte_img, min(len(yte_img), 400_000), args.seed + 1)
    orc = best_threshold_oracle(Xtr, ytr, Xte_img[te_sel], yte_img[te_sel])
    print(f"[oracle] best single-band test IoU = {orc[0]['test_iou']:.4f} "
          f"(band index {orc[0]['band_index']})", flush=True)

    out = {
        "experiment": "EXP-K label separability (no field data required)",
        "data_dir": args.data_dir,
        "n_train_pixels_used": int(len(ytr)),
        "n_test_pixels_used": int(len(te_sel)),
        "class_means": mus,
        "class_stds": sds,
        "fisher_ratio_per_band": fisher,
        "fisher_ratio_multivariate": round(fisher_multi, 6),
        "linear_separability": lin,
        "single_band_oracle": orc,
        "ppv_estimable": False,
        "ppv_note": ("Positive predictive value of WorldCover class 60 against "
                     "measured soil salinity cannot be estimated from this "
                     "dataset: no field electrical-conductivity samples exist. "
                     "Class 60 also contains bare rock and alluvial-fan "
                     "surfaces. Report proxy-label agreement only."),
    }
    with open(os.path.join(args.out_dir, "label_separability.json"), "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

    lines = ["# EXP-K — is the proxy label near-separable?", "",
             f"- train pixels used: {len(ytr):,}",
             f"- test pixels used : {len(te_sel):,}",
             f"- multivariate Fisher ratio (6 bands): **{fisher_multi:.4f}**"]
    if HAVE_SK:
        lines += [f"- linear separability, 5-fold CV AUC: "
                  f"**{lin['cv_auc_mean']:.4f} ± {lin['cv_auc_std']:.4f}**",
                  f"- logistic-regression test IoU (6 raw bands): "
                  f"**{lin['test_iou_linear_model']:.4f}**"]
    lines += ["", "## Best single-band threshold rules (fitted on train, scored on test)", "",
              "| band | threshold | test IoU |", "|---|---|---|"]
    for r in orc[:6]:
        lines.append(f"| b{r['band_index']} | {r['threshold']:.1f} | "
                     f"{r['test_iou']:.4f} |")
    lines += ["", "## Interpretation", "",
              "A high linear AUC and a high single-band IoU mean the label is "
              "reproducible from raw reflectance almost without a model. That is "
              "the correct reading of the 0.926 headline: **the label, not the "
              "architecture, is doing the work.**", "",
              "PPV against true soil salinity is **not estimable** here (no field "
              "EC data); see `ppv_note` in the JSON."]
    with open(os.path.join(args.out_dir, "TABLE_label_purity.md"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print(f"[done] -> {args.out_dir}", flush=True)


if __name__ == "__main__":
    main()

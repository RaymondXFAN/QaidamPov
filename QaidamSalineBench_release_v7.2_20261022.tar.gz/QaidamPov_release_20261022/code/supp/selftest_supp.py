#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest_supp.py — offline end-to-end self-test for the supplementary package.

Runs every experiment script on tiny SYNTHETIC data with correct shapes and
dtypes, on CPU, with 2 epochs, and asserts that all expected output files are
written. Purpose: catch import/path/dtype/shape bugs *before* the long server run.

Usage:
    python selftest_supp.py
Exit code 0 => all good (prints ✅ PASS).
"""
from __future__ import annotations

import os
import sys
import json
import subprocess
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable


def run(cmd, expect_rc=0):
    print("\n$ " + " ".join(cmd), flush=True)
    r = subprocess.run(cmd, cwd=HERE)
    if r.returncode != expect_rc:
        print(f"❌ command failed (rc={r.returncode}): {' '.join(cmd)}")
        sys.exit(1)


def need(path):
    ok = os.path.exists(path)
    print(("  ✅ " if ok else "  ❌ MISSING ") + path)
    if not ok:
        sys.exit(1)
    return path


def main():
    from common import make_synthetic_data, ttest_rel, describe

    tmp = tempfile.mkdtemp(prefix="qaidam_supp_selftest_")
    data = os.path.join(tmp, "data")
    out = os.path.join(tmp, "out")
    H = 64
    make_synthetic_data(data, n_train=16, n_val=6, n_test=6, H=H, W=H, seed=0)
    print(f"🧪 synthetic data -> {data}")

    # ---- stats sanity (no scipy needed) ----
    a = np.array([0.80, 0.78, 0.83])
    b = np.array([0.79, 0.77, 0.78])
    st = ttest_rel(a, b)
    assert abs(st["mean_diff"] - np.mean(a - b)) < 1e-9, st
    assert st["n"] == 3 and st["df"] == 2
    print(f"  ✅ ttest_rel: {st['mean_diff']:+.4f}, t={st['t']:.3f}, p={st['p_value']:.4f}")
    try:
        from scipy import stats  # optional cross-check
        t2 = stats.ttest_rel(a, b)
        assert abs(st["t"] - t2.statistic) < 1e-6, (st["t"], t2.statistic)
        assert abs(st["p_value"] - t2.pvalue) < 1e-6, (st["p_value"], t2.pvalue)
        print("  ✅ ttest_rel matches scipy (t and p)")
    except ImportError:
        print("  ℹ️  scipy absent (not required); manual t-test used")
    dd = describe([1.0, 2.0, 3.0])
    assert abs(dd["std_ddof1"] - 1.0) < 1e-9  # sample std
    print(f"  ✅ describe(ddof=1): std={dd['std_ddof1']:.4f}")

    # ---- EXP-A ----
    run([PY, "exp_a_multiseed_lambda.py", "--data-dir", data, "--out-dir", out,
         "--seeds", "42,43", "--lambdas", "1.0,0.5", "--epochs", "2",
         "--batch-size", "8", "--cpu"])
    A = os.path.join(out, "expA_multiseed_lambda")
    need(os.path.join(A, "TABLE_multiseed_lambda.md"))
    need(os.path.join(A, "grid_results.json"))
    need(os.path.join(A, "ckpts", "dual_seed42_lam1.0.pth"))
    need(os.path.join(A, "ckpts", "single_seed42.pth"))
    gr = json.load(open(os.path.join(A, "grid_results.json")))
    assert gr["single_task"]["n"] == 2, gr["single_task"]["n"]
    assert "1.0" in gr["paired_dual_minus_single_iou"], gr["paired_dual_minus_single_iou"]
    print("  ✅ EXP-A outputs verified")

    # ---- EXP-B (uses EXP-A checkpoints) ----
    run([PY, "exp_b_export_raw_metrics.py", "--data-dir", data,
         "--ckpt-dir", os.path.join(A, "ckpts"), "--out-dir", out, "--cpu"])
    B = os.path.join(out, "expB_raw_metrics")
    need(os.path.join(B, "raw_metrics_all.json"))
    need(os.path.join(B, "test_distribution.json"))
    need(os.path.join(B, "TABLE_change_per_class.md"))
    rm = json.load(open(os.path.join(B, "raw_metrics_all.json")))
    assert len(rm["dual"]) >= 1, "no dual checkpoints evaluated"
    cm = np.array(rm["dual"][0]["change"]["confusion_matrix"])
    assert cm.shape == (4, 4), cm.shape
    print("  ✅ EXP-B outputs verified (4x4 change confusion matrix present)")

    # ---- EXP-C ----
    run([PY, "exp_c_unet_baseline.py", "--data-dir", data, "--out-dir", out,
         "--mode", "both", "--seeds", "42", "--epochs", "2", "--cpu"])
    C = os.path.join(out, "expC_unet")
    need(os.path.join(C, "TABLE_unet.md"))
    need(os.path.join(C, "unet_summary.json"))
    print("  ✅ EXP-C outputs verified")

    # ---- EXP-D ----
    total = 16 + 6 + 6
    rng = np.random.RandomState(1)
    # 7 spatial groups
    groups = rng.randint(0, 7, size=total).astype(np.int64)
    np.save(os.path.join(tmp, "groups.npy"), groups)
    coords = np.stack([90 + rng.rand(total) * 0.02, 37 + rng.rand(total) * 0.02], 1)
    np.save(os.path.join(tmp, "coords.npy"), coords)
    D = os.path.join(out, "expD_spatial")
    run([PY, "exp_d_spatial_split.py", "--mode", "audit", "--data-dir", data,
         "--out-dir", out, "--coords", os.path.join(tmp, "coords.npy")])
    need(os.path.join(D, "leakage_audit.json"))
    run([PY, "exp_d_spatial_split.py", "--mode", "split", "--data-dir", data,
         "--out-dir", out, "--groups", os.path.join(tmp, "groups.npy")])
    need(os.path.join(D, "grouped_split.json"))
    need(os.path.join(D, "data_grouped", "train_x.npy"))
    run([PY, "exp_d_spatial_split.py", "--mode", "train", "--data-dir", data,
         "--out-dir", out, "--grouped-data-dir", os.path.join(D, "data_grouped"),
         "--seeds", "42", "--epochs", "2", "--cpu"])
    need(os.path.join(D, "grouped_train_results.json"))
    print("  ✅ EXP-D outputs verified")

    print("\n" + "=" * 60)
    print("✅ PASS — all supplementary experiment scripts run end-to-end offline")
    print(f"   (temp dir: {tmp})")
    print("=" * 60)


if __name__ == "__main__":
    main()

# QaidamPov 补充实验包（EAI 返修用）

> 目的：为 EAI 返修稿补齐"能自证的实验证据"。本包**不改动原项目任何代码**，
> 全部为独立脚本，复用原有的数据目录与 checkpoint 命名。
> 生成日期：2026-10-11

---

## 0. 这个包解决评审里的哪些问题

| 评审条目 | 问题 | 本包对应实验 |
|---|---|---|
| P0-1 / Q-01~03 | Table 4 数学上不可能（准确率 < 单类贡献；macro-F1/weighted 对不上） | **EXP-B** 导出原始混淆矩阵，重算 |
| P0-3 / Q-05 | 六跑是伪重复；头条 0.803 非无偏估计 | **EXP-A** 多种子 × λ 网格 + 单任务配对 |
| P1-1 / Q-14 / Q-15 | ΔIoU 三处打架、std 口径混用（ddof） | **EXP-A**（统一 ddof=1 并给配对检验） |
| P1-6 Q-05(B) | λ 消融只有单 seed | **EXP-A**（λ × seed 双因素） |
| Q-24 | Table 2 只报 train 分布 | **EXP-B** 导出 test 分布 |
| Q-25 | Prithvi 的 stability F1-macro 无出处 | **EXP-B**（读 prithvi checkpoint 导出） |
| Q-26 | 缺 U-Net 等分割实践基线 | **EXP-C** U-Net（单任务 + 双任务） |
| Q-16 | stride 64 导致 patch 重叠、train/test 泄漏 | **EXP-D** 防泄漏重切分 + 重训 |

---

## 1. 目录结构

```
supp/
├── common.py                     # 公共：数据/模型/指标/统计（与原文架构逐层一致）
├── exp_a_multiseed_lambda.py     # EXP-A 多种子×λ 网格 + 单任务配对
├── exp_b_export_raw_metrics.py   # EXP-B 原始混淆矩阵/逐类指标导出
├── exp_c_unet_baseline.py        # EXP-C U-Net 基线
├── exp_d_spatial_split.py        # EXP-D 防泄漏切分（audit/split/train）
├── selftest_supp.py              # 离线自测（合成数据，CPU，2 epoch）
├── run_supplementary.sh          # 一键 runner（含预检闸门/幂等/汇总）
└── README_SUPPLEMENT.md          # 本文件
```

**关键实现约定（保证与论文可比）**
- `DualTaskModel` 与原 `02_train_dual.py` **逐层一致**；编码器 128→64→32（**两次** maxpool），两次上采样回 128。
- 归一化用 train 集 mean/std；类别权重、best-val 选模、AdamW+cosine 全部沿用原文。
- 所有 std **统一 ddof=1（样本标准差）**，并附配对 t 检验（手写实现，不依赖 scipy）。
- 数据格式：`train/val/test_{x,y_static,y_change}.npy`，x 为 `(N,6,128,128) float32`，标签 `int64`。

---

## 2. 依赖

与原项目相同，无需额外安装：`torch`, `numpy`, `scikit-learn`（`timm` 仅在 EXP-B 读 Prithvi checkpoint 时用到）。

---

## 3. 上机操作（AutoDL）

### 3.1 放置
压缩包内顶层目录为 `QaidamPov/supp/`，解压到数据盘根即成为 `/root/autodl-tmp/QaidamPov/supp/`：

```bash
tar -xzf QaidamPov_supp.tar.gz -C /root/autodl-tmp/
cd /root/autodl-tmp/QaidamPov/supp
```
> 该目录已存在 `QaidamPov/`，解压只会新增 `supp/` 子目录，不会覆盖任何原有文件。

### 3.2 先跑"预检闸门"（约 5 分钟）
```bash
bash run_supplementary.sh gate
```
看到 `✅ gate passed` 再往下；失败即为数据/环境问题，日志在 `supp/logs/`。

### 3.3 后台跑全流程
```bash
nohup bash run_supplementary.sh all > logs/boot.log 2>&1 &
```
（`all` 会依次跑 gate → EXP-A → EXP-B → EXP-C → EXP-D，**幂等**：已完成的步骤自动 SKIP。）

### 3.4 非阻塞监控（**不要用 `tail -f`**）
```bash
bash run_supplementary.sh status      # 一眼看进度 + 当前 job + 最新日志尾
```
跑完后一次看总表：
```bash
bash run_supplementary.sh summary
```

### 3.5 单独跑某一步
```bash
bash run_supplementary.sh expA        # 或 expB / expC / expD
```

---

## 4. 各实验：输入 / 输出 / 耗时

| 实验 | 输入 | 主要输出 | 预估耗时(4090) |
|---|---|---|---|
| gate | 现有数据 | `_gate/` 小样本结果 | ~5 min |
| **EXP-A** | 数据（不需 checkpoint）| `expA_multiseed_lambda/TABLE_multiseed_lambda.md`、`grid_results.json`、`ckpts/` | 15 run × ~5 min ≈ **75 min** |
| **EXP-B** | **已有 checkpoint**（dual_*/prithvi_lora_*） | `expB_raw_metrics/{raw_metrics_all.json, test_distribution.json, TABLE_change_per_class.md}` | **几分钟** |
| **EXP-C** | 数据 | `expC_unet/TABLE_unet.md`、`unet_summary.json` | 6 run × ~6 min ≈ **40 min** |
| **EXP-D** | 需要 `coords`/`groups`（见 §5）| `expD_spatial/{leakage_audit.json, grouped_split.json, grouped_train_results.json}` | audit 快；train 与 EXP-A 同级 |

> **总耗时经验值 ≈ 2–2.5 小时**（不含 Prithvi 重训——本包不重训 Prithvi，只复用其 checkpoint 做 EXP-B 导出）。
> 种子/λ 可用环境变量加码：`SEEDS=42,123,2024,7,2025 LAMBDAS=1.0,0.3,0.5,0.7 bash run_supplementary.sh expA`

---

## 5. EXP-D 的两个可选输入（重要）

空间泄漏是"必须处理"的问题，但**修复它的前提是知道每个 patch 来自哪块空间**。二选一：

- **`GROUPS`**（推荐，用于 `split`）：长度 = 全部 patch 数（280+60+60=400）的**整数组 id**，每行一个，标明该 patch 属于哪个 MGRS tile / 地理区块。
  从预处理阶段导出即可（同一 tile 切出的 patch 同 id）。然后：
  ```bash
  GROUPS=/path/groups.npy bash run_supplementary.sh expD
  ```
  脚本按 **group 70/15/15** 重新划分，写入 `expD_spatial/data_grouped/` 并重训，
  给出**防泄漏 IoU** 以对照原文 0.803。

- **`COORDS`**（可选，用于 `audit`）：`(400,2)` 的 lon/lat（patch 中心，顺序 = train,val,test 拼接）。
  脚本统计"测试 patch 到最近训练 patch 的距离小于一个 patch 足迹(1280 m)"的比例，量化泄漏程度。

**若两者都没有**：EXP-D 会**如实报告"无法量化"**，我们就在回复信里把泄漏写为"已声明的局限"（诚实声明，也能过）。**但强烈建议想办法拿到 groups** —— 这条直接决定审稿人信不信 0.803。

---

## 6. 离线自测（本机 CPU，无需服务器）
```bash
python selftest_supp.py     # 需 torch（CPU 版即可）
```
它用**真实 dtype 的合成数据**把 4 个实验全部跑一遍并断言输出齐全，看到 `✅ PASS` 即代表脚本本身无 bug。

---

## 7. 注意事项
- 本包**不修改** `02/03/04` 等原脚本，也不动现有 `results/`；所有产物落在 `results/supplementary/`。
- EXP-B 会**读取** `checkpoints/dual_*.pth` 与 `checkpoints/prithvi_lora_*.pth`；若原有 Prithvi checkpoint 不在，则自动跳过 Prithvi 部分并提示。
- 结果里所有 `std` 均为 **ddof=1**，与原文 Table 6 的 ±0.024 口径一致，彻底消除 ddof 混用。
- 需要重跑某一步：删掉其输出目录或 `_gate/`，再执行对应命令即可（幂等）。

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exp_n_paired_stats.py — SR-grade paired statistics for the dual-vs-single comparison

Why this exists
---------------
Scientific Reports' statistical guidelines require, for every test: the test name,
the n, the comparison, a justification, the alpha, one/two-tailed, the exact P value,
error bars labelled as s.d. or s.e.m., and *range* rather than s.d. for very small
samples.  A paired t-test with n = 3 also cannot be justified on normality grounds,
so we additionally report an exact sign-flip permutation test and its minimum
attainable two-sided P value (2 / 2^n).

Reads     <runs-dir>/*.json          one file per (seed, lambda) and per single-task run
Writes    <out>/TABLE_paired_sr.md
          <out>/paired_sr.json

Usage
    python exp_n_paired_stats.py --runs-dir results/supplementary/expA_geoaux_grouped8/runs \
        --out results/supplementary/expA_geoaux_grouped8
"""
from __future__ import annotations

import argparse
import glob
import itertools
import json
import os
import re

import numpy as np
from scipy import stats


def read_iou(d):
    """Tolerant reader: the IoU lives at d['static']['iou_saline'] in current runs."""
    for node in (d.get("static"), d.get("metrics", {}).get("static"), d):
        if isinstance(node, dict):
            for k in ("iou_saline", "iou", "saline_iou", "IoU_saline"):
                if k in node and isinstance(node[k], (int, float)):
                    return float(node[k])
    return None


def load(runs_dir):
    dual, single = {}, {}
    skipped = []
    for f in sorted(glob.glob(os.path.join(runs_dir, "*.json"))):
        b = os.path.basename(f)
        try:
            d = json.load(open(f))
        except Exception as e:  # noqa: BLE001
            skipped.append((b, f"unreadable: {e}"))
            continue
        iou = read_iou(d)
        if iou is None:
            skipped.append((b, "no IoU field"))
            continue
        # 兼容 unet_single_seed42 / dual_seed42_lam1.0 / unet_dual_seed42 等命名
        m = re.search(r"(single|dual)[_-]?seed(\d+)(?:[_-]?lam([0-9]+(?:\.[0-9]+)?))?", b)
        if m:
            kind, seed, lam = m.group(1), int(m.group(2)), m.group(3)
            if kind == "single":
                single[seed] = iou
            else:
                dual.setdefault(float(lam) if lam else 1.0, {})[seed] = iou
            continue
        skipped.append((b, "name does not match any known pattern"))
    return dual, single, skipped


def signflip_p(diffs):
    """Exact two-sided paired sign-flip permutation test."""
    diffs = np.asarray(diffs, dtype=float)
    n = len(diffs)
    obs = abs(diffs.mean())
    cnt = 0
    for signs in itertools.product((1, -1), repeat=n):
        if abs((diffs * np.array(signs)).mean()) >= obs - 1e-12:
            cnt += 1
    return cnt / 2 ** n, 2 / 2 ** n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs-dir", required=True)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    out = args.out or os.path.dirname(os.path.abspath(args.runs_dir))

    dual, single, skipped = load(args.runs_dir)
    if not dual and not single:
        raise SystemExit(f"[fatal] no runs recognised under {args.runs_dir}")
    if not single:
        raise SystemExit("[fatal] no single-task runs — the paired comparison is impossible")

    print(f"[load] single-task seeds : {sorted(single)}")
    for lam in sorted(dual):
        print(f"[load] dual lambda={lam:<4} seeds: {sorted(dual[lam])}")
    for b, why in skipped:
        print(f"[skip] {b}  ({why})")

    rows = []
    for lam in sorted(dual):
        seeds = sorted(set(dual[lam]) & set(single))
        if len(seeds) < 2:
            print(f"[warn] lambda={lam}: only {len(seeds)} paired seed(s), skipped")
            continue
        d = np.array([dual[lam][s] for s in seeds], dtype=float)
        s = np.array([single[ss] for ss in seeds], dtype=float)
        diff = d - s
        n = len(diff)
        t, p_t = stats.ttest_rel(d, s)
        se = diff.std(ddof=1) / np.sqrt(n)
        tcrit = stats.t.ppf(0.975, n - 1)
        p_perm, p_min = signflip_p(diff)
        rows.append({
            "lambda": lam, "n": n, "seeds": seeds,
            "dual_mean": float(d.mean()), "dual_sd": float(d.std(ddof=1)),
            "single_mean": float(s.mean()), "single_sd": float(s.std(ddof=1)),
            "delta": float(diff.mean()), "delta_sd": float(diff.std(ddof=1)),
            "delta_min": float(diff.min()), "delta_max": float(diff.max()),
            "ci_lo": float(diff.mean() - tcrit * se),
            "ci_hi": float(diff.mean() + tcrit * se),
            "t": float(t), "p_t": float(p_t),
            "p_perm": float(p_perm), "p_perm_min": float(p_min),
            "n_pos": int((diff > 0).sum()),
            "cohens_dz": float(diff.mean() / diff.std(ddof=1)) if diff.std(ddof=1) > 0 else float("nan"),
        })

    # ------------------------------------------------------------------ print
    hdr = (f"{'lam':>5} {'n':>3} {'single':>17} {'dual':>17} {'delta':>9} "
           f"{'95% CI':>20} {'p(t)':>8} {'p(perm)':>9} {'+/-':>6}")
    print("\n" + hdr)
    print("-" * len(hdr))
    for r in rows:
        print(f"{r['lambda']:>5} {r['n']:>3} "
              f"{r['single_mean']:.4f}±{r['single_sd']:.4f}   "
              f"{r['dual_mean']:.4f}±{r['dual_sd']:.4f}  "
              f"{r['delta']:+.4f}  [{r['ci_lo']:+.4f}, {r['ci_hi']:+.4f}]  "
              f"{r['p_t']:>8.4f} {r['p_perm']:>9.4f} "
              f"{r['n_pos']:>3}/{r['n']}")
    if rows:
        print(f"\n[note] minimum attainable two-sided permutation p at n={rows[0]['n']} "
              f"is {rows[0]['p_perm_min']:.4f} (= 2/2^n).")

    # ------------------------------------------------------------------- write
    os.makedirs(out, exist_ok=True)
    L = ["# Paired dual-vs-single statistics (pre-specified λ = 1.0)", "",
         "Primary analysis: λ = 1.0, same seeds, same epochs, same schedule. "
         "Other λ are descriptive only and carry no inferential weight. "
         "α = 0.05, two-sided. Error bars and ± throughout are **s.d.**, not s.e.m.", "",
         "| λ | n | single IoU | dual IoU | Δ IoU | Δ range | 95% CI of Δ | t (df) | p (paired t) "
         "| p (sign-flip) | Δ>0 | d_z |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        L.append(f"| {r['lambda']} | {r['n']} | {r['single_mean']:.4f} ± {r['single_sd']:.4f} | "
                 f"{r['dual_mean']:.4f} ± {r['dual_sd']:.4f} | {r['delta']:+.4f} | "
                 f"[{r['delta_min']:+.4f}, {r['delta_max']:+.4f}] | "
                 f"[{r['ci_lo']:+.4f}, {r['ci_hi']:+.4f}] | "
                 f"{r['t']:.3f} ({r['n'] - 1}) | {r['p_t']:.4f} | {r['p_perm']:.4f} | "
                 f"{r['n_pos']}/{r['n']} | {r['cohens_dz']:+.2f} |")
    if rows:
        L += ["", f"**Minimum attainable two-sided permutation p at n = {rows[0]['n']}: "
                  f"{rows[0]['p_perm_min']:.4f}** (= 2/2^n). Any claim of significance at this "
                  f"sample size must survive this bound.", ""]
    L += ["Tests: paired two-sample t-test (`scipy.stats.ttest_rel`, two-sided) reported alongside "
          "an exact paired sign-flip permutation test, because normality is untestable below "
          "n ≈ 10. The permutation test is assumption-free and is the one we treat as primary "
          "when the two disagree.", ""]
    with open(os.path.join(out, "TABLE_paired_sr.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    with open(os.path.join(out, "paired_sr.json"), "w", encoding="utf-8") as f:
        json.dump({"primary_lambda": 1.0, "alpha": 0.05, "sided": "two",
                   "error_bar": "s.d.", "rows": rows}, f, indent=2)
    print(f"\n[write] {os.path.join(out, 'TABLE_paired_sr.md')}")
    print(f"[write] {os.path.join(out, 'paired_sr.json')}")


if __name__ == "__main__":
    main()

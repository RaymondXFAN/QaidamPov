#!/bin/bash
# =============================================================================
# QaidamPov supplementary experiments — one-click runner
#
# Layout assumed on the server:
#     PROJECT = /root/autodl-tmp/QaidamPov
#     scripts = $PROJECT/supp            (this folder)
#     out     = $PROJECT/results/supplementary
#
# Usage:
#     bash run_supplementary.sh gate      # ~5 min safety gate (tiny real run)
#     bash run_supplementary.sh expA      # multi-seed x lambda grid
#     bash run_supplementary.sh expB      # raw confusion-matrix export
#     bash run_supplementary.sh expC      # U-Net baseline
#     bash run_supplementary.sh expD      # spatial split (audit/split/train)
#     bash run_supplementary.sh all       # gate -> A -> B -> C -> D
#     bash run_supplementary.sh status    # non-blocking progress check
#     bash run_supplementary.sh summary   # print the final SUMMARY file
#
# Long run (detached):
#     nohup bash run_supplementary.sh all > logs/boot.log 2>&1 &
# =============================================================================
set -uo pipefail

PROJECT="${PROJECT_DIR:-/root/autodl-tmp/QaidamPov}"
SUPP="${PROJECT}/supp"
OUT="${PROJECT}/results/supplementary"
LOGS="${SUPP}/logs"
PY="${PYTHON:-python}"

SEEDS="${SEEDS:-42,123,2024}"
LAMBDAS="${LAMBDAS:-1.0,0.3,0.5,0.7}"
EPOCHS="${EPOCHS:-30}"
BATCH="${BATCH:-8}"

# Optional inputs for EXP-D (set these if you have them)
COORDS="${COORDS:-}"          # Nx2 lon/lat .npy, patch centres (audit mode)
GROUPS="${GROUPS:-}"          # N int group ids per patch (split mode)

mkdir -p "${OUT}" "${LOGS}"
cd "${SUPP}"

log()  { echo "[$(date '+%F %T')] $*"; }
ok()   { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
die()  { echo "❌ $*"; exit 1; }

have() { [ -e "$1" ]; }

# ---------------------------------------------------------------------------
gate() {
    log "=== GATE: tiny real run to validate data + code path (≈5 min) ==="
    local gdir="${OUT}/_gate"
    rm -rf "${gdir}"
    ${PY} -u exp_a_multiseed_lambda.py --data-dir "${PROJECT}/data/processed_dual" \
        --out-dir "${OUT}" --tag _gate --seeds 42 --lambdas 1.0 \
        --epochs 2 --batch-size "${BATCH}" || die "gate run crashed"
    have "${gdir}/runs/dual_seed42_lam1.0.json" || die "gate: no per-run json written"
    have "${gdir}/TABLE_multiseed_lambda.md"   || die "gate: no table written"
    ok "gate passed — data loads, model trains, results written"
}

expA() {
    log "=== EXP-A: multi-seed x lambda grid (seeds=${SEEDS} lambdas=${LAMBDAS}) ==="
    if have "${OUT}/expA_multiseed_lambda/TABLE_multiseed_lambda.md"; then
        warn "EXP-A already done -> SKIP (delete the folder to redo)"; return
    fi
    ${PY} -u exp_a_multiseed_lambda.py --data-dir "${PROJECT}/data/processed_dual" \
        --out-dir "${OUT}" --seeds "${SEEDS}" --lambdas "${LAMBDAS}" \
        --epochs "${EPOCHS}" --batch-size "${BATCH}" \
        || die "EXP-A failed"
    ok "EXP-A done -> ${OUT}/expA_multiseed_lambda/TABLE_multiseed_lambda.md"
}

expB() {
    log "=== EXP-B: raw confusion-matrix export from existing checkpoints ==="
    if have "${OUT}/expB_raw_metrics/TABLE_change_per_class.md"; then
        warn "EXP-B already done -> SKIP"; return
    fi
    local ckptdir="${PROJECT}/checkpoints"
    if ! ls "${ckptdir}"/dual_*.pth >/dev/null 2>&1; then
        ckptdir="${OUT}/expA_multiseed_lambda/ckpts"
        warn "no dual_*.pth in ${PROJECT}/checkpoints -> using EXP-A checkpoints"
    fi
    [ -d "${ckptdir}" ] || die "no checkpoint dir available for EXP-B (run EXP-A first)"
    ${PY} -u exp_b_export_raw_metrics.py --data-dir "${PROJECT}/data/processed_dual" \
        --ckpt-dir "${ckptdir}" --out-dir "${OUT}" --batch-size "${BATCH}" \
        || die "EXP-B failed"
    ok "EXP-B done -> ${OUT}/expB_raw_metrics/TABLE_change_per_class.md"
}

expC() {
    log "=== EXP-C: U-Net baseline (single + dual) ==="
    if have "${OUT}/expC_unet/TABLE_unet.md"; then
        warn "EXP-C already done -> SKIP"; return
    fi
    ${PY} -u exp_c_unet_baseline.py --data-dir "${PROJECT}/data/processed_dual" \
        --out-dir "${OUT}" --mode both --seeds "${SEEDS}" \
        --epochs "${EPOCHS}" --batch-size "${BATCH}" \
        || die "EXP-C failed"
    ok "EXP-C done -> ${OUT}/expC_unet/TABLE_unet.md"
}

expD() {
    log "=== EXP-D: spatial-leakage-safe split ==="
    if [ -z "${GROUPS}" ] && have "${PROJECT}/data/processed_dual/patch_tiles.npy"; then
        GROUPS="${PROJECT}/data/processed_dual/patch_tiles.npy"
        warn "GROUPS auto-set from rebuild output (patch_tiles.npy) -> leak-free split will work"
    fi
    if [ -n "${COORDS}" ] && have "${COORDS}"; then
        ${PY} -u exp_d_spatial_split.py --mode audit --out-dir "${OUT}" \
            --data-dir "${PROJECT}/data/processed_dual" --coords "${COORDS}" \
            || warn "EXP-D audit failed"
    else
        warn "COORDS not set -> skipping leakage audit (set COORDS=/path/coords.npy)"
    fi
    if [ -n "${GROUPS}" ] && have "${GROUPS}"; then
        ${PY} -u exp_d_spatial_split.py --mode split --out-dir "${OUT}" \
            --data-dir "${PROJECT}/data/processed_dual" --groups "${GROUPS}" \
            || die "EXP-D split failed"
        ${PY} -u exp_d_spatial_split.py --mode train --out-dir "${OUT}" \
            --grouped-data-dir "${OUT}/expD_spatial/data_grouped" \
            --seeds "${SEEDS}" --epochs "${EPOCHS}" --batch-size "${BATCH}" \
            || die "EXP-D train failed"
        ok "EXP-D done -> ${OUT}/expD_spatial/grouped_train_results.json"
    else
        warn "GROUPS not set -> skipping grouped re-split (set GROUPS=/path/groups.npy)"
        warn "  Without it we can only *document* the leakage limitation, not measure it."
    fi
}

summary() {
    local f="${OUT}/SUMMARY.md"
    {
        echo "# QaidamPov supplementary — summary"
        echo
        echo "generated: $(date '+%F %T')"
        echo
        for t in expA_multiseed_lambda/TABLE_multiseed_lambda.md \
                 expB_raw_metrics/TABLE_change_per_class.md \
                 expC_unet/TABLE_unet.md \
                 expD_spatial/leakage_audit.json \
                 expD_spatial/grouped_train_results.json ; do
            if have "${OUT}/${t}"; then
                echo "## ${t}"
                echo '```'
                cat "${OUT}/${t}"
                echo '```'
                echo
            fi
        done
    } > "${f}"
    cat "${f}"
}

status() {
    echo "--- supplementary progress ---"
    echo "out dir : ${OUT}"
    for p in \
        "_gate/runs/dual_seed42_lam1.0.json|gate" \
        "expA_multiseed_lambda/TABLE_multiseed_lambda.md|EXP-A" \
        "expB_raw_metrics/TABLE_change_per_class.md|EXP-B" \
        "expC_unet/TABLE_unet.md|EXP-C" \
        "expD_spatial/grouped_train_results.json|EXP-D" ; do
        f="${p%%|*}"; n="${p##*|}"
        if have "${OUT}/${f}"; then echo "  [done] ${n}"; else echo "  [    ] ${n}"; fi
    done
    echo "--- running python jobs ---"
    pgrep -af "exp_[abcd]_" || echo "  (none)"
    echo "--- tail of newest log ---"
    ls -t "${LOGS}"/*.log 2>/dev/null | head -1 | xargs -r tail -n 15
}

case "${1:-all}" in
    gate)    gate ;;
    expA)    expA ;;
    expB)    expB ;;
    expC)    expC ;;
    expD)    expD ;;
    status)  status ;;
    summary) summary ;;
    all)
        gate
        expA
        expB
        expC
        expD
        summary
        ok "ALL supplementary experiments finished"
        ;;
    *) die "unknown command: ${1:-} (use gate|expA|expB|expC|expD|all|status|summary)" ;;
esac

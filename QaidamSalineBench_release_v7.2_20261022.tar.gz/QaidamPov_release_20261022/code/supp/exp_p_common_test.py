#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exp_p_common_test.py — 把两套划分对齐到同一个测试集（纯 numpy，无需 torch）

为什么需要它
------------
patch 级测试集 60 个 patch / 983,040 像素，tile 级 66 个 / 1,081,344 像素。
两者不是同一批像素，所以 "tile IoU − patch IoU" 混合了两种效应：
    (a) 泄漏被移除
    (b) 测试集换了
本脚本建立一个**唯一评测集 E**（= tile 级 test 的 66 个 patch，来自留出瓦片），
并把 E 拆成 E_seen / E_unseen：
    E_seen   = 这些 patch **也出现在 patch 级训练集里**（模型训练时见过）
    E_unseen = 不在 patch 级训练集里
于是可以分离出三个互不混淆的量：
    Δ_mem    = IoU(E_seen) − IoU(E_unseen)   同一模型、同一像素、只差"见没见过"
    Δ_cover  = patch 模型(E_unseen) vs tile 模型(E)   同一像素、训练覆盖度不同
    Δ_arch   = 上述量随模型家族的变化

关键实现细节
------------
两个数据目录的 patch **顺序不同**，不能按下标对齐。这里用 x 数组的
md5 做指纹；若指纹匹配率 < 90%（例如中途改过 dtype/normalisation），
自动退回"六波段均值 + 最近邻"匹配，并打印警告。

用法
----
    # 1) 建索引（秒级）
    python exp_p_common_test.py index \
        --patch-dir /root/autodl-tmp/QaidamPov/data/processed_dual \
        --eval-dir  /root/autodl-tmp/QaidamPov/results/supplementary/expD_spatial/data_grouped \
        --out       /root/autodl-tmp/QaidamPov/results/supplementary/common_test

    # 2) 汇总（等 exp_q_common_eval.py 跑完之后）
    python exp_p_common_test.py report \
        --index /root/autodl-tmp/QaidamPov/results/supplementary/common_test/common_index.json \
        --eval-out /root/autodl-tmp/QaidamPov/results/supplementary/common_test/evals \
        --out /root/autodl-tmp/QaidamPov/results/supplementary/common_test

输出
----
    common_index.json   每个 patch 的指纹、所属瓦片、在两套划分中的归属
    patch_table.csv     人可读版本
    TABLE_common_test.md  最终表
"""
from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import json
import os
import sys

import numpy as np

SPLITS = ("train", "val", "test")


# --------------------------------------------------------------------- utils
def md5_of(arr: np.ndarray) -> str:
    return hashlib.md5(np.ascontiguousarray(arr, dtype=np.float32).tobytes()).hexdigest()


def load_split_x(data_dir: str, split: str):
    p = os.path.join(data_dir, f"{split}_x.npy")
    if not os.path.exists(p):
        return None
    return np.load(p, mmap_mode="r")


def load_tiles(data_dir: str, n: int):
    """瓦片 id 数组；找不到就返回 None（不致命）。"""
    for name in ("patch_tiles.npy", "tiles.npy", "groups.npy"):
        p = os.path.join(data_dir, name)
        if os.path.exists(p):
            g = np.load(p)
            if len(g) >= n:
                return g[:n], os.path.basename(p)
    return None, None


def build_dir_table(data_dir: str):
    """返回 {split: [ {idx, md5, band_mean} ]}"""
    table = {}
    for sp in SPLITS:
        x = load_split_x(data_dir, sp)
        if x is None:
            continue
        n = len(x)
        rows = []
        for i in range(n):
            a = np.asarray(x[i], dtype=np.float32)
            rows.append({"idx": i, "md5": md5_of(a),
                         "band_mean": [float(v) for v in a.mean(axis=(1, 2))]})
        table[sp] = rows
    return table


def describe_dir(tag, table):
    counts = "  ".join(f"{sp}={len(table[sp])}" for sp in SPLITS if sp in table)
    print(f"[dir] {tag:<6} {counts}")


# --------------------------------------------------------------------- index
def cmd_index(args):
    os.makedirs(args.out, exist_ok=True)
    patch_tab = build_dir_table(args.patch_dir)
    eval_tab = build_dir_table(args.eval_dir)
    if "test" not in eval_tab:
        raise SystemExit(f"[fatal] {args.eval_dir} 缺 test_x.npy")
    describe_dir("patch", patch_tab)
    describe_dir("eval ", eval_tab)

    # patch 目录里所有 md5 -> (split, idx)
    patch_lookup = {}
    for sp, rows in patch_tab.items():
        for r in rows:
            patch_lookup[r["md5"]] = (sp, r["idx"])

    # 指纹匹配率
    E = eval_tab["test"]
    hit = sum(1 for r in E if r["md5"] in patch_lookup)
    rate = hit / max(1, len(E))
    print(f"[match] {hit}/{len(E)} eval-test patches 在 patch 目录中找到（{rate:.1%}）")

    fallback = {}
    if rate < 0.90:
        print("[warn] 指纹匹配率过低，退回波段均值最近邻匹配（结果请人工复核）")
        all_patch = [(r["md5"], sp, r["idx"], np.array(r["band_mean"]))
                     for sp, rows in patch_tab.items() for r in rows]
        for r in E:
            v = np.array(r["band_mean"])
            d = [np.abs(v - a[3]).sum() for a in all_patch]
            j = int(np.argmin(d))
            if d[j] < 1e-3:
                fallback[r["md5"]] = (all_patch[j][1], all_patch[j][2])
                patch_lookup.setdefault(r["md5"], (all_patch[j][1], all_patch[j][2]))
        hit = sum(1 for r in E if r["md5"] in patch_lookup)
        print(f"[match] 回退后 {hit}/{len(E)}")

    # 瓦片信息
    p_tiles, p_name = load_tiles(args.patch_dir, sum(len(v) for v in patch_tab.values()))
    e_tiles, e_name = load_tiles(args.eval_dir, sum(len(v) for v in eval_tab.values()))
    print(f"[tiles] patch目录={p_name or '未找到'}  eval目录={e_name or '未找到'}")

    # 组装 E 的逐 patch 记录
    records = []
    for r in E:
        mem = patch_lookup.get(r["md5"])
        records.append({
            "md5": r["md5"],
            "eval_idx": r["idx"],
            "patch_split": mem[0] if mem else None,
            "patch_idx": mem[1] if mem else None,
            "seen_in_training": bool(mem and mem[0] == "train"),
        })
    n_seen = sum(1 for x in records if x["seen_in_training"])
    print(f"[E] 共 {len(records)} patch：seen={n_seen}  unseen={len(records) - n_seen}")

    out = {
        "patch_dir": os.path.abspath(args.patch_dir),
        "eval_dir": os.path.abspath(args.eval_dir),
        "md5_match_rate": rate,
        "n_eval_test": len(records),
        "n_seen": n_seen,
        "n_unseen": len(records) - n_seen,
        "E": records,
    }
    jp = os.path.join(args.out, "common_index.json")
    with open(jp, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    cp = os.path.join(args.out, "patch_table.csv")
    with open(cp, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["eval_idx", "md5", "patch_split", "patch_idx", "seen_in_training"])
        for r in records:
            w.writerow([r["eval_idx"], r["md5"], r["patch_split"], r["patch_idx"],
                        int(r["seen_in_training"])])
    print(f"[write] {jp}\n[write] {cp}")
    if n_seen == 0:
        print("[warn] E 中没有任何 patch 落在 patch 级训练集 —— 说明两套划分几乎同构，"
              "本实验失去对比意义，请检查 eval-dir 是否用错。")


# -------------------------------------------------------------------- report
def _iou_from_counts(c):
    tp, fp, fn = c["tp"], c["fp"], c["fn"]
    d = tp + fp + fn
    return tp / d if d else float("nan")


def cmd_report(args):
    idx = json.load(open(args.index, encoding="utf-8"))
    seen = {r["md5"]: r["seen_in_training"] for r in idx["E"]}

    files = sorted(glob.glob(os.path.join(args.eval_out, "**", "*.json"), recursive=True))
    if not files:
        raise SystemExit(f"[fatal] {args.eval_out} 下没有评估 json")

    rows = []
    for f in files:
        d = json.load(open(f, encoding="utf-8"))
        pc = d.get("per_patch", [])
        if not pc:
            continue
        grp = {"seen": [], "unseen": [], "all": []}
        for p in pc:
            key = p["md5"]
            if key not in seen:
                continue
            grp["all"].append(p)
            grp["seen" if seen[key] else "unseen"].append(p)

        def agg(lst):
            c = {"tp": 0, "fp": 0, "fn": 0}
            for p in lst:
                for k in c:
                    c[k] += int(p.get(k, 0))
            return _iou_from_counts(c), len(lst)

        i_all, n_all = agg(grp["all"])
        i_seen, n_seen = agg(grp["seen"])
        i_un, n_un = agg(grp["unseen"])
        rows.append({"name": d.get("name", os.path.basename(f)),
                     "family": d.get("family", "?"),
                     "protocol": d.get("protocol", "?"),
                     "iou_all": i_all, "iou_seen": i_seen, "iou_unseen": i_un,
                     "n_all": n_all, "n_seen": n_seen, "n_unseen": n_un})

    if not rows:
        raise SystemExit("[fatal] 没有可汇总的 per_patch 记录")

    # 按 (family, protocol) 汇总 mean ± sd
    from collections import defaultdict
    g = defaultdict(list)
    for r in rows:
        g[(r["family"], r["protocol"])].append(r)

    L = ["# Common-test-set evaluation（同一批像素，两套划分）", "",
         f"评测集 E = tile 级 test 的 {idx['n_eval_test']} 个 patch，"
         f"其中 {idx['n_seen']} 个也在 patch 级训练集中（E_seen），"
         f"{idx['n_unseen']} 个不在（E_unseen）。", "",
         "| Model | Protocol | n runs | IoU(E_seen) | IoU(E_unseen) | Δ_mem | IoU(E) |",
         "|---|---|---:|---|---|---|---|"]
    for (fam, prot), rs in sorted(g.items()):
        def ms(k):
            v = np.array([r[k] for r in rs], dtype=float)
            v = v[~np.isnan(v)]
            return f"{v.mean():.4f} ± {v.std(ddof=1):.4f}" if len(v) > 1 else (
                f"{v.mean():.4f}" if len(v) else "—")
        dmem = np.array([r["iou_seen"] - r["iou_unseen"] for r in rs], dtype=float)
        dmem = dmem[~np.isnan(dmem)]
        dmem_s = f"{dmem.mean():+.4f}" + (f" ± {dmem.std(ddof=1):.4f}" if len(dmem) > 1 else "")
        L.append(f"| {fam} | {prot} | {len(rs)} | {ms('iou_seen')} | {ms('iou_unseen')} "
                 f"| {dmem_s} | {ms('iou_all')} |")
    L += ["", "Δ_mem = IoU(E_seen) − IoU(E_unseen)，即**同一模型、同一批像素**上"
              "「训练时见过 / 没见过」的差距，是记忆化膨胀的直接度量。", ""]
    op = os.path.join(args.out, "TABLE_common_test.md")
    os.makedirs(args.out, exist_ok=True)
    open(op, "w", encoding="utf-8").write("\n".join(L))
    print("\n".join(L))
    print(f"\n[write] {op}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("index")
    a.add_argument("--patch-dir", required=True, help="patch 级数据目录（含 train_x.npy）")
    a.add_argument("--eval-dir", required=True, help="tile 级数据目录，其 test 即评测集 E")
    a.add_argument("--out", required=True)
    a.set_defaults(func=cmd_index)

    b = sub.add_parser("report")
    b.add_argument("--index", required=True)
    b.add_argument("--eval-out", required=True)
    b.add_argument("--out", required=True)
    b.set_defaults(func=cmd_report)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

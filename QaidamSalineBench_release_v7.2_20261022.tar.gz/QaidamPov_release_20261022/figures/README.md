# Figures

Six figures, one palette, generated from the per-seed numbers that are in the paper's
tables. Nothing here was touched up in Illustrator, which is the only way I can promise
that a bar height equals a number.

| File | Paper | Content | Panel count |
|---|---|---|---|
| `Fig1_separability_rank` | Fig. 1 | The separability ladder: constant 0.620, six single-band thresholds, six-band linear 0.890, four learned models up to 0.927; and the same three models under both protocols | 2 |
| `Fig2_design_audit` | Fig. 2 | Sampling design (patch vs tile split), composition of the 66-patch common set (48 / 10 / 8), share of test patches sharing a tile with training (100 % vs 0 %) | 3 |
| `Fig3_ladder_did` | Fig. 3 | The three-arm ladder (0.923 / 0.874 / 0.807, eight seeds each) and its decomposition into 1.24 + 3.68 + 6.71 = 11.63 points | 2 |
| `Fig4_cprime` | Fig. 4 | The sample-size-matched arm C′: B / C′ / C dumbbells, and B → C split into spatial source versus 42 extra patches | 2 |
| `Fig5_aux_indices` | Fig. 5 | Dual-minus-single IoU at tile level for two backbones and two auxiliary labels; spectral-index features under both protocols | 2 |
| `Fig6_family_gradient` | Fig. 6 | Duplication effect by family (1.71 → 5.19 points) and the same intervention as a share of each family's total penalty | 2 |

## Palette

`morandi_style.py` — "Morandi, grey-classic". One colour, one meaning, across all six
figures:

| Hex | Role |
|---|---|
| `#4E6B80` | deep slate — tile-level (leakage-free) protocol, and the neighbourhood term |
| `#B0868A` | dusty rose — patch-level (leaky) protocol, and the duplication term |
| `#6FA0A0` | grey teal — the deduplicated middle arm |
| `#C39B72` | greige — ordinary data loss (placebo) |
| `#8A8A93` | neutral grey — trivial baselines (constant classifier, single-band threshold) |
| `#1F1F1F` | text, never pure black |

Typography: Times/Nimbus serif, 16 pt minimum, no title inside the image (captions are
editable paragraphs in the manuscript), PNG at 600 dpi plus vector PDF.

## Regenerate

```bash
cd figures/scripts
python fig3_separability_rank.py     # -> _out/Fig1_separability_rank.{png,pdf}
python fig1_design_audit.py          # -> Fig2
python fig2_ladder_did.py            # -> Fig3
python fig6_cprime.py                # -> Fig4
python fig4_aux_indices.py           # -> Fig5
python fig5_family_gradient.py       # -> Fig6
```

Note the mismatch between script names and figure numbers: the scripts were written in
one order and the figures are numbered by first citation in the text. The table above is
the mapping; `save()` writes the correct Figure-N stem.

`save()` runs two self-checks and prints their result. `overlap_report()` counts
collisions between text bounding boxes; `edge_ink_check()` looks for ink in the outer
three pixel columns of the PNG, which is how a clipped axis label announces itself. Both
should report zero. If a figure is regenerated with different data, expect to move a few
labels by hand; the scripts are not layout-solvers.

# -*- coding: utf-8 -*-
"""Fig.2 — 三阶段阶梯 + 协议差距的三分量拆解（U-Net，8 种子）。"""
import sys
sys.path.insert(0, "/sandbox/workspace/figs")
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from morandi_style import (use_style, save, despine, panel_label, overlap_report,
                            INK, C_LEAK, C_HONEST, C_MID, C_SOFT2)

use_style(base=17)

# ---- EXP-U 实测（U-Net single, 8 seeds, 共同评测集 E）----
with_seeds = np.array([0.9167, 0.9182, 0.9203, 0.9208, 0.9212, 0.9266, 0.9270, 0.9342])
wout_seeds = np.array([0.8521, 0.8532, 0.8620, 0.8784, 0.8800, 0.8806, 0.8832, 0.9031])
tile_seeds = np.array([0.7835, 0.7859, 0.7956, 0.8007, 0.8022, 0.8182, 0.8234, 0.8463])

rows = [
    ("patch 280", with_seeds, C_LEAK),
    ("patch 232", wout_seeds, C_MID),
    ("tile 274",  tile_seeds, C_HONEST),
]

fig = plt.figure(figsize=(7.16, 3.35))
gs = gridspec.GridSpec(1, 2, width_ratios=[1.22, 1.0], wspace=0.42)

# ---------------------------------------------------------------- (a) ladder
ax = fig.add_subplot(gs[0, 0])
ys = np.arange(len(rows))[::-1]
for y, (lab, v, c) in zip(ys, rows):
    m, sd = v.mean(), v.std(ddof=1)
    ax.barh(y, m, height=0.44, color=c, alpha=0.92, edgecolor="none", zorder=2)
    ax.errorbar(m, y, xerr=sd, fmt="none", ecolor=INK, elinewidth=1.4,
                capsize=4, capthick=1.4, zorder=5)
    ax.text(m - sd - 0.006, y + 0.30, f"{m:.3f}", va="bottom", ha="right",
            fontsize=16, fontweight="bold", color=INK)
    rng = np.random.default_rng(1)
    ax.scatter(v, y + rng.normal(0, 0.055, len(v)), s=15,
               facecolor="white", edgecolor=INK, linewidth=0.8, zorder=6)
ax.set_yticks(ys)
ax.set_yticklabels([r[0] for r in rows], fontsize=16)
ax.set_xlim(0.72, 1.02)
ax.set_xticks([0.75, 0.80, 0.85, 0.90, 0.95])
ax.tick_params(axis="x", labelsize=15)
ax.set_xlabel("IoU on common test set", labelpad=3)
despine(ax, left=False)
ax.spines["left"].set_visible(False)
ax.grid(axis="x", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax.set_axisbelow(True)
# 步降标注
for y0, y1, txt in ((ys[0], ys[1], "−4.9"), (ys[1], ys[2], "−6.7")):
    xm = 0.985
    ax.annotate("", xy=(xm, y1 + 0.23), xytext=(xm, y0 - 0.23),
                arrowprops=dict(arrowstyle="-|>", lw=1.4, color=INK, shrinkA=0, shrinkB=0))
    ax.text(xm - 0.004, (y0 + y1) / 2, txt, fontsize=15, va="center", ha="right",
            color=INK, fontweight="bold")
panel_label(ax, "(a)", x=-0.24, y=1.02)

# ---------------------------------------------------------------- (b) 三分量
ax2 = fig.add_subplot(gs[0, 1])
dup, dloss, nbr = 1.24, 3.68, 6.71
segs = [(dup, C_LEAK, "duplication"), (dloss, C_SOFT2, "data loss"), (nbr, C_HONEST, "neighbourhood")]
left = 0.0
for val, c, lab in segs:
    ax2.barh(0, val, left=left, height=0.42, color=c, edgecolor="white", lw=1.4)
    ax2.text(left + val / 2, 0, f"{val:.1f}", ha="center", va="center",
             fontsize=16, fontweight="bold")
    left += val
ax2.set_xlim(0, 13.2); ax2.set_ylim(-2.35, 1.0)
ax2.set_yticks([]); ax2.set_xticks([0, 4, 8, 12])
ax2.tick_params(axis="x", labelsize=15)
ax2.set_xlabel("share of gap (pp)", labelpad=2)
# 图例：竖排在条形下方，三行，靠左
for i, (val, c, lab) in enumerate(segs):
    yy = -0.72 - i * 0.46
    ax2.add_patch(plt.Rectangle((0.25, yy - 0.16), 0.62, 0.32, color=c))
    ax2.text(1.05, yy, lab, va="center", ha="left", fontsize=14)
despine(ax2, left=False)
ax2.spines["left"].set_visible(False)
panel_label(ax2, "(b)", x=-0.20, y=1.02)

overlap_report(fig, "Fig2")
save(fig, "Fig3_ladder_did")

# -*- coding: utf-8 -*-
"""Fig.4 — Auxiliary-task effect matrix and index-feature reversal."""
import sys
sys.path.insert(0, "/sandbox/workspace/figs")
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Rectangle
from morandi_style import (use_style, save, despine, panel_label, overlap_report,
                            INK, C_LEAK, C_HONEST)

use_style(base=17)

fig = plt.figure(figsize=(7.16, 3.05))
gs = gridspec.GridSpec(1, 2, width_ratios=[1.0, 1.15], wspace=0.40)

# ---------------------------------------------------------------- (a) 2x2 matrix
ax = fig.add_subplot(gs[0, 0])
cells = {("CNN", "geometric"): (0.87, "0.071"),
         ("CNN", "stability"): (0.00, "0.999"),
         ("U-Net", "geometric"): (0.32, "0.714"),
         ("U-Net", "stability"): (2.01, "0.044")}
rows = ["CNN", "U-Net"]
cols = ["geometric", "stability"]
vmax = 2.2
for i, r in enumerate(rows):
    for j, c in enumerate(cols):
        v, p = cells[(r, c)]
        y = 1 - i
        a = 0.10 + 0.50 * min(v / vmax, 1.0)
        ax.add_patch(Rectangle((j, y - 0.42), 0.92, 0.84, facecolor=C_LEAK,
                               alpha=a, edgecolor="white", lw=2.0))
        ax.text(j + 0.46, y + 0.10, f"{v:+.2f}", ha="center", va="center",
                fontsize=21, fontweight="bold", color=INK)
        ax.text(j + 0.46, y - 0.20, f"p = {p}", ha="center", va="center",
                fontsize=14, color="#1F1F1F")
ax.set_xlim(-0.02, 2.0); ax.set_ylim(-0.62, 1.62)
ax.set_xticks([0.46, 1.46]); ax.set_xticklabels(cols, fontsize=16)
ax.set_yticks([1, 0]); ax.set_yticklabels(rows, fontsize=16)
ax.tick_params(length=0)
ax.set_xlabel("auxiliary label", labelpad=6)
for s in ("top", "right", "left", "bottom"):
    ax.spines[s].set_visible(False)
ax.text(1.0, 1.52, "Δ IoU (pp), tile level", ha="center", va="bottom", fontsize=15,
        color="#1F1F1F")
panel_label(ax, "(a)", x=-0.20, y=1.06)

# ---------------------------------------------------------------- (b) 指数反转
ax2 = fig.add_subplot(gs[0, 1])
x = np.arange(2)
w = 0.34
patch_d = [-0.08, 0.13]
tile_d = [1.22, 0.99]
ax2.bar(x - w / 2, patch_d, w, color=C_LEAK, label="patch", edgecolor="none")
ax2.bar(x + w / 2, tile_d, w, color=C_HONEST, label="tile", edgecolor="none")
for xi, v in zip(x - w / 2, patch_d):
    ax2.text(xi, v + (0.06 if v >= 0 else -0.10), f"{v:+.2f}", ha="center",
             va="bottom" if v >= 0 else "top", fontsize=15, color=INK, fontweight="bold")
for xi, v in zip(x + w / 2, tile_d):
    ax2.text(xi, v + 0.06, f"{v:+.2f}", ha="center", va="bottom", fontsize=15,
             color=INK, fontweight="bold")
ax2.axhline(0, color=INK, lw=1.1, zorder=1)
ax2.set_xticks(x); ax2.set_xticklabels(["RF", "XGB"], fontsize=16)
ax2.set_ylim(-0.42, 1.62)
ax2.set_yticks([0, 0.5, 1.0])
ax2.set_ylabel("Δ IoU from indices (pp)", labelpad=3)
ax2.tick_params(axis="y", labelsize=15)
despine(ax2)
ax2.grid(axis="y", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax2.set_axisbelow(True)
ax2.legend(loc="upper left", ncol=2, handlelength=1.0, columnspacing=1.2,
           fontsize=15, bbox_to_anchor=(0.0, 1.06))
panel_label(ax2, "(b)", x=-0.24, y=1.06)

overlap_report(fig, "Fig4")
save(fig, "Fig5_aux_indices")

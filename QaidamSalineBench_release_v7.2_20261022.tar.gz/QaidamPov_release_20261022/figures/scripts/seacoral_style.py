# -*- coding: utf-8 -*-
"""
seacoral_style.py — 本项目统一绘图样式（"海盐珊瑚"配色 + Times 字形 + 大字号）

色号来源：将军提供的色卡（科研配色 · 海盐珊瑚），官方标注 HEX 如下：
  paper  #F7FAFC   极浅冷白（背景）
  sky    #A7C7E7   浅蓝
  mint   #CFEAF6   薄荷浅青
  coral  #F4A7AE   珊瑚粉（核心色）
  peach  #FBD9C9   浅珊瑚
  slate  #5878A6   灰蓝（最深主色）
  sea    #A6D0C6   青绿
  lilac  #DADDE3   淡紫灰

语义绑定（一色一义，全稿一致）：
  slate  = tile 级协议 / "诚实"评测
  coral  = patch 级协议 / 泄漏
  sea    = 中间态（剔除重复 patch）
  sky    = 次级模型（XGB / U-Net）
  peach  = 辅助标签 / 次级高亮
  mint   = 浅填充
  lilac  = 平凡基线（单波段阈值等）
  文字   #1F1F1F（不用纯黑）
"""
import glob
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

PALETTE = {
    "paper": "#F7FAFC",
    "sky":   "#A7C7E7",
    "mint":  "#CFEAF6",
    "coral": "#F4A7AE",
    "peach": "#FBD9C9",
    "slate": "#5878A6",
    "sea":   "#A6D0C6",
    "lilac": "#DADDE3",
}
INK = "#1F1F1F"

# 语义别名
C_LEAK = PALETTE["coral"]
C_HONEST = PALETTE["slate"]
C_MID = PALETTE["sea"]
C_ALT = PALETTE["sky"]
C_TRIVIAL = PALETTE["lilac"]
C_SOFT = PALETTE["mint"]
C_SOFT2 = PALETTE["peach"]

_FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/termes/*.otf",   # TeX Gyre Termes（Times 克隆，首选）
    os.path.expanduser("~/.fonts/*.otf"),
]


def _load_fonts():
    for pat in _FONT_CANDIDATES:
        for f in glob.glob(pat):
            try:
                fm.fontManager.addfont(f)
            except Exception:
                pass


def use_style(base=17):
    """全局样式：Times 字形、字号下限 16、无顶/右框线。"""
    _load_fonts()
    names = {f.name for f in fm.fontManager.ttflist}
    fam = [n for n in ("TeX Gyre Termes", "Times New Roman", "Nimbus Roman",
                       "Liberation Serif", "STIXGeneral", "DejaVu Serif") if n in names]
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": fam + ["DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": base,
        "axes.labelsize": base + 2,
        "axes.titlesize": base + 2,
        "xtick.labelsize": base - 1,
        "ytick.labelsize": base - 1,
        "legend.fontsize": base - 1,
        "axes.linewidth": 1.1,
        "axes.edgecolor": INK,
        "axes.labelcolor": INK,
        "text.color": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.width": 1.0,
        "ytick.major.width": 1.0,
        "xtick.major.size": 5,
        "ytick.major.size": 5,
        "legend.frameon": False,
        "savefig.dpi": 600,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.04,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    return fam


def despine(ax, left=True, bottom=True):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if not left:
        ax.spines["left"].set_visible(False)
    if not bottom:
        ax.spines["bottom"].set_visible(False)


def panel_label(ax, s, x=-0.10, y=1.02):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=20, fontweight="bold",
            va="bottom", ha="left", color=INK)


def edge_ink_check(path, tol=120, band=3):
    """检查 PNG 四边是否还有墨迹（有则说明文字被裁切）。"""
    try:
        from PIL import Image
        import numpy as np
        a = np.array(Image.open(path).convert("L"))
        h, w = a.shape
        hits = {"L": int((a[:, :band] < tol).sum()), "R": int((a[:, w-band:] < tol).sum()),
                "T": int((a[:band, :] < tol).sum()), "B": int((a[h-band:, :] < tol).sum())}
        bad = {k: v for k, v in hits.items() if v}
        if bad:
            print(f"[warn] {path} 边缘有墨迹（可能被裁切）: {bad}")
        return bad
    except Exception:
        return {}


def save(fig, stem, outdir="/sandbox/workspace/figs/_out"):
    os.makedirs(outdir, exist_ok=True)
    for ext in ("pdf", "png"):
        p = os.path.join(outdir, f"{stem}.{ext}")
        fig.savefig(p)          # dpi 600 for png, vector for pdf
        print(f"[write] {p}")
        if ext == "png":
            edge_ink_check(p)
    plt.close(fig)


def overlap_report(fig, name=""):
    """程序化自检：相邻 Text 的 bbox 是否两两重叠（忽略含 0 面积的）。"""
    from matplotlib.text import Text
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    items = []
    for ax in fig.axes:
        tl = list(ax.texts)
        if ax.axison:      # 关掉坐标轴的 panel（示意图）没有可见刻度
            tl += list(ax.get_xticklabels()) + list(ax.get_yticklabels())
            tl += [ax.xaxis.label, ax.yaxis.label]
        for t in tl:
            if t.get_text().strip() and t.get_visible():
                bb = Text.get_window_extent(t, r)
                items.append((t.get_text(), bb))
    bad = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            a, b = items[i][1], items[j][1]
            if a.overlaps(b):
                ix = min(a.x1, b.x1) - max(a.x0, b.x0)
                iy = min(a.y1, b.y1) - max(a.y0, b.y0)
                if ix > 1 and iy > 1:
                    bad.append((items[i][0], items[j][0], round(ix), round(iy)))
    print(f"[check] {name}: {len(items)} 个文本, 重叠 {len(bad)} 处")
    for b in bad[:12]:
        print("   !!", b)
    return bad

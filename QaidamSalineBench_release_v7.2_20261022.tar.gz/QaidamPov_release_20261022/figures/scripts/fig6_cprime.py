# -*- coding: utf-8 -*-
"""Fig.4 — 样本量匹配臂 C′：把 B→C 的差距拆成「换空间来源」与「多 42 个 patch」。

B   = 232 patches, 同一批 tile（剔除 48 个重复 patch）
C′  = 274 patches, 换 tile，但训练集大小与 B 对齐
C   = 274 patches, 换 tile（完整）

数据：EXP-V，8 seeds/臂。
"""
import sys
sys.path.insert(0, "/sandbox/workspace/figs")
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from morandi_style import (use_style, save, despine, panel_label, overlap_report,
                           INK, C_LEAK, C_HONEST, C_MID, C_SOFT2, C_TRIVIAL)

use_style(base=17)

# family, B, C', C, 空间来源(B->C'), 样本量(C'->C), colour
D = [
    ("U-Net",   0.8741, 0.8087, 0.8070,  6.54,  0.17, C_HONEST),
    ("CNN",     0.8666, 0.7905, 0.7803,  7.61,  1.02, C_HONEST),
    ("Prithvi", 0.8447, 0.8410, 0.8294,  0.37,  1.16, C_MID),
    ("XGB",     0.8270, 0.8474, 0.8494, -2.05, -0.19, C_LEAK),
    ("RF",      0.8396, 0.8511, 0.8518, -1.15, -0.07, C_LEAK),
]

fig = plt.figure(figsize=(7.16, 4.15))
gs = gridspec.GridSpec(1, 2, width_ratios=[1.12, 1.0], wspace=0.52)

# ---------------------------------------------------------------- (a) 三点哑铃
ax = fig.add_subplot(gs[0, 0])
ys = np.arange(len(D))[::-1]
for y, (lab, b, cp, c, *_r) in zip(ys, D):
    ax.plot([c, b], [y, y], color="#C9C9C4", lw=2.6, solid_capstyle="round", zorder=1)
    ax.scatter([b], [y], s=86, facecolor="white", edgecolor=C_TRIVIAL, linewidth=1.6, zorder=3)
    ax.scatter([cp], [y], s=86, color=C_MID, edgecolor="white", linewidth=1.0, zorder=4)
    ax.scatter([c], [y], s=96, color=C_HONEST, edgecolor="white", linewidth=1.0, zorder=5)
ax.set_yticks(ys)
ax.set_yticklabels([d[0] for d in D], fontsize=16)
ax.set_xlim(0.765, 0.882)
ax.set_xticks([0.78, 0.82, 0.86])
ax.set_xlabel("IoU on the common set", labelpad=3)
ax.tick_params(axis="x", labelsize=15)
ax.grid(axis="x", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax.set_axisbelow(True)
despine(ax, left=False)
ax.spines["left"].set_visible(False)
# 图例统一放整图底部，避免与面板内数据抢位
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
fig.legend(handles=[
    Line2D([], [], marker="o", ls="", markerfacecolor="white", markeredgecolor=C_TRIVIAL,
           markeredgewidth=1.6, markersize=10, label="B: 232 patches, same tiles"),
    Line2D([], [], marker="o", ls="", markerfacecolor=C_MID, markeredgecolor=C_MID,
           markersize=10, label="C$'$: 274 patches, new tiles"),
    Line2D([], [], marker="o", ls="", markerfacecolor=C_HONEST, markeredgecolor=C_HONEST,
           markersize=10, label="C: 274 patches, new tiles"),
], loc="lower center", bbox_to_anchor=(0.5, -0.175), ncol=3, fontsize=13,
    frameon=False, handletextpad=0.3, columnspacing=1.6)
ax.set_ylim(-0.55, 4.6)
panel_label(ax, "(a)", x=-0.30, y=1.02)

# ---------------------------------------------------------------- (b) 分解
ax2 = fig.add_subplot(gs[0, 1])
ys2 = np.arange(len(D))[::-1]
spa = np.array([d[4] for d in D])
smp = np.array([d[5] for d in D])
for y, s1, s2 in zip(ys2, spa, smp):
    ax2.barh(y, s1, height=0.42, color=C_HONEST, edgecolor="white", lw=1.2)
    ax2.barh(y, s2, left=s1, height=0.42, color=C_SOFT2, edgecolor="white", lw=1.2)
    tot = s1 + s2
    ax2.text(tot + (0.50 if tot >= 0 else -0.50), y, f"{tot:+.1f}", va="center",
             ha="left" if tot >= 0 else "right", fontsize=15, fontweight="bold", color=INK)
ax2.axvline(0, color=INK, lw=1.1, zorder=3)
ax2.set_yticks(ys2); ax2.set_yticklabels([])
ax2.set_xlim(-3.6, 9.6); ax2.set_xticks([-2, 0, 4, 8])
ax2.set_xlabel("B $\\rightarrow$ C (pp)", labelpad=3)
ax2.tick_params(axis="x", labelsize=15)
ax2.grid(axis="x", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax2.set_axisbelow(True)
despine(ax2, left=False)
ax2.spines["left"].set_visible(False)
from matplotlib.patches import Patch
ax2.legend(handles=[Patch(facecolor=C_HONEST, label="spatial source"),
                    Patch(facecolor=C_SOFT2, label="42 extra patches")],
           loc="lower right", fontsize=13, handlelength=1.0, frameon=False)

overlap_report(fig, "Fig4")
save(fig, "Fig4_cprime")

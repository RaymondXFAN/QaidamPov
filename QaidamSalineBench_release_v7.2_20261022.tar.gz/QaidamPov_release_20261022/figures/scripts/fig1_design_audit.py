# -*- coding: utf-8 -*-
"""Fig.1 — Sampling design and overlap audit."""
import sys
sys.path.insert(0, "/sandbox/workspace/figs")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch
import matplotlib.gridspec as gridspec
from morandi_style import (use_style, save, despine, panel_label, overlap_report,
                            PALETTE, INK, C_LEAK, C_HONEST, C_SOFT2)

use_style(base=17)

fig = plt.figure(figsize=(7.16, 4.55))
gs = gridspec.GridSpec(2, 2, height_ratios=[1.9, 1.0], hspace=0.62, wspace=0.34)

# ---------------------------------------------------------------- (a) schematic
ax = fig.add_subplot(gs[0, :])
ax.set_xlim(0, 16.4); ax.set_ylim(0, 4.6); ax.axis("off")

S, G = 0.62, 0.07


def grid(x0, y0, cols, rows, colors):
    for r in range(rows):
        for c in range(cols):
            ax.add_patch(Rectangle((x0 + c * (S + G), y0 + r * (S + G)), S, S,
                                   facecolor=colors[r][c], edgecolor="white", lw=1.3))


def tile_box(x0, y0, cols, rows, label):
    w = cols * (S + G) - G
    h = rows * (S + G) - G
    ax.add_patch(FancyBboxPatch((x0 - 0.13, y0 - 0.13), w + 0.26, h + 0.26,
                                boxstyle="round,pad=0.02,rounding_size=0.08",
                                fill=False, ls=(0, (4, 3)), lw=1.6, ec=INK, zorder=6))
    ax.text(x0 + w / 2, y0 + h + 0.30, label, ha="center", va="bottom",
            fontsize=16, color=INK)


cmap = {"T": C_LEAK, "V": C_HONEST}

# 左：patch 级 —— 同一块瓦片内部被随机拆成 train / test
pat = [["T", "V", "T", "T", "V"],
       ["V", "T", "T", "V", "T"],
       ["T", "V", "T", "T", "T"]]
grid(0.55, 1.05, 5, 3, [[cmap[v] for v in row] for row in pat])
tile_box(0.55, 1.05, 5, 3, "patch-level split  (one tile)")
ax.text(0.55 + 2.5 * (S + G) - G / 2, 0.62, "train and test patches interleaved",
        ha="center", va="top", fontsize=16, color=INK)

# 右：tile 级 —— 整块瓦片留出
left_tile = [["T"] * 3] * 3
right_tile = [["V"] * 3] * 3
grid(9.55, 1.05, 3, 3, [[cmap[v] for v in row] for row in left_tile])
tile_box(9.55, 1.05, 3, 3, "")
grid(9.55 + 3 * (S + G) + 0.55, 1.05, 3, 3, [[cmap[v] for v in row] for row in right_tile])
tile_box(9.55 + 3 * (S + G) + 0.55, 1.05, 3, 3,
         "tile-level split  (tiles disjoint)")
ax.text(9.55 + 3 * (S + G) + 0.55 + 1.5 * (S + G) - G / 2, 0.62,
        "whole tiles held out", ha="center", va="top", fontsize=16, color=INK)

# 图例
ax.add_patch(Rectangle((0.58, 4.05), 0.26, 0.26, facecolor=C_LEAK, edgecolor="white"))
ax.text(0.98, 4.18, "train", va="center", fontsize=16)
ax.add_patch(Rectangle((2.15, 4.05), 0.26, 0.26, facecolor=C_HONEST, edgecolor="white"))
ax.text(2.55, 4.18, "test", va="center", fontsize=16)
panel_label(ax, "(a)", x=-0.02, y=0.95)

# ---------------------------------------------------------------- (b) E 构成
ax2 = fig.add_subplot(gs[1, 0])
seg = [(48, C_LEAK), (10, C_SOFT2), (8, C_HONEST)]
left = 0
for n, c in seg:
    ax2.barh(0, n, left=left, height=0.46, color=c, edgecolor="white", lw=1.4)
    ax2.text(left + n / 2, 0, str(n), ha="center", va="center",
             fontsize=17, fontweight="bold")
    left += n
ax2.set_xlim(0, 68); ax2.set_ylim(-1.45, 0.55)
ax2.set_yticks([]); ax2.set_xticks([0, 25, 50])
ax2.tick_params(axis="x", labelsize=15)
ax2.set_xlabel("evaluation patches", labelpad=2)
ax2.text(0, -0.78, "seen", color=C_LEAK, fontsize=16, ha="left", va="center")
ax2.text(66, -0.78, "unseen", color=C_HONEST, fontsize=16, ha="right", va="center")
despine(ax2, left=False)
ax2.spines["left"].set_visible(False)
panel_label(ax2, "(b)", x=-0.16, y=1.05)

# ---------------------------------------------------------------- (c) 审计
ax3 = fig.add_subplot(gs[1, 1])
labs, vals, cols = ["tile", "patch"], [0, 100], [C_HONEST, C_LEAK]
ax3.barh([0, 1], vals, height=0.44, color=cols, edgecolor="none")
for i, (v, c) in enumerate(zip(vals, cols)):
    ax3.text(v + 3, i, f"{v}%", va="center", ha="left", fontsize=17,
             fontweight="bold", color=c)
ax3.set_yticks([0, 1]); ax3.set_yticklabels(labs, fontsize=16)
ax3.set_xlim(0, 128); ax3.set_xticks([0, 50, 100])
ax3.tick_params(axis="x", labelsize=15)
ax3.set_xlabel("test patches sharing a tile\nwith training (%)", labelpad=2)
despine(ax3, left=False)
ax3.spines["left"].set_visible(False)
panel_label(ax3, "(c)", x=-0.34, y=1.05)

overlap_report(fig, "Fig1")
save(fig, "Fig2_design_audit")

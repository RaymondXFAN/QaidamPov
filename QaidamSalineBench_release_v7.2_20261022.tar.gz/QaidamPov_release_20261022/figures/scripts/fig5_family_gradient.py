# -*- coding: utf-8 -*-
"""Fig.5 — 重复效应随空间先验强度单调下降；协议差距的构成按族反转。"""
import sys
sys.path.insert(0, "/sandbox/workspace/figs")
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from morandi_style import (use_style, save, despine, panel_label, overlap_report,
                            INK, C_LEAK, C_HONEST, C_MID, C_SOFT2)

use_style(base=17)

# family, DiD, CI_lo, CI_hi, Δ_seen, Δ_unseen, B−C, colour
D = [
    ("U-Net",     1.71, 0.75, 2.67,  5.40,  3.68,  6.71, C_HONEST),
    ("CNN",       2.06, 0.85, 3.27,  5.86,  3.80,  8.63, C_HONEST),
    ("Prithvi",   2.97, 2.07, 3.87,  6.48,  3.51,  1.53, C_MID),
    ("XGB",       4.40, 4.32, 4.48, 11.27,  6.88, -2.24, C_LEAK),
    ("RF",        5.19, 5.05, 5.34, 11.98,  6.78, -1.22, C_LEAK),
]

fig = plt.figure(figsize=(7.16, 3.30))
gs = gridspec.GridSpec(1, 2, width_ratios=[1.0, 1.22], wspace=0.46)

# ---------------------------------------------------------------- (a) 梯度
ax = fig.add_subplot(gs[0, 0])
ys = np.arange(len(D))[::-1]
for y, (lab, m, lo, hi, *_rest) in zip(ys, D):
    c = _rest[-1]
    ax.plot([lo, hi], [y, y], color=c, lw=3.0, solid_capstyle="round", zorder=2)
    ax.scatter([m], [y], s=105, color=c, zorder=3, edgecolor="white", linewidth=1.0)
    ax.text(hi + 0.22, y, f"{m:.1f}", va="center", ha="left", fontsize=15,
            color=INK, fontweight="bold")
ax.axvline(0, color=INK, lw=1.1, ls=(0, (3, 2)), zorder=1)
ax.set_yticks(ys); ax.set_yticklabels([d[0] for d in D], fontsize=16)
ax.set_xlim(0, 6.25); ax.set_xticks([0, 2, 4])
ax.set_xlabel("duplication effect (pp)", labelpad=3)
ax.tick_params(axis="x", labelsize=15)
despine(ax, left=False); ax.spines["left"].set_visible(False)
ax.grid(axis="x", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax.set_axisbelow(True)
panel_label(ax, "(a)", x=-0.22, y=1.02)

# ---------------------------------------------------------------- (b) 构成（按族归一化）
ax2 = fig.add_subplot(gs[0, 1])
AC = np.array([11.61, 13.91, 7.18, 7.79, 9.28])          # A − C，各族总惩罚
dup_share = np.array([d[1] for d in D]) * (48 / 66) / AC * 100
plc_share = np.array([d[5] for d in D]) / AC * 100
nbr_share = np.array([d[6] for d in D]) / AC * 100

x = np.arange(len(D)); w = 0.26
ax2.bar(x - w, dup_share, w, color=C_LEAK,   edgecolor="none", label="duplication")
ax2.bar(x,     plc_share, w, color=C_SOFT2,  edgecolor="none", label="data loss")
ax2.bar(x + w, nbr_share, w, color=C_HONEST, edgecolor="none", label="neighbourhood")
ax2.axhline(0, color=INK, lw=1.1, zorder=1)
for xi, v in zip(x - w, dup_share):
    ax2.text(xi, v + 2.0, f"{v:.0f}", ha="center", va="bottom",
             fontsize=14, color=INK, fontweight="bold")
ax2.set_xticks(x); ax2.set_xticklabels([d[0] for d in D], fontsize=13, rotation=32)
ax2.set_ylim(-40, 100)
ax2.set_yticks([0, 50, 100])
ax2.set_ylabel("share of total penalty (%)", labelpad=3)
ax2.tick_params(axis="y", labelsize=15)
despine(ax2)
ax2.grid(axis="y", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax2.set_axisbelow(True)
ax2.legend(loc="upper center", ncol=3, handlelength=0.9, fontsize=12,
           bbox_to_anchor=(0.52, 1.13), frameon=False, columnspacing=1.1)
panel_label(ax2, "(b)", x=-0.30, y=1.14)

overlap_report(fig, "Fig5")
save(fig, "Fig6_family_gradient")

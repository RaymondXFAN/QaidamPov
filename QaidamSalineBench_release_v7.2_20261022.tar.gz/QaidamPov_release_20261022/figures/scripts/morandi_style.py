# -*- coding: utf-8 -*-
"""
morandi_style.py — 本项目统一绘图样式（「莫兰迪·灰调经典」+ Times 字形 + 大字号）

色系取自 academic-figure-style 技能 palettes.SCHEMES["morandi"]。
全稿一色一义，锁定不换：

  C_LEAK    #B0868A  灰玫瑰  = patch 级协议 / 泄漏
  C_HONEST  #4E6B80  深灰蓝  = tile 级协议 / 无泄漏评测
  C_MID     #6FA0A0  灰青    = 剔除重复 patch 的中间态
  C_ALT     #6E8CA0  灰蓝    = 次级模型
  C_TRIVIAL #8A8A93  中性灰  = 平凡基线（常数/单波段阈值）
  C_SOFT2   #C39B72  灰驼    = 普通数据损失
  文字      #1F1F1F  不用纯黑
"""
import glob
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

# ---- 复用 seacoral_style 的主题内核（字体、字号、保存、自检），只覆盖配色 ----
from seacoral_style import (use_style, despine, panel_label, edge_ink_check,  # noqa: F401
                            save, overlap_report, INK)

PALETTE = {
    "paper": "#F7F7F5",
    "sky":   "#C3D0DA",
    "mint":  "#C2D6D6",
    "coral": "#DFCBCB",
    "peach": "#E4D2BE",
    "slate": "#6E8CA0",
    "sea":   "#6FA0A0",
    "lilac": "#D2D2D8",
    "rose":  "#B0868A",
    "deep":  "#4E6B80",
    "green": "#8BA37F",
    "lilac2": "#9C8CA8",
    "tan":   "#C39B72",
}

C_LEAK = PALETTE["rose"]
C_HONEST = PALETTE["deep"]
C_MID = PALETTE["sea"]
C_ALT = PALETTE["slate"]
C_TRIVIAL = "#8A8A93"
C_SOFT = PALETTE["sky"]
C_SOFT2 = PALETTE["tan"]
C_GREEN = PALETTE["green"]

# 五族固定配色（全稿一致：同一族在任何图里同色）
FAMILY = {
    "U-Net":   PALETTE["deep"],
    "CNN":     PALETTE["slate"],
    "Prithvi": PALETTE["lilac2"],
    "XGB":     PALETTE["tan"],
    "RF":      PALETTE["rose"],
}

GRID = "#D8D8D4"
RULE = "#BFBFBA"
NOTE = "#6B6B6B"

# -*- coding: utf-8 -*-
"""Fig.3 — Label separability saturates model performance; ranking flips by protocol."""
import sys
sys.path.insert(0, "/sandbox/workspace/figs")
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from morandi_style import (use_style, save, despine, panel_label, overlap_report,
                            INK, C_LEAK, C_HONEST, C_MID, C_ALT, C_TRIVIAL)

use_style(base=17)

# ---- patch 级实测 IoU（单波段为单阈值最优；LR 为六波段线性；其余为学习模型）----
bars = [
    ("RF",       0.9267, C_HONEST),
    ("U-Net",    0.9104, C_LEAK),
    ("Prithvi",  0.8987, C_MID),
    ("LR",       0.8899, C_ALT),
    ("B04",      0.8202, C_TRIVIAL),
    ("B03",      0.8022, C_TRIVIAL),
    ("B02",      0.7964, C_TRIVIAL),
    ("B12",      0.7137, C_TRIVIAL),
    ("B08",      0.6442, C_TRIVIAL),
    ("B11",      0.6439, C_TRIVIAL),
    ("constant", 0.6200, C_TRIVIAL),
]

fig = plt.figure(figsize=(7.16, 3.75))
gs = gridspec.GridSpec(1, 2, width_ratios=[1.25, 1.0], wspace=0.30)

# ---------------------------------------------------------------- (a) lollipop
ax = fig.add_subplot(gs[0, 0])
ys = np.arange(len(bars))[::-1]
X0 = 0.575
for y, (lab, v, c) in zip(ys, bars):
    ax.plot([X0, v], [y, y], color=c, lw=3.2, solid_capstyle="round", zorder=2)
    if lab == "constant":
        ax.scatter([v], [y], s=95, facecolor="white", edgecolor=c, linewidth=1.6, zorder=3)
    else:
        ax.scatter([v], [y], s=95, color=c, zorder=3, edgecolor="white", linewidth=1.0)
    ax.text(v + 0.008, y, f"{v:.3f}", va="center", ha="left", fontsize=16, color=INK)
# 单波段 / 多波段分界（constant 基线以下单独一段）
ax.axhline(6.5, color="#BFBFBA", lw=1.0, ls=(0, (2, 3)), zorder=1)
ax.set_yticks(ys)
ax.set_yticklabels([b[0] for b in bars], fontsize=16)
ax.set_xlim(X0 - 0.004, 1.005)
ax.set_xticks([0.60, 0.70, 0.80, 0.90])
ax.set_xlabel("IoU, patch-level test set", labelpad=3)
despine(ax, left=False)
ax.spines["left"].set_visible(False)
ax.grid(axis="x", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax.set_axisbelow(True)
ax.text(0.0, -0.27, "colour: six-band model  $\\cdot$  grey: one band, one threshold  $\\cdot$  hollow: no model",
        transform=ax.transAxes, fontsize=13, color="#6B6B6B", ha="left", va="top")
panel_label(ax, "(a)", x=-0.20, y=1.01)

# ---------------------------------------------------------------- (b) dumbbell
ax2 = fig.add_subplot(gs[0, 1])
sl = [("RF",      0.9267, 0.8564),
      ("U-Net",   0.9104, 0.7957),
      ("Prithvi", 0.8987, 0.8205)]
yy = np.arange(len(sl))[::-1]
for y, (lab, a, b) in zip(yy, sl):
    ax2.plot([b, a], [y, y], color="#BFBFBA", lw=2.2, zorder=1, solid_capstyle="round")
    ax2.scatter([a], [y], s=110, color=C_LEAK, zorder=3, edgecolor="white", linewidth=1.1)
    ax2.scatter([b], [y], s=110, color=C_HONEST, zorder=3, edgecolor="white", linewidth=1.1)
    ax2.text((a + b) / 2, y + 0.24, f"{(b - a) * 100:+.1f}", ha="center", va="bottom",
             fontsize=15, color=INK, fontweight="bold")
ax2.set_yticks(yy)
ax2.set_yticklabels([s_[0] for s_ in sl], fontsize=16)
ax2.set_xlim(0.755, 0.955)
ax2.set_ylim(-0.6, 2.62)
ax2.set_xticks([0.80, 0.85, 0.90])
ax2.tick_params(axis="x", labelsize=15)
ax2.set_xlabel("IoU", labelpad=3)
despine(ax2, left=False)
ax2.spines["left"].set_visible(False)
ax2.grid(axis="x", ls=":", lw=0.8, color="#D8D8D4", zorder=0)
ax2.set_axisbelow(True)
# 内联图例
ax2.scatter([0.775], [2.42], s=70, color=C_LEAK, clip_on=False)
ax2.text(0.784, 2.42, "patch", va="center", fontsize=15)
ax2.scatter([0.835], [2.42], s=70, color=C_HONEST, clip_on=False)
ax2.text(0.844, 2.42, "tile", va="center", fontsize=15)
panel_label(ax2, "(b)", x=-0.22, y=1.01)

overlap_report(fig, "Fig3")
save(fig, "Fig1_separability_rank")

# Spatial Leakage and Label Separability Drive Reported Salinization-Mapping Accuracy: A Spatially Blind Baseline Matches a Geospatial Foundation Model

## Abstract
Soil salinization threatens the Qaidam Basin, yet basin-scale maps rest on proxy labels and are validated on randomly split image patches. We quantify how much of the reported accuracy is attributable to the label, to the evaluation protocol and to the model. Using 400 Sentinel-2 patches from 18 map tiles, with the bare-ground class of the WorldCover product as a saline proxy that is positive for 62% of pixels and is therefore a bare-ground rather than a salinity measurement, we benchmark tree ensembles, convolutional networks, a U-Net and a Prithvi foundation model under a patch-level split (280/60/60) and a tile-level split (274/60/66). The proxy is nearly linearly separable: one band with one threshold reaches an intersection-over-union of 0.820 and a six-band linear model 0.890, against 0.62 for a constant classifier, while a pixel-wise forest tops both protocols (0.927 and 0.869). All 18 tiles straddle the patch-level split. On a common evaluation set, withholding tiles costs a U-Net 11.6 points, of which deleting the 48 duplicated patches accounts for 4.9; a placebo arm shows that only 1.2 of those 4.9 points are a duplication effect. Across five families the duplication effect rises monotonically, from 1–2 points for convolutional decoders to 4.4–5.2 for spatially blind ensembles, 11%, 30% and 41% of each family's total penalty, and the ordering replicates on a disjoint set of seeds. Leakage is therefore not uniform in origin, and no single remedy addresses it. Multi-task gains do not reproduce.

**Index Terms**, Data leakage, salinization mapping, Sentinel-2, validation protocol.

---

## I. INTRODUCTION

Soil salinization is among the dominant land-degradation processes in arid endorheic basins, and the Qaidam Basin of the northeastern Tibetan Plateau is a canonical case: a hyper-arid, internally drained depression in which secondary salinization interacts with groundwater withdrawal, irrigation and intense evaporation. Mapping its extent at basin scale is a prerequisite for land-management decisions, and satellite remote sensing is the only practical route at decadal frequency [1], [14]–[16], [21].

Two constraints make this problem harder than it appears. First, salinity is properly characterized by electrical conductivity measured in soil samples, whereas remotely sensed salinity is expressed indirectly through surface crusts and the absence of vegetation. Any satellite-derived map is therefore a *proxy*, and when that proxy is a class exported from a global land-cover product it inherits that product's systematic label noise [23]–[26]. Second, the proxy commonly used at scale, the bare-ground class, is spectrally close to separable from its surroundings, which means the achievable accuracy may be bounded by the label rather than by the model.

Deep learning has become the default response, and two further claims are now routine: that multi-task learning, in which a static map and a change or stability map are predicted jointly, improves the primary task [8], [27]–[29], [39]; and that large pretrained geospatial foundation models provide a decisive advantage in data-scarce settings [2], [18], [30], [31]. Both claims are usually evaluated in the same way: a random split of image patches, single-date reflectance, a handful of random seeds, and the proxy label treated as truth.

This evaluation template has three failure modes that are rarely quantified together. (i) **Construct validity**: if the proxy is nearly separable from raw reflectance, all models converge to the label's own ceiling and architectural comparisons become differences among near-ties. (ii) **Internal validity**: patches are cropped with overlap, so a random patch-level split places near-duplicate content in training and test; because the inflation need not be uniform across model families, it can bias which model appears best [9]–[13], [17], [20], [32], [33]. (iii) **Statistical conclusion validity**: with two or three seeds, paired comparisons cannot reach significance under any nonparametric test, and selecting the best loss weight post hoc yields an optimistically biased headline.

The second failure mode is usually asserted rather than measured. "Leakage" conflates two mechanisms: a test patch may itself appear in training, or it may merely neighbour a training patch. Because patches are cropped at a 64-pixel stride, removing every duplicated patch still leaves the neighbourhood in the training set. The two remedies differ, deduplicate the sample set or withhold spatial units, and separating them requires an intervention on the training set rather than a comparison of two splits.

This paper measures all three failure modes for one reproducible basin-scale benchmark, and replaces the usual cross-protocol comparison with a controlled ablation that isolates the two leakage mechanisms. The contributions are:

1. A reproducible, leakage-audited benchmark: 400 patches from 18 tiles, six bands, two protocols, with the full split-composition report released.
2. A label-separability ladder that bounds every reported score: a constant classifier reaches 0.62 at the 62% prevalence of the proxy, one band with one threshold 0.820, a linear model on six bands 0.890, and a pixel-wise forest with no spatial context 0.927, the highest score in the study.
3. A leakage audit showing that 100% of test patches share a tile with training, and a **three-stage decomposition of the resulting 11.6-point protocol gap on a common evaluation set**: deleting the duplicated patches costs 4.9 points, of which 3.7 are reproduced on patches that were never seen (a placebo), leaving a net duplication effect of 1.2 points on the full 66-patch set (1.7 on the 48 duplicated patches, 1.3 pooled across three batches); withholding the whole tiles costs a further 6.7 points, and a **sample-size-matched arm** shows that 6.5 of those 6.7 come from the change of spatial source rather than from the 42 extra training patches.
4. The mechanism that follows, and its dependence on architecture: repeating the intervention for five families yields a **monotone gradient in spatial prior**, 1–2 points for skip-connected and plain convolutional decoders, 3.0 for a token decoder, and 4.4–5.2 for two spatially blind ensembles, i.e. roughly 11%, 30% and 41% of each family's total penalty. Duplication is largely a problem of models that can memorise individual pixel spectra; neighbourhood sampling is the problem of models that exploit spatial context.
5. A reassessment of multi-task gains under eight seeds, two protocols and two auxiliary labels, showing that the previously reported gain does not reproduce and that no cell survives correction for four comparisons.

---

## II. STUDY AREA AND DATA

### A. Study Area

The Qaidam Basin (approximately 35–39° N, 90–99° E) is a hyper-arid endorheic basin on the northeastern Tibetan Plateau, covering approximately 2.5 × 10⁵ km² including its marginal mountains, with a lowland floor between roughly 2,650 and 3,200 m a.s.l., mean annual precipitation rising from about 15 mm in the northwest to 200 mm in the southeast, and potential evaporation more than an order of magnitude higher [19]. Saline and alkaline surfaces, playas, salt flats and salt-affected alluvial fans, form contiguous, high-albedo patches that are spectrally distinct from the surrounding gravel desert and sparse steppe [35]. Bare ground and desert between them account for almost the whole basin floor [36], which is what makes a bare-ground class a usable proxy here, and also what sets its prevalence. This is precisely why a spectral proxy is feasible, and also why it is easy to learn.

### B. Imagery and Patches

We use Sentinel-2 Level-2A surface reflectance [7] in six bands, B02 (blue), B03 (green), B04 (red), B08 (near-infrared), B11 and B12 (short-wave infrared), on a 10 m analysis grid (the 20 m short-wave infrared bands are resampled). A single cloud-free reflectance stack is used per patch, screened with the operational Copernicus cloud mask [38]; no temporal composite or index stack is supplied to any model, so all **deep** architectures receive identical information. The two index variants of the pixel-wise baselines (RF_idx, XGB_idx) deliberately receive three additional spectral indices, and are reported as separate rows throughout precisely so that the effect of those features remains visible. Patches are 128 × 128 pixels (a 1280 m footprint) cropped with a stride of 64 pixels, i.e. adjacent patches share 50% of their area, from **18** MGRS tiles, yielding 400 patches. All 18 tiles lie in UTM zones 45–47 and were acquired between 25 July and 30 September 2020 under a 15% scene-level cloud-cover ceiling; tile identifiers, scene names and acquisition dates are listed in Table A1. Because MGRS tiles are 110 km squares, several of them straddle the basin margin and contribute marginal desert and alluvial-fan surfaces, which is also where much of the non-saline class comes from. Tile size and overlap are known to move reported accuracy by several points [40], which is why the overlap is recorded in the released split definition rather than left implicit.

### C. Proxy Labels

**Static label.** The WorldCover product [1] contains no salinity class; we therefore use class 60 (*bare / sparse vegetation*), binarised per pixel, as a saline proxy. It is a proxy by necessity, not a measurement: class 60 also captures gravel plains and built-up edges, and no field conductivity data exist for this basin, so positive predictive value against true salinity cannot be estimated from these data. Because bare ground is the dominant cover type in this landscape, the proxy is positive for **62% of the pixels** in every evaluation set used below. It is therefore a bare-ground proxy for saline surfaces, not a salinity measurement, and the prevalence is high enough that accuracy is an uninformative headline metric: we report intersection-over-union throughout for that reason.

**Stability label.** A four-class label is obtained by cross-tabulating the 2020 (v100) and 2021 (v200) class-60 masks: stable non-saline, stable saline, expansion and shrinkage. Because the two epochs come from different product versions, part of the apparent change is version artefact, itself a documented form of label noise in global products [23], [34].

**Geometric auxiliary label.** To separate "the auxiliary task is useless" from "the auxiliary label is contaminated", we build a second target that never touches a product version: for each saline pixel we compute the Euclidean distance to the nearest non-saline pixel *within the same patch* and bin it at 2 and 6 pixels into fringe, shoulder and core, plus one non-saline class. The label is geometrically self-consistent by construction.

### D. Splits

**Patch-level (conventional).** Patches are split 280/60/60 at random, ignoring tile membership.

**Tile-level (leakage-free).** The 18 tiles are partitioned disjointly, giving 274/60/66 patches.

The two protocols assign the same 400 patches differently. Test sets contain 983,040 and 1,081,344 pixels respectively. Because the two test sets differ in composition, no cross-protocol statement below rests on an absolute difference between the two columns of Table I and Table II; the controlled ablation of Section III-D resolves that confound by evaluating both training regimes on one common pixel set.

---

## III. METHODS

### A. Models

**(a) Single- and dual-task CNN.** A 6.10 M-parameter encoder–decoder with four down-sampling stages. The dual-task variant shares the encoder and adds a second head for the four-class auxiliary map, trained with

  L = L_static + λ · L_aux. (1)

**(b) U-Net.** Base width 32, skip connections at every resolution, in single- and dual-task configurations [3]. It is included because skip connections are the property most often credited with fine-boundary performance, and, as Section IV-C shows, the property that most amplifies protocol dependence.

**(c) Prithvi-EO-1.0 with low-rank adapters and a trainable decoder.** A 100 M-parameter vision transformer initialised from the Prithvi-EO-1.0 weights [2] (101 of 101 encoder tensors loaded; missing = 0, unexpected = 0) with adapters [6] (r = 8, α = 16) on the qkv and proj projections of all 12 blocks, plus task-specific token decoders. The adapters themselves contain 0.44 M parameters, but 62.7 M are trained in total because the projection and decoder stack is not frozen [31]; this arm is therefore a fine-tuning configuration, not a parameter-efficient one, and we describe it as such throughout. Because only single-date imagery is available, the three-dimensional patch embedding is bypassed, so this benchmark does not probe the model's temporal capacity and cannot be read as an upper bound on foundation-model performance.

**(d) Pixel-wise baselines.** Random Forest [4] and XGBoost [5] trained on 800,000 stratified training pixels with no neighbourhood and no spatial context, in two feature configurations that are kept distinct throughout: **RF_raw** / **XGB_raw** (six raw bands) and **RF_idx** / **XGB_idx** (six bands plus the normalised difference vegetation index, the normalised difference water index and a salinity index [22]).

### B. Training

AdamW (learning rate 1 × 10⁻³, weight decay 0.01), batch size 8, cosine decay, 30 epochs, class-weighted cross-entropy [37], and horizontal/vertical flip augmentation. Model selection uses the best validation combined score, after which the test set is evaluated once. Every deep configuration is trained with **eight seeds** (42, 123, 2024, 7, 13, 99, 777, 2025), and every table reports all eight, including the runs that underperform. The pixel-wise baselines are deterministic given a fixed training-pixel sample; their eight replicates re-draw the training-pixel sample rather than the initialisation.

Our deep pipeline is **not bit-reproducible**, and this bounds how finely any number here should be read. Re-executing a configuration at a fixed seed typically moves its IoU by about **0.2 points** (seed 42: 0.9111 → 0.9133), and one re-execution moved it by **3.9 points** (seed 777: 0.8677 → 0.9066); the residual comes from CUDA kernels that `torch.backends.cudnn.deterministic` does not cover. Two consequences follow, and they differ in scale. A *single run* should be read to no better than about 0.2 points. An excursion of the second kind propagates to an eight-seed mean as roughly 3.9/8 ≈ **0.5 points**, so differences smaller than that between two eight-seed means should not be interpreted. The intervals in Tables III–V cover seed-to-seed variation only and do not include this run-to-run component. We report the re-execution of the run that showed the 3.9-point excursion and disclose the original in the note to Table I.

### C. Diagnostic Probes

Throughout, the primary metric is the saline-class intersection-over-union. For a reference saline set *S* and a predicted set *Ŝ* over a pixel set Ω,

  IoU = |*S* ∩ *Ŝ*| / |*S* ∪ *Ŝ*|. (2)

Two probes bound what any model can reach on the proxy. The Fisher ratio of band *b* measures univariate class separation, and the best single-band rule is the threshold that maximises IoU on the training split:

  *F*_{b} = (*μ*_{1,b} − *μ*_{0,b})² / [(*σ*_{1,b})² + (*σ*_{0,b})²], (3)

  *t*_{b} = argmax_{t} IoU({*p* : *x*_{p,b} > *t*}, *S*). (4)

A constant classifier that labels every pixel saline attains

  IoU_{const} = *q* / (2 − *q*) (5)

at prevalence *q*, which is the floor any model must beat. Three probes accompany the benchmark: (i) a *label-separability* probe (per-class band statistics, Fisher ratio, five-fold linear separability, multinomial logistic regression, and the single-band rule of (4)); (ii) a *leakage-composition* audit, which fingerprints every patch by the MD5 hash of its float32 tensor and reports, for each evaluation patch, whether it also occurs in training and which partition it belongs to; and (iii) the cleaned auxiliary-label experiment of Section II-C.

### D. Common Evaluation Set and Controlled Ablation

Comparing the patch-level and tile-level columns of Table I and Table II confounds two things: how much spatial context the model had, and which pixels were scored. We therefore define a **common evaluation set** E as the 66 test patches of the tile-level split, pixels that no tile-level model has ever seen, and evaluate every patch-level model on the same 66 patches.

Fingerprinting shows that of these 66 patches, **48 also occur in the patch-level training set**, 10 were used for early stopping (validation) and 8 were never touched. E therefore contains a natural within-set contrast, but that contrast alone is not causal: the two subsets differ in intrinsic difficulty, and a model that has never seen either subset still scores differently on them (Section V-B).

We therefore run a **controlled ablation** in which the same architecture, the same hyper-parameters, the same eight seeds and the same evaluation set are used, and only the composition of the training set changes:

- **arm A (all):** the 280 patch-level training patches, including the 48 that are members of E;
- **arm B (duplicates removed):** the same set with those 48 deleted (232 patches);
- **stage C (tiles withheld):** the tile-level training set, 274 patches drawn from tiles that contain no evaluation patch;
- **arm C′ (matched):** 232 patches drawn from that same tile-level pool, so that the spatial source changes while the sample size is held at B's.

The last arm exists because B and C differ in two things at once, the spatial source and 42 patches, and a contrast that changes two things cannot attribute its effect to either. With C′, the second step splits into **B → C′**, which changes only the spatial source, and **C′ → C**, which changes only the sample size.

From these we report

  Δ_{seen} = IoU(E_{seen} | A) − IoU(E_{seen} | B), (6)
  Δ_{unseen} = IoU(E_{unseen} | A) − IoU(E_{unseen} | B), (7)
  DiD = Δ_{seen} − Δ_{unseen}. (8)

Δ_{unseen} is a **placebo**: deleting 48 patches is not a no-op, because it removes 17% of the training data and, since E_{seen} and E_{unseen} are interleaved within the same tiles, part of the local information around both subsets. Any loss reproduced on patches that were never seen is therefore not a duplication effect, and the difference-in-differences (8) is the quantity of interest.

The ablation is run for five model families: the U-Net, the plain CNN, the Prithvi model (dual-task, λ = 1, matching Table II), and the two pixel-wise ensembles. For the deep models the eight replicates vary the initialisation; for the pixel-wise models they vary the 800,000-pixel training sample, because those classifiers are otherwise deterministic. The intervals reported for the pixel-wise models therefore quantify sampling variability and are not comparable in width with those of the deep models.

The contribution of duplication to the total penalty is expressed as a share of the whole protocol gap,

  Share = DiD × (|E_{seen}| / |E|) / (A − C), (9)

where the weight 48/66 accounts for DiD being measured on the duplicated patches while A − C is measured on all of E.

### E. Evaluation and Statistics

Accuracy, weighted and macro F1, and Cohen's κ are reported alongside IoU. Dual-versus-single comparisons are paired by seed. For each comparison we report the mean difference, a two-sided paired *t*-test (α = 0.05), an exact paired sign-flip permutation test, and a 95% confidence interval from the *t* distribution, because normality is untestable at this sample size. The permutation test compares the observed mean paired difference *d̄* with all 256 sign assignments,

  *p* = 2^{-8} Σ_{s} **1**[ |Σ_{i} *s*_{i}*d*_{i} / 8| ≥ |*d̄*| ], (10)

so its smallest attainable two-sided value is 2/256 = 0.0078; where a test attains that floor we report the exact value rather than an inequality. Where four auxiliary-task cells are compared, we apply a Bonferroni threshold of α = 0.0125.

---

## IV. RESULTS

### A. The Proxy Label Sets the Ceiling

A multivariate Fisher ratio of 2.39 across the six bands and a five-fold cross-validated linear separability area under the curve of 0.982, computed on a stratified subsample of 300,000 training and 400,000 test pixels drawn from the patch-level split indicate that saline and non-saline pixels are close to linearly separable in raw reflectance. A multinomial logistic regression on the six bands alone reaches a test IoU of 0.890, 96% of the best score reported anywhere in this paper. A single threshold on a single band reaches 0.820 (red, B04); green and blue reach 0.802 and 0.796, while the near- and short-wave infrared bands are weaker, 0.714 (B12), and 0.644 for both B11 and B08. The ordering of the bands by this score matches their ordering by Fisher ratio (2.27, 1.98, 1.94, 1.32, 0.48 and 0.10 for B04, B03, B02, B12, B11 and B08; Spearman ρ = 0.94). The band ranking is therefore a property of the proxy rather than of the classifier: the near-infrared band, where a salt crust and dry bare ground are most alike, carries almost no univariate class information (Fisher ratio 0.10) and is 18 points worse than red on its own.

A pixel-wise Random Forest with no spatial context, RF_raw, reaches 0.927, the highest value in the study, and adding three spectral indices does not improve on raw bands (RF_idx, 0.926), which excludes the possibility that the classical baseline is compensating with engineered features. A constant classifier that labels every pixel saline, the natural floor for a label with 62% prevalence, scores an IoU of 0.62, an accuracy of 0.62 and κ = 0. The resulting ladder, 0.62 (constant) → 0.820 (one band, one threshold) → 0.890 (six bands, linear) → 0.927 (six bands, non-linear, spatially blind) → 0.910 (U-Net, full spatial context), has three consequences. First, the proxy label is bounded well below unity by its own spectral ambiguity. Second, the marginal contribution of architectural depth is confined to a narrow band that a spatially blind model already occupies (Fig. 1a). Third, the usable range is narrow: between the constant floor of 0.62 and the best score of 0.927 there are 0.31 IoU points to be won, and one threshold on one band already wins two thirds of them.

[[FIG:1]]

### B. Static Benchmark Under the Conventional Protocol

**TABLE I.** Static saline classification under the **patch-level split** (280/60/60; 983,040 test pixels). Deep models: intersection-over-union is the mean ± standard deviation over eight seeds, all eight reported; the accuracy, weighted F1 and κ columns are means over the same eight runs, without a spread, because the headline metric is IoU.

| Model | Params | Acc. | F1 (w) | κ | IoU |
|---|---|---|---|---|---|
| RF_raw | — | 0.9525 | 0.9525 | 0.8986 | **0.9267** |
| RF_idx | — | 0.9520 | 0.9520 | 0.8976 | 0.9259 |
| XGB_idx | — | 0.9472 | 0.9471 | 0.8869 | 0.9196 |
| XGB_raw | — | 0.9463 | 0.9462 | 0.8848 | 0.9183 |
| U-Net (dual) | 6.1 M | 0.9416 | 0.9417 | 0.8759 | 0.9101 ± 0.0027‡ |
| U-Net (single) | 6.1 M | 0.9419 | 0.9421 | 0.8770 | 0.9104 ± 0.0024 |
| CNN (single) | 6.1 M | 0.9384 | 0.9386 | 0.8696 | 0.9050 ± 0.0037 |
| CNN (dual, λ = 1) | 6.1 M | 0.9341 | 0.9344 | 0.8607 | 0.8985 ± 0.0054 |
| CNN (dual, λ = 0.3) | 6.1 M | 0.9340 | 0.9345 | 0.8612 | 0.8978 ± 0.0067 |
| Prithvi (fine-tuned) | 62.7 M | 0.9343 | 0.9346 | 0.8613 | 0.8987 ± 0.0037 |

‡ One dual-task run (seed 777) returned an IoU of 0.868 against a median of 0.911 for the other seven. Re-executing the same configuration at the same seed returned 0.907, so the low value is an excursion of the pipeline rather than a property of the seed; the row reports the re-execution, and retaining the original would raise its standard deviation from 0.0027 to 0.0153. Both values are released. The Δ column of Table II is the difference of the two means and no paired test is performed across protocols.

Under this protocol the classical baselines exceed every deep model; among the deep models the two U-Nets and the single-task CNN are the strongest, and the two dual-task CNNs and the Prithvi model the weakest, separated by less than a point.

### C. The Protocol Gap Decomposes Into Duplication and Neighbourhood

All 400 patches derive from 18 tiles and were cropped with a stride of 64, so adjacent patches share half their area. In the patch-level split **all 18 tiles contribute patches to all three partitions**; hence 100% of test patches share a tile with at least one training patch, and no tile is held out (Fig. 2).

[[FIG:2]]

**TABLE II.** The same models under the **leakage-free tile-level split** (274/60/66; 1,081,344 test pixels), and the resulting change relative to Table I. The tile-level spreads are two to five times larger than their patch-level counterparts; the two protocols use different training sets and differently composed test sets, so the spreads are not directly comparable across tables.

| Model | IoU | Δ vs patch-level |
|---|---|---|
| RF_idx | **0.8686** | −0.0573 |
| XGB_idx | 0.8591 | −0.0605 |
| RF_raw | 0.8564 | −0.0703 |
| XGB_raw | 0.8492 | −0.0691 |
| Prithvi | 0.8205 ± 0.0279 | −0.0782 |
| U-Net (dual) | 0.8158 ± 0.0121 | −0.0943 |
| U-Net (single) | 0.7957 ± 0.0146 | −0.1147 |
| CNN (single) | 0.7895 ± 0.0284 | −0.1155 |
| CNN (dual, λ = 1) | 0.7895 ± 0.0131 | −0.1090 |
| CNN (dual, λ = 0.3) | 0.7888 ± 0.0163 | −0.1090 |

Two observations survive the change of test set. First, the ordering is **not preserved**: at the patch level the Prithvi model sits fifth of six, below both U-Nets and the single-task CNN, whereas at the tile level it is first. The reassignment is small in absolute terms, 0.8205 against 0.8158 for the dual-task U-Net, a 0.5-point margin well inside the ±1.2–2.8-point seed spread, and it moves past models that were within half a point of it at the patch level, so we read it as a removal of an advantage rather than as a reversal in favour of the foundation model. Second, the cross-protocol penalty is graded by architecture: pixel-wise baselines lose 5.7–7.0 points, the token decoder 7.8, and the skip-connected decoders 8.9–11.5.

Those numbers mix two things: removing the spatial blocking also changes *which* pixels are scored. We therefore hold the evaluation set fixed.

**TABLE III.** Controlled ablation on the common evaluation set E (66 patches, 1,081,344 pixels), eight replicates per arm. A: patch-level training set (280 patches, including 48 that are members of E). B: A minus those 48 patches (232). C: tile-level training set (274 patches, no evaluation tile represented). Δ is in IoU points; DiD is the duplication effect (difference-in-differences), tested by an exact two-sided sign flip over eight seeds. Intervals cover seed-to-seed variation only; run-to-run pipeline variation is additional and is quantified in Section III-B. The same quantity appears at three scales in this paper and they are one effect, not three: **1.71 points** as the DiD on the 48 duplicated patches, **1.24 points** when scaled by 48/66 to the full 66-patch set, and **1.30 points** when pooled over three independent batches (Table IV). A replication on a disjoint seed set (1001–1008) preserves the ordering and is reported in Section IV-C and Table IV. DiD is measured on the 48 patches that were duplicated, whereas A − C is measured on all 66, so Share weights it by 48/66 before forming the ratio: Share = DiD × (48/66) / (A − C). The three components then close exactly, 1.24 + 3.68 + 6.71 = 11.63 against a measured A − C of 11.61.

| Family | A | B | C | A − B | B − C | DiD | Share |
|---|---:|---:|---:|---:|---:|---:|---:|
| U-Net | 0.9231 | 0.8741 | 0.8070 | +4.90 | +6.71 | **+1.71** [+0.75, +2.67] | 11% |
| CNN | 0.9194 | 0.8666 | 0.7803 | +5.28 | +8.63 | **+2.06** [+0.85, +3.27] | 11% |
| Prithvi (dual, fine-tuned) | 0.9012 | 0.8447 | 0.8294 | +5.65 | +1.53 | **+2.97** [+2.07, +3.87] | 30% |
| XGB_raw | 0.9273 | 0.8270 | 0.8494 | +10.03 | −2.24 | **+4.40** [+4.32, +4.48] | 41% |
| RF_raw | 0.9446 | 0.8396 | 0.8518 | +10.50 | −1.22 | **+5.19** [+5.05, +5.34] | 41% |

All five duplication effects are positive in every replicate, at p = 0.0078 in every case, the smallest value attainable by a two-sided sign-flip test with eight seeds. The three deep-model intervals overlap: what the point estimates support is a grouping, tree ensembles above the token decoder above the convolutional decoders, rather than a strict ordering of adjacent families. An independent replication of the U-Net row with eight fresh seeds is given in Table IV. Stage C re-trains the tile-level configuration inside the ablation pipeline; it reproduces the Table II values to within 1.1 points (U-Net 0.807 against 0.796, CNN 0.780 against 0.789, Prithvi 0.829 against 0.820). An independent implementation of the same U-Net configuration gave 0.796, so this residual is the run-to-run spread of two eight-seed runs rather than a pipeline defect, and the same comparison, 1.4 points in the independent implementation against 1.7 here, is our estimate of the reproducibility of the headline contrast.

The 11.61-point gap measured here exceeds the 11.5-point cross-protocol difference of Tables I and II because the latter compares two differently composed test sets.

On the common set the U-Net loses **4.90 points** when the 48 duplicated patches are deleted (A → B) and a further **6.71 points** when the whole tiles are withheld (B → C), for a total of 11.61 points (Fig. 3a). The two steps are not nested, stage C is a different set of 274 patches rather than a subset of B, which leaves a sample-size explanation open. A third arm closes it. Arm C′ is drawn from the same held-out tiles as C but restricted to 232 patches, matching B exactly, so the two contrasts can be read separately: **B → C′** changes the spatial source and nothing else, **C′ → C** changes the sample size by 42 patches and nothing else. For the U-Net the spatial source carries **6.54 of the 6.71 points** and the extra patches carry 0.17; for the CNN the split is 7.61 and 1.02. The second step is therefore measured, not argued, to be a spatial-source effect (Fig. 4).

[[FIG:3]]

[[FIG:4]]

To check that the gradient is a property of the families rather than of one draw of seeds, we repeated the two-arm ablation for the other four families on a disjoint seed set (1001–1008). The replication lands within 0.24 points of the original for all four, CNN 2.06 → 1.82, Prithvi 2.97 → 3.11, XGB 4.40 → 4.44, RF 5.19 → 5.12, and preserves the ordering exactly (RF > XGB > Prithvi > CNN). Both components replicate as well: Δ_{seen} moves by at most 1.0 point and Δ_{unseen} by at most 1.1, so the placebo contrast is as reproducible as the effect it corrects. The U-Net arm, replicated separately on the same fresh seeds (Table IV), is the exception: its duplication effect falls from 1.71 to 0.90, the largest seed-to-seed movement in the study and the reason its magnitude is quoted as a range. We therefore treat the ordering as replicated and the individual magnitudes as estimated to about ±0.3 points.

Repeating the intervention for the other four families changes the picture in two ways (Table III, Fig. 5). First, the duplication effect is **not uniform**: it is 1.7 and 2.1 points for the two convolutional models, 3.0 for the token decoder, and 4.4 and 5.2 points for XGB and RF. The ordering is monotone in the direction opposite to each model's use of spatial context, the less spatial structure a model exploits, the more of its reported score comes from duplicated samples, and it spans a factor of three.

Second, the neighbourhood term behaves differently across families, and here the matched arm corrects us. For the two convolutional decoders it is the dominant term (6.7 and 8.6 points). For the token decoder it is small (1.5), and almost none of it survives the matching: its 1.53 splits into 0.37 from the spatial source and 1.17 from the extra patches, so the token decoder's dependence on same-tile locality is even weaker than the raw contrast suggests. For the two pixel-wise ensembles the term is slightly **negative** (−1.2 and −2.2), and the matched arm shows that this is *not* the sample-size effect we originally proposed, the 42 extra patches account for only 0.07 and 0.19 of it. Withholding tiles therefore helps a spatially blind model by changing *which* patches it trains on, not by giving it more of them. We can rule out data quantity; the most likely remaining candidate is a shift in the spectral composition of the two training pools, which we do not pursue here.

The composition is the quantitative core of this paper. The total protocol penalty is largest for the two convolutional models (11.6 and 13.9 points) and smaller for the token decoder and the pixel-wise ensembles (7.2 and 7.8–9.3), yet duplication accounts for 11% of the two convolutional models, 30% of the token decoder and 41% of the pixel-wise ones. No single remedy addresses both: deduplication targets the models that already lose least overall, and spatial blocking targets the ones for which duplication is a minor term.

[[FIG:5]]

Deleting the 48 patches is not a clean intervention, because it also removes 17% of the training data and, since E_{seen} and E_{unseen} are interleaved within the same tiles, part of the local information around both. The placebo quantifies this: on patches that were never seen, the same deletion still costs 3.68 points (Fig. 3b).

The naive within-set contrast explains why such a placebo is necessary. Comparing E_{seen} against E_{unseen} directly suggests that having a patch in training is worth nothing, the patch-level models of Table I, which trained on all 48, score 0.913 on those 48 and 0.912 on the 18 they never saw. But the tile-level models, which have seen neither subset, score 0.778 on the 48 against 0.820 on the 18, i.e. the 48 patches are **4.2 points harder by construction**. The direct contrast therefore measures the sum of a duplication gain and a difficulty deficit, and with 18 unseen patches it cannot resolve a four-point effect in any case.

**TABLE IV.** The placebo contrast and the difference-in-differences for all five families, with the independent replication of the U-Net arm. Δ_{seen} is measured on the 48 duplicated patches and Δ_{unseen} on the 18 that were never seen; DiD = Δ_{seen} − Δ_{unseen}. Intervals are 95% t intervals over seeds and cover seed-to-seed variation only (Section III-B); p is the exact two-sided sign-flip value for eight seeds, whose smallest attainable value is 2/256 = 0.0078. The pooled row is an inverse-variance fixed-effect combination of the two U-Net experiments run with the same implementation; the 1.4-point estimate from the independent implementation (Section IV-C) is not pooled, because pooling across implementations would conflate implementation differences with sampling variation. heterogeneity between them is moderate (I² = 51%), so that interval is optimistic, a random-effects interval would be 0.4 to 2.2, and the pooled value is quoted as a descriptive midpoint rather than as a pooled test.

| Family | Δ_{seen} (pp) | Δ_{unseen} (pp) | DiD (pp) | 95% CI (DiD) | sign | p |
|---|---:|---:|---:|---|---:|---:|
| U-Net | +5.40 | +3.68 | **+1.71** | [+0.75, +2.67] | 8/8 | 0.0078 |
| CNN | +5.86 | +3.80 | **+2.06** | [+0.85, +3.27] | 8/8 | 0.0078 |
| Prithvi | +6.48 | +3.51 | **+2.97** | [+2.07, +3.87] | 8/8 | 0.0078 |
| XGB_raw | +11.27 | +6.88 | **+4.40** | [+4.32, +4.48] | 8/8 | 0.0078 |
| RF_raw | +11.98 | +6.78 | **+5.19** | [+5.05, +5.34] | 8/8 | 0.0078 |
| *U-Net, replication (1001–1008)* | +2.80 | +1.89 | *+0.90* | [−0.04, +1.85] | 6/8 | 0.079 |
| *U-Net, pooled (16 runs)* | — | — | *+1.30* | [+0.69, +1.91] | — | — |

The placebo is informative for every family, and it matters most for the two that carry the headline. On patches that were never seen, deleting the same 48 patches still costs 3.7 and 3.8 points for the two convolutional models and 3.5 for the token decoder, but **6.9 and 6.8 points for XGB and RF**. For the pixel-wise ensembles the placebo is therefore *larger than the effect it is meant to control*: on the patches that were duplicated, the same deletion costs 11.3 and 12.0 points, of which 6.9 and 6.8 also appear on patches that were never seen, leaving 4.4 and 5.2 for duplication itself. An estimate that skipped the placebo would have more than doubled the duplication effect for precisely those two families, which is the opposite of what a reader might assume from the small intervals of Table III.

This gives the gradient a second face. The less a model uses spatial context, the greater the share of its protocol penalty that is a plain sample-size effect rather than a leakage effect: ordinary data loss accounts for 32% and 27% of the penalty in the two convolutional models, 49% in the token decoder, and 88% and 73% in the two ensembles, while duplication accounts for 11%, 11%, 30%, 41% and 41% respectively. For a spatially blind baseline, withholding tiles largely removes an advantage that has nothing to do with locality at all.

Exact duplication is therefore worth **1.24 points on the full 66-patch scale**, 1.7 on the duplicated patches themselves, not 4.9. The remaining **3.7 points** of the first step is the ordinary cost of deleting training data, most of it local, and the three components close: 1.24 + 3.68 + 6.71 = 11.63 against a measured total of 11.61. And the dominant term is neither: withholding the tiles costs 6.7 points while adding patches.

Because the magnitude of this term carries the argument, we repeated the whole ablation with eight seeds that were not used anywhere else (1001–1008). The replication reproduces the direction and the structure of the decomposition but gives a smaller duplication effect, **+0.90 points (95% CI −0.04 to +1.85, 6/8)**, against +1.71 in the original. The two intervals overlap substantially, and an inverse-variance combination of the two experiments places the effect at **+1.30 points (0.69–1.91)**. We therefore treat 1.3 rather than 1.7 as the best estimate and report the range across experiments. The family ordering in Table III, by contrast, does not depend on this uncertainty: the smallest family effect (1.7) and the largest (5.2) differ by a factor of three, far outside the spread of either experiment. In this benchmark, the reported inflation is a **neighbourhood** phenomenon, test patches sit inside the spatial support of the training sample, and half-overlapping neighbours are enough to reproduce most of the advantage, rather than a duplication phenomenon that deduplication would fix.

### D. Multi-Task Gains Do Not Reproduce, in Any Cell

**TABLE V.** Paired dual-versus-single difference in IoU at the tile level, λ = 1, eight seeds, two backbones and two auxiliary labels. α = 0.05, two-sided; Bonferroni threshold for four comparisons α = 0.0125. p (perm) is the exact two-sided sign-flip randomisation p-value for the *mean paired difference*; because its null distribution uses the magnitudes of the individual differences, it is not a function of the sign count alone.

| Backbone | Auxiliary label | Δ IoU | 95% CI | p (t) | p (perm) | Δ > 0 |
|---|---|---|---|---|---|---|
| CNN | geometric (clean) | +0.0087 | [−0.0010, +0.0185] | 0.071 | 0.078 | 6/8 |
| CNN | stability (product) | −0.0000 | [−0.030, +0.030] | 0.9996 | 1.0000 | 5/8 |
| U-Net | geometric (clean) | +0.0032 | [−0.0167, +0.0231] | 0.714 | 0.727 | 5/8 |
| U-Net | stability (product) | +0.0201 | [+0.0007, +0.0396] | 0.044 | 0.039 | 7/8 |

At the patch level, where the protocol rewards local texture, the same comparison is negative under the pre-specified weight (Δ = −0.0065, 95% CI [−0.0126, −0.0004], p(t) = 0.041, p(perm) = 0.055, 2/8), and more negative at λ = 0.3 (Δ = −0.0072, p(t) = 0.034, 2/8).

Three observations from Table V. First, once leakage is removed, no cell survives correction: the only nominally significant cell (U-Net with the stability label, +2.0 points) sits at p = 0.044 against a Bonferroni threshold of 0.0125, and its confidence interval barely excludes zero (Fig. 6a). Second, that cell is not attributable to the backbone: replacing the stability label with the drift-free geometric label removes 84% of the effect (+2.01 → +0.32 points, p = 0.714). The gain, such as it is, follows the *label*, not the architecture. Third, the patch-level sign is negative but does not survive correction either; the defensible statement is that the previously reported gain does not reproduce, and that the point estimate is negative under a leaked protocol.

[[FIG:6]]

### E. Mechanism: the Auxiliary Head Regularises, and Neighbourhood Rewards Memorisation

For the plain convolutional encoder the dual-task model is markedly more stable across seeds than its single-task counterpart: at the tile level its standard deviation is 0.0131 against 0.0284, a factor of 2.2 (variance-ratio test p = 0.059, n = 8; reported descriptively), at an identical mean of 0.7895. The auxiliary head therefore acts as a regulariser for that encoder, **lowering variance without improving bias**. The effect is not uniform, and we state it narrowly: for the U-Net at the tile level the ratio is only 1.2 (0.0121 against 0.0146), and at the patch level the two arms are indistinguishable on both counts, 0.9101 against 0.9104 in accuracy and 0.0027 against 0.0024 in spread (Table I). Under the leaked protocol, where half-overlapping neighbours reward memorisation of local texture, regularisation therefore buys nothing at all: the dual–single difference is −0.03 points at the patch level against +2.01 under the blocked protocol. What the auxiliary head cannot do is help while the neighbourhood is still there. We also note that pairing by seed provided no variance reduction here (the implied correlation between dual and single performance at a given seed is about −0.4), which *increases* the variance of the difference rather than reducing it, so the paired test is no more powerful than an unpaired one, and arguably less.

### F. The Stability Head: A Disclosure, Not a Product

**TABLE VI.** Stability-head performance, pooled over **twelve** dual-task runs (three seeds × four values of λ = 0.3, 0.5, 0.7 and 1.0, static IoU 0.894–0.909), 983,040 test pixels. These runs belong to the patch-level split, so the figures below are not leakage-free and are read as a disclosure rather than as an accuracy claim.

| Class | Precision | Recall | F1 |
|---|---|---|---|
| Stable non-saline | 0.971 | 0.796 | 0.875 |
| Stable saline | 0.974 | 0.887 | 0.928 |
| Expansion | 0.148 | 0.790 | 0.250 |
| Shrinkage | 0.155 | 0.029 | 0.049 |
| Macro | 0.562 | 0.625 | **0.525** |
| Weighted | 0.932 | 0.836 | 0.872 |

Pooled accuracy is 0.836 (Table VI). The expansion class attains F1 = 0.25 with high recall (0.79) but low precision (0.15), whereas shrinkage remains near-degenerate (0.049). With the foundation-model backbone the auxiliary head is stronger (macro-F1 0.572; shrinkage 0.236), an observation we report without claiming generality, since it rests on one backbone and one basin. Critically, the 3.1% apparent expansion is dominated by the v100 → v200 product difference rather than by real salinization, so the head is presented as an auxiliary regulariser and a transparency disclosure, not as an operational change-detection product.

---

## V. DISCUSSION

### A. The Dominant Factors Are the Label and the Protocol

Across five model families, two protocols and two auxiliary labels, the ordering of results is explained by two quantities that are not architectural: how separable the proxy is from raw reflectance, and whether the protocol withholds spatial units. A pixel-wise forest wins under both protocols; a 100 M foundation model wins nothing; and the protocol penalty itself ranges from 7.2 to 13.9 points across the five families. For the U-Net, where it is 11.6 points, about 57.8% of it is same-tile neighbourhood sampling, 10.7% exact duplication, and 31.7% the ordinary cost of a smaller training set. The split is not transferable: Section V-B shows that it inverts across families, and that the duplication term alone ranges from 1.7 to 5.2 points when read as the DiD on the duplicated patches (1.2 to 3.8 on the full 66-patch scale). For a field in which architectural novelty is the usual currency, this is an uncomfortable but actionable result: before comparing models on a proxy-labelled benchmark, one should first report how well a spatially blind linear model performs.

### B. Leakage Is Neither Binary Nor Uniform

Three features of the multi-family ablation are, in our view, the most transferable.

First, **duplication is a problem of models that can memorise, not of models that exploit texture.** The intuitive account, that convolutional decoders with skip connections benefit most from overlapping patches, because they can copy high-frequency texture from a neighbour, predicts the opposite of what we observe. The duplication effect is largest for the two pixel-wise ensembles (4.4 and 5.2 points), intermediate for the token decoder (3.0), and smallest for the two convolutional decoders (1.7 and 2.1). The dose runs the other way as well: the convolutional models are trained on every pixel of the duplicated patches, whereas the pixel-wise ensembles draw 800,000 of the 4,587,520 training pixels (one in 5.7), so a given duplicated pixel has only about a one-in-six chance of entering their training sample. A lower dose produces a threefold larger effect. A tree ensemble can isolate a single six-dimensional spectrum in a leaf and reproduce it exactly on the same pixels; a convolutional decoder with batch normalisation, flip augmentation and 274 training patches cannot revisit individual pixels; the token decoder sits between the two because its input is quantised into 16 × 16 patch tokens before attention is applied, which limits how exactly a single pixel spectrum can be reproduced. The gradient across the five families is monotone in the models' use of spatial context and spans a factor of three.

Second, **the remedy is family-specific, because the composition inverts.** For the two convolutional decoders duplication accounts for 11% of the protocol penalty and the withheld neighbourhood for 58–62%; for the pixel-wise ensembles the ordering is reversed, duplication accounts for 41% and the neighbourhood term is *negative*. Withholding tiles does not penalise a spatially blind model at all; and the matched arm shows this is not a sample-size effect: the 42 extra patches account for less than 0.2 of it. A benchmark policy that applies spatial blocking to every model will therefore overstate its cost for pixel-wise baselines while under-addressing the duplication they are actually exposed to, and deduplication alone leaves the convolutional models essentially untouched.

Third, the naive within-set contrast is misleading on its own. On the same 66 patches, a tile-level model that has never seen any of them still scores 4.2 points lower on the 48 that the patch-level model trained on, so those 48 patches are intrinsically harder. Any estimate that ignores this compares models and subsets at the same time. With 18 unseen patches the contrast is also too imprecise to resolve a four-point effect, which is why the placebo arm rather than the contrast carries the argument.

Finally, the headline contrast is reproducible in sign but not in magnitude, and we report the two parts differently. For the four non-convolutional families a replication on a disjoint seed set returns duplication effects within 0.24 points of the original and the same ordering, so the gradient is not a property of one draw of seeds. For the U-Net, three independent batches of eight runs, two implementations and one replication, return 1.4, 1.7 and 0.9 points for the same configuration, with the absolute levels of the three stages moving by about one point between implementations and a combined estimate of 1.3. We therefore treat the ordering as replicated and the U-Net magnitude as a range, and we do not quote the individual terms to two decimal places.

### C. Why the Foundation Model Did Not Win, and Why That Is Not a Verdict

Its patch-level IoU is among the lowest of the deep models, but its cross-protocol penalty is also among the smallest, so under the leakage-free protocol it moves to the top of the deep models, by a margin small enough to be inside seed variability. Two design constraints bound the interpretation: the single-date input bypasses the three-dimensional patch embedding, so half of the pretraining is unused; and 62.7 M trainable parameters against 274 training patches is an extreme low-data stress test rather than a capacity-matched comparison. What the data support is narrower and still useful: in this regime pretraining did not compensate for the absence of a task-appropriate decoder, and a six-band forest with no spatial context retained a 3.6-point point-estimate advantage.

### D. Relation to Multi-Task Learning in Remote Sensing

Reported multi-task gains in remote sensing segmentation are typically obtained with shared encoders on tasks whose labels come from the same annotation process, such as segmentation with height estimation or with pan-sharpening [27], [28]. Our auxiliary task is different in kind: its label is derived from a different product, at a different confidence, and it is only weakly related to the primary target. That the gain is absent here, and is carried by one auxiliary label rather than by the backbone, is consistent with the view that multi-task benefit depends on label relatedness and on the evaluation regime, not on the architecture alone [8], [29], [39].

### E. Implications for Benchmark Practice

Four checks would have changed the conclusions of this study and are cheap to adopt: report the separability of the proxy label; report the fraction of test patches sharing a tile with training; report scores on a common pixel set rather than on two differently composed test sets; and, where the leakage claim is load-bearing, intervene on the training set rather than compare two splits. Each is a sentence and a number, or a single retraining run of an existing configuration, not a new study.

### F. Limitations

(i) *Construct validity*: the label is a bare-ground proxy subject to the systematic errors of global products [23]–[26], not a salinity measurement; no conductivity data exist, so positive predictive value is not estimable and no statement here is an accuracy claim about soil salinity. (ii) *Ablation geometry*: stages B and C are not nested, C is a different set of 274 patches rather than a subset of B, so the 4.9 and 6.7-point steps are two contrasts rather than an exact partition. The matched arm C′ resolves what the nesting would have resolved: holding the patch count at 232 while changing the spatial source recovers 6.54 of the U-Net's 6.71 points, leaving 0.17 for the 42 extra patches. The same arm shows that the *sign* of the neighbourhood term for the pixel-wise ensembles is not a data-quantity effect either, and we do not claim to explain it. (iii) *Placebo assumption*: the difference-in-differences credits the placebo contrast as a common additive offset; if deleting the 48 patches degrades the local support of the *seen* patches more than that of the unseen ones, which is likely, since the deleted patches are themselves members of the seen set, then Δ_{unseen} is deflated and the duplication effect is an **upper bound**, consistent with the smaller value obtained in the replication. (iv) *Precision of the within-set contrast*: only 18 of the 66 evaluation patches are unseen, and 10 of those were used for early stopping, so the unseen set is small and not fully naive. (v) *Scope of the ablation*: it covers five families but one head configuration each (the Prithvi arm is dual-task, the others single-task), one basin and one sensor; the ordering of the families is an empirical fact of this benchmark, replicated on a disjoint seed set, but its explanation in terms of memorisation capacity is an interpretation rather than a measurement. (vi) *Statistical power*: eight seeds exclude effects larger than 1.3 to 4.1 points depending on the cell, but cannot resolve sub-point differences, and pairing did not reduce variance. (vii) *Magnitude of the duplication term*: three independent batches give 0.9, 1.4 and 1.7 points for the same configuration, one of which does not reach significance on its own; the pooled estimate of 1.3 points is the quantity we defend, and it is small relative to the neighbourhood term. (viii) *External validity*: one basin, one sensor, one season, 400 patches; the separability ladder and both leakage terms are properties of this proxy in this landscape and should be re-measured, not assumed, elsewhere.

---

## VI. CONCLUSION

We assembled a reproducible, leakage-audited benchmark for proxy-labelled salinization mapping in the Qaidam Basin and used it to reassess two widely assumed advantages. The proxy is close to linearly separable: one band with one threshold reaches 0.820, a six-band linear model 0.890, and a pixel-wise forest with no spatial context 0.927, the highest score under both protocols, and 3.6 points above a 100 M foundation model at the tile level. The conventional patch-level split inflates the reported score of a U-Net by 11.6 points, but a controlled intervention shows that only 1.3 points of that inflation is attributable to duplicated samples (0.9–1.7 across three independent batches), while 6.7 is attributable to evaluating inside the spatial support of the training sample. Repeating the intervention across five families shows that the split of the inflation is family-specific: duplication accounts for 11% of the penalty for convolutional decoders, 30% for a token decoder and 41% for spatially blind ensembles. Multi-task learning provides no resolvable gain once spatial blocking is applied, and the only auxiliary-task cell that is nominally significant does not survive correction.

The practical implication is that for basin-scale, proxy-labelled mapping problems the highest-leverage contributions are not new architectures but (i) characterising the separability of the proxy before comparing models, (ii) holding out spatial blocks rather than patches, and (iii) reporting paired, power-aware comparisons on a common pixel set instead of post-hoc best configurations. Deduplication, the intuitive remedy, is not one of them.

---

## APPENDIX, SENTINEL-2 TILE INVENTORY

**TABLE A1.** The 18 Sentinel-2 tiles from which patches were cropped. All scenes are Level-2A, processed with Sen2Cor, and each was required to meet the 15% scene-level cloud-cover ceiling stated in Section II-B. Acquisition dates are those encoded in the scene identifiers.

| Tile | Scene identifier | UTM zone | Acquisition date |
|---|---|---|---|
| 45SYA | S2A_45SYA_20200929_1_L2A | 45N | 2020-09-29 |
| 45SYD | S2B_45SYD_20200825_1_L2A | 45N | 2020-08-25 |
| 46SBE | S2A_46SBE_20200929_1_L2A | 46N | 2020-09-29 |
| 46SBH | S2B_46SBH_20200825_1_L2A | 46N | 2020-08-25 |
| 46SCH | S2B_46SCH_20200825_1_L2A | 46N | 2020-08-25 |
| 46SDE | S2B_46SDE_20200819_1_L2A | 46N | 2020-08-19 |
| 46SDH | S2B_46SDH_20200901_1_L2A | 46N | 2020-09-01 |
| 46SEH | S2A_46SEH_20200725_1_L2A | 46N | 2020-07-25 |
| 46SFF | S2A_46SFF_20200725_1_L2A | 46N | 2020-07-25 |
| 46SFH | S2A_46SFH_20200725_1_L2A | 46N | 2020-07-25 |
| 46SGF | S2A_46SGF_20200930_1_L2A | 46N | 2020-09-30 |
| 46SGH | S2B_46SGH_20200915_1_L2A | 46N | 2020-09-15 |
| 47SKB | S2B_47SKB_20200925_1_L2A | 47N | 2020-09-25 |
| 47SLV | S2A_47SLV_20200917_1_L2A | 47N | 2020-09-17 |
| 47SMB | S2B_47SMB_20200915_1_L2A | 47N | 2020-09-15 |
| 47SMV | S2A_47SMV_20200917_1_L2A | 47N | 2020-09-17 |
| 47SNB | S2B_47SNB_20200922_1_L2A | 47N | 2020-09-22 |
| 47SNV | S2A_47SNV_20200917_1_L2A | 47N | 2020-09-17 |

Every tile contributes patches to all three partitions of the patch-level split; under the tile-level split the same 18 tiles divide into the 274/60/66 patch groups, and the tile composition of each partition is released with the split definition.

---

## ACKNOWLEDGMENT

The authors thank `[TO ADD]`. Sentinel-2 imagery was obtained from the Copernicus Data Space; the WorldCover product from ESA [1]; the Prithvi-EO-1.0 weights from IBM and NASA. Derived labels, split definitions, per-run metrics and evaluation code are available at `[DOI]`.

---

## REFERENCES

[1] D. Zanaga et al., "ESA WorldCover 10 m 2021 v200," Zenodo, 2022, doi: 10.5281/zenodo.7254221.
[2] J. Jakubik et al., "Foundation models for generalist geospatial artificial intelligence," arXiv:2310.18660, 2023.
[3] O. Ronneberger, P. Fischer, and T. Brox, "U-Net: Convolutional networks for biomedical image segmentation," in *Proc. MICCAI*, 2015, pp. 234–241.
[4] L. Breiman, "Random forests," *Mach. Learn.*, vol. 45, no. 1, pp. 5–32, 2001.
[5] T. Chen and C. Guestrin, "XGBoost: A scalable tree boosting system," in *Proc. 22nd ACM SIGKDD*, 2016, pp. 785–794.
[6] E. J. Hu et al., "LoRA: Low-rank adaptation of large language models," in *Proc. ICLR*, 2022.
[7] M. Drusch et al., "Sentinel-2: ESA's optical high-resolution mission for GMES operational services," *Remote Sens. Environ.*, vol. 120, pp. 25–36, May 2012.
[8] R. Caruana, "Multitask learning," *Mach. Learn.*, vol. 28, no. 1, pp. 41–75, 1997.
[9] D. R. Roberts et al., "Cross-validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure," *Ecography*, vol. 40, no. 8, pp. 913–929, 2017.
[10] P. Ploton et al., "Spatial validation reveals poor predictive performance of large-scale ecological mapping models," *Nature Commun.*, vol. 11, no. 1, p. 4540, 2020.
[11] T. Kattenborn, F. Schiefer, J. Frey, H. Feilhauer, M. D. Mahecha, and C. F. Dormann, "Spatially autocorrelated training and validation samples inflate performance assessment of convolutional neural networks," *ISPRS Open J. Photogramm. Remote Sens.*, vol. 5, p. 100018, 2022.
[12] Y. Wang, M. Khodadadzadeh, and R. Zurita-Milla, "Spatial+: A new cross-validation method to evaluate geospatial machine learning models," *Int. J. Appl. Earth Obs. Geoinf.*, vol. 121, p. 103364, 2023.
[13] J. Linnenbrink, C. Milà, M. Ludwig, and H. Meyer, "kNNDM CV: k-fold nearest-neighbour distance matching cross-validation for map accuracy estimation," *Geosci. Model Dev.*, vol. 17, no. 15, pp. 5897–5912, 2024.
[14] F. Wang et al., "Advancements and perspective in the quantitative assessment of soil salinity utilizing remote sensing and machine learning algorithms: A review," *Remote Sens.*, vol. 16, no. 24, p. 4812, 2024.
[15] M. Zhang et al., "Monitoring soil salinity in arid areas of Northern Xinjiang using multi-source satellite data: A trusted deep learning framework," *Land*, vol. 14, no. 1, p. 110, 2025.
[16] H. Chen, J. Wu, and C. Xu, "Optimization of multi-source remote sensing soil salinity estimation based on different salinization degrees," *Remote Sens.*, vol. 17, no. 7, p. 1315, 2025.
[17] K. John, D. D. Saurette, and B. Heung, "The problematic case of data leakage: A case for leave-profile-out cross-validation in 3-dimensional digital soil mapping," *Geoderma*, vol. 455, Art. no. 117223, 2025, doi: 10.1016/j.geoderma.2025.117223.
[18] V. Kostejn, Y. Essus, J. Abrahamson, and R. R. Vatsavai, "U-Prithvi: Integrating a foundation model and U-Net for enhanced flood inundation mapping," in *Proc. GIScience*, vol. 18, 2025, pp. 18:1–18:17, doi: 10.4230/LIPIcs.GIScience.2025.18.
[19] X. Jin, R. Guo, and W. Xia, "Distribution of actual evapotranspiration over Qaidam Basin, an arid area in China," *Remote Sens.*, vol. 5, no. 12, pp. 6976–6996, 2013, doi: 10.3390/rs5126976.
[20] A. Boser, "Validating spatio-temporal environmental machine learning models: Simpson's paradox and data splits," *Environ. Res. Commun.*, vol. 6, no. 3, Art. no. 031003, 2024, doi: 10.1088/2515-7620/ad2e44.
[21] X. Jiang, H. Duan, J. Liao, P. Guo, C. Huang, and X. Xue, "Comparative research on multi-algorithm of soil salinity monitoring based on Gaofen-5, Sentinel-1, and Sentinel-2," *Int. J. Remote Sens.*, vol. 44, no. 15, pp. 4704–4726, 2023, doi: 10.1080/01431161.2023.2235640.
[22] N. M. Khan, V. V. Rastoskuev, Y. Sato, and S. Shiozawa, "Assessment of hydrosaline land degradation by using a simple approach of remote sensing indicators," *Agric. Water Manag.*, vol. 77, no. 1–3, pp. 96–109, 2005, doi: 10.1016/j.agwat.2004.09.038.
[23] I. Mirpulatov, S. Illarionova, D. Shadrin, and E. Burnaev, "Pseudo-labeling approach for land cover classification through remote sensing observations with noisy labels," *IEEE Access*, vol. 11, pp. 82570–82583, 2023.
[24] M. Hell and M. Brandmeier, "Identifying plausible labels from noisy training data for a land use and land cover classification application in Amazônia Legal," *Remote Sens.*, vol. 16, no. 12, p. 2080, 2024.
[25] J. Zhao et al., "A cross-spatiotemporal weakly supervised framework for land cover classification: Generating temporally and spatially consistent land cover maps," *ISPRS J. Photogramm. Remote Sens.*, vol. 227, pp. 519–538, 2025.
[26] M. Otsu, J. Zhou, B. Han, A. Accad, and S. Pan, "A robust co-training framework to handle noisy labels for remote sensing image segmentation," *IEEE Trans. Geosci. Remote Sens.*, vol. 63, pp. 1–14, 2025, doi: 10.1109/TGRS.2025.3563922.
[27] M. Wang, Z. Yan, Y. Feng, W. Diao, and X. Sun, "Multi-task learning of semantic segmentation and height estimation for multi-modal remote sensing images," *J. Geodesy Geoinf. Sci.*, vol. 6, no. 4, pp. 27–39, 2023, doi: 10.11947/j.JGGS.2023.0403.
[28] L. Huang, B. Jiang, S. Lv, Y. Liu, and Y. Fu, "Deep-learning-based semantic segmentation of remote sensing images: A survey," *IEEE J. Sel. Topics Appl. Earth Observ. Remote Sens.*, vol. 17, pp. 8370–8396, 2024, doi: 10.1109/JSTARS.2023.3335891.
[29] J. Li, Y. Cai, Q. Li, M. Kou, and T. Zhang, "A review of remote sensing image segmentation by deep learning methods," *Int. J. Digit. Earth*, vol. 17, no. 1, Art. no. 2328827, 2024, doi: 10.1080/17538947.2024.2328827.
[30] C. Fibaek, L. Camilleri, A. Luyts, N. Dionelis, and B. Le Saux, "PhilEO Bench: Evaluating geo-spatial foundation models," in *Proc. IEEE Int. Geosci. Remote Sens. Symp. (IGARSS)*, 2024, pp. 2739–2744, doi: 10.1109/IGARSS53475.2024.10642780.
[31] X. Ma, X. Zhang, M.-O. Pun, and B. Huang, "A unified framework with multimodal fine-tuning for remote sensing semantic segmentation," *IEEE Trans. Geosci. Remote Sens.*, vol. 63, Art. no. 5405015, 2025, doi: 10.1109/TGRS.2025.3585238.
[32] M. Ludwig, A. Moreno-Martínez, N. Hölzel, E. Pebesma, and H. Meyer, "Assessing and improving the transferability of current global spatial prediction models," *Global Ecol. Biogeogr.*, vol. 32, no. 3, pp. 356–368, 2023, doi: 10.1111/geb.13635.
[33] H. Meyer and E. Pebesma, "Predicting into unknown space? Estimating the area of applicability of spatial prediction models," *Methods Ecol. Evol.*, vol. 12, no. 9, pp. 1620–1633, 2021, doi: 10.1111/2041-210X.13650.
[34] T. Zhao, X. Zhang, Y. Gao, J. Mi, W. Liu, J. Wang, M. Jiang, and L. Liu, "Assessing the accuracy and consistency of six fine-resolution global land cover products using a novel stratified random sampling validation dataset," *Remote Sens.*, vol. 15, no. 9, p. 2285, 2023, doi: 10.3390/rs15092285.
[35] G. I. Metternicht and J. A. Zinck, "Remote sensing of soil salinity: Potentials and constraints," *Remote Sens. Environ.*, vol. 85, no. 1, pp. 1–20, 2003, doi: 10.1016/S0034-4257(02)00188-8.
[36] X. Cao, Y. Cheng, J. Jiao, J. Jian, L. Bai, J. Li, and X. Ma, "Impact of land use/cover changes on soil erosion by wind and water from 2000 to 2018 in the Qaidam Basin," *Land*, vol. 12, no. 10, p. 1866, 2023, doi: 10.3390/land12101866.
[37] T.-Y. Lin, P. Goyal, R. Girshick, K. He, and P. Dollár, "Focal loss for dense object detection," in *Proc. IEEE Int. Conf. Comput. Vis. (ICCV)*, 2017, pp. 2999–3007, doi: 10.1109/ICCV.2017.324.
[38] L. Baetens, C. Desjardins, and O. Hagolle, "Validation of Copernicus Sentinel-2 cloud masks obtained from MAJA, Sen2Cor, and FMask processors using reference cloud masks generated with a supervised active learning procedure," *Remote Sens.*, vol. 11, no. 4, p. 433, 2019, doi: 10.3390/rs11040433.
[39] A. Kendall, Y. Gal, and R. Cipolla, "Multi-task learning using uncertainty to weigh losses for scene geometry and semantics," in *Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR)*, 2018, pp. 7482–7491, doi: 10.1109/CVPR.2018.00781.
[40] C.-I. Cira, M.-Á. Manso-Callejo, N. Yokoya, T. Sălăgean, and A.-C. Badea, "Impact of tile size and tile overlap on the prediction performance of convolutional neural networks trained for road classification," *Remote Sens.*, vol. 16, no. 15, p. 2818, 2024, doi: 10.3390/rs16152818.

---

## Figure Captions

**Fig. 1.** The proxy label bounds every score in the study. (a) Intersection-over-union on the patch-level test set for a separability ladder: a constant classifier at the 62% prevalence of the proxy (0.620), six single-band thresholds (B04 0.820, B03 0.802, B02 0.796, B12 0.714, B08 and B11 0.644), a six-band linear model (0.890) and four learned models, including the spatially blind random forest that leads the study (0.927). Colour marks six-band models, grey marks one band with one threshold, hollow marks the model-free floor. (b) The forest, the foundation model and the U-Net under both protocols; withholding whole tiles lowers every model and reorders them, by 7.0, 7.8 and 11.5 points respectively, matching the delta column of Table II.

**Fig. 2.** Sampling design and leakage audit. (a) Under a patch-level split, training and test patches are interleaved within the same MGRS tile, the windows being 128 × 128 pixels at a 64-pixel stride; under a tile-level split, whole tiles are withheld. (b) Composition of the common evaluation set, 66 patches: 48 also occur in the patch-level training set, 10 were used for early stopping and 8 were never seen. (c) Share of test patches whose tile also contains training patches, under the two protocols.

**Fig. 3.** Decomposition of the protocol gap on a common evaluation set (U-Net, eight seeds). (a) IoU of the same model trained on 280 patches including 48 members of the evaluation set (0.923), on 232 patches after deleting them (0.874), and on 274 patches from held-out tiles (0.807); dots are individual seeds, whiskers one standard deviation. (b) The resulting 11.6-point gap splits into 1.2 points of exact duplication, 3.7 of ordinary data loss and 6.7 of withheld neighbourhood, that is 11%, 32% and 58% of the total.

**Fig. 4.** The sample-size-matched arm. (a) IoU of arm B (232 patches, same tiles), arm C′ (274 patches from held-out tiles, its training set matched to B) and arm C (274 patches from held-out tiles). C′ lies close to C for every family, so the second step of the gap is not a sample-size effect. (b) The step from B to C split into the change of spatial source and the 42 extra patches: 6.5 of the 6.7 points for the U-Net and 7.6 of 8.6 for the CNN come from the spatial source alone. For the two pixel-wise ensembles the step is slightly negative, and the extra patches do not explain it either.

**Fig. 5.** Auxiliary-task effect and spectral indices. (a) Dual-minus-single IoU at the tile level for two backbones and two auxiliary labels. Only the U-Net with the stability label is nominally significant (p = 0.044), which does not survive Bonferroni correction for four comparisons (alpha = 0.0125), and the effect disappears when that label is replaced by the drift-free geometric one. (b) Spectral-index features help only under the tile-level protocol.

**Fig. 6.** Duplication effect by model family, eight replicates per arm. (a) Difference-in-differences between the 48 duplicated and the 18 unseen evaluation patches; whiskers are 95% confidence intervals. The point estimates rise monotonically as a model's use of spatial context falls, although the deep-model intervals overlap. (b) The same intervention as its three components, in percent of each family's total penalty: duplication accounts for 11%, 11%, 30%, 41% and 41% across the five families, and the remainder splits between ordinary data loss and withheld neighbourhood. For the two pixel-wise ensembles the neighbourhood component is negative, and the matched arm of Fig. 4 shows that the 42 extra patches do not cause it.

---
